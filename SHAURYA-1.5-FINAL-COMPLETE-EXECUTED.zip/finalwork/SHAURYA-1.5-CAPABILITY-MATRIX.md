# SHAURYA 1.5 — Capability Matrix

**Frozen scope:** Phases 1–10. No Phase 11 or new major architecture is introduced by this freeze audit.

| CAPABILITY | STATUS | EVIDENCE | DEPENDENCY | LIMITATION |
|---|---|---|---|---|
| Authentication/session architecture | PARTIALLY VERIFIED | API/auth code and focused tests; DB-backed full flow cannot run | PostgreSQL, asyncpg | Live persistence not verified |
| Projects/files/versions | PARTIALLY VERIFIED | API code and existing tests | PostgreSQL, asyncpg | Full CRUD integration blocked |
| Conversations/messages | IMPLEMENTED — NOT VERIFIED | API/model implementation | PostgreSQL | Live DB integration unavailable |
| Agent runtime/tool calling | PARTIALLY VERIFIED | Focused reliability/security tests | Model provider for live loop | Live model continuation not tested |
| Sandbox boundary | IMPLEMENTED — NOT VERIFIED | Sandbox architecture/configuration | Docker | Docker unavailable |
| Research | NOT_CONFIGURED | Provider boundary present | Research provider | No live provider configured |
| Document intelligence | PARTIALLY VERIFIED | Parser dependencies inspected; local parsing support present | Optional parser packages + DB | Full store/retrieve flow not verified |
| Knowledge base | IMPLEMENTED — NOT VERIFIED | API/storage/retrieval implementation | PostgreSQL; embedding provider for vector path | Live DB/provider integration unavailable |
| Multimodal/vision | NOT_CONFIGURED | Provider boundary present | Vision provider | No live provider configured |
| Embeddings | NOT_CONFIGURED | Provider boundary present | Embedding provider | No provider configured |
| Local Git | VERIFIED | Real temporary-repository Git tests | Git | Project workspace persistence requires runtime volume |
| GitHub | NOT_CONFIGURED | Provider implementation inspected | GitHub credentials | No live repository operation performed |
| CI | NOT_CONFIGURED | Provider abstraction inspected | CI provider | No live workflow executed |
| Deployment/rollback | NOT_CONFIGURED | Provider and approval boundaries inspected | Deployment provider | No live deployment executed |
| Approval system | VERIFIED | Approval-focused tests and endpoint implementation | PostgreSQL for persistence | External-provider execution not tested |
| Security boundaries | VERIFIED | Existing security suite + secret scan | None for static/unit checks | No penetration test/certification |
| Observability | PARTIALLY VERIFIED | Event/audit structures inspected | PostgreSQL/Redis for full runtime | Full cross-system correlation not live-tested |
| Frontend workspace | PARTIALLY VERIFIED | Static source/API contract audit | npm dependencies | Production build/browser E2E blocked |
| Alembic migrations | VERIFIED | Static `0001 → 0002 → 0003` validation | Alembic | Live PostgreSQL upgrade not run |
| Docker Compose configuration | VERIFIED | YAML parse and service inspection | Docker for runtime | Runtime unavailable |

## Status interpretation

- **VERIFIED** means the corresponding check was actually executed successfully in this environment.
- **PARTIALLY VERIFIED** means only the stated subset was executed successfully.
- **IMPLEMENTED — NOT VERIFIED** means implementation was inspected but the required runtime integration was not successfully executed.
- **NOT_CONFIGURED** means the required external provider/credential is absent.
- **BLOCKED** means a required local dependency/runtime prevented the check.
- **UNAVAILABLE** means the required runtime/tool is absent or unreachable.
- **NOT_TESTED** means no evidence was collected.
