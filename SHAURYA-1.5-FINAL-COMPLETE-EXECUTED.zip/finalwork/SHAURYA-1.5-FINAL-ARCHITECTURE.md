# SHAURYA 1.5 — Final Architecture

**Scope:** Frozen Phase 1–10 repository. This document describes the implementation that exists; it does not introduce a new architecture.

## Frontend

The Next.js/React frontend in `apps/web` provides authentication, project/file navigation, Monaco editing, agent task submission, task events, terminal execution state, research, knowledge-base document upload, image/vision state, Git status/diff, and deployment state. Production build and browser E2E are not verified in the freeze environment because frontend dependencies are unavailable.

## API

FastAPI in `apps/api/app/main.py` exposes authentication, projects/files/versions, conversations, tasks/events, execution, research, documents, knowledge, multimodal, review/security, Git, GitHub, CI, deployment, approvals, environments, memory, model information, health, and production-readiness endpoints.

## Authentication and authorization

Authentication uses the existing JWT/session architecture. Project-scoped endpoints use project authorization checks. Sensitive external actions use the approval record boundary.

## Database

SQLAlchemy async models are backed by PostgreSQL through `asyncpg`. Alembic migrations are ordered as `0001_initial → 0002_phase7_intelligence → 0003_phase8_workflows`. Static migration validation passed; live PostgreSQL CRUD is blocked in the current environment.

## Redis

Redis is configured as the asynchronous infrastructure/cache boundary. The configured service is represented in Compose and application infrastructure, but live Redis verification is blocked.

## Agent runtime and model abstraction

The agent runtime persists task state, iterations, tool calls, executions, events, and results. Model providers are abstracted with primary/fallback configuration. A live autonomous repair loop requires an actual model provider and sandbox runtime and was not tested during the freeze.

## Tool system

Tools are registered and invoked through the existing authorization/execution boundary. Structured failures are represented as explicit errors/events rather than fabricated success.

## Sandbox

The repository contains Docker-based sandbox architecture with resource/security controls and a sandbox worker. Docker is unavailable in the audit environment, so runtime sandbox execution is not verified.

## Repository intelligence

Repository indexing provides bounded file/symbol context and supports relevant-file retrieval without requiring the entire repository to be sent to a model.

## Research

Research providers, source records, citations, and untrusted-content handling are implemented as provider boundaries. No live research provider is configured in the freeze environment.

## Documents

Document extraction/chunking supports the parser dependencies declared by the repository. Full persistent document integration requires the database and, for vector retrieval, an embedding provider.

## Knowledge base and embeddings

Knowledge documents/chunks and project-scoped retrieval are represented in the database model and API. Embedding generation is provider-backed and remains unconfigured.

## Multimodal

Image upload/validation and vision-provider boundaries exist. No live vision provider is configured.

## Git

Local Git operations use real subprocess Git against project-scoped workspaces: status, branches, diff, history, staging/commit, and push boundary. Git path/branch validation is covered by focused tests.

## GitHub

GitHub REST integration uses server-side credentials and approval-gated sensitive operations. No GitHub credential is configured for this freeze.

## CI

CI is provider-neutral and HTTP-backed. No live CI provider is configured.

## Deployment

Deployment is provider-neutral and includes approval, deployment states, health checks, and rollback boundaries. No live deployment provider is configured.

## Approvals

External mutations such as push, PR, deployment, rollback, publish, and repository modification use explicit approval records.

## Security

The repository contains path/project isolation, symlink and archive traversal protections, command/tool authorization boundaries, untrusted-content handling, secret redaction, and security tests. This is not a penetration test or security certification.

## Observability

Task, model, tool, execution, Git, approval, deployment, security, and error records/events are represented across the existing persistence and event architecture. Full live cross-system observability depends on unavailable infrastructure.

## Frozen external boundary

The remaining work is environment activation and real integration testing: PostgreSQL, Redis, Docker, frontend dependencies, model provider, GitHub, CI, deployment, research, vision, and embeddings. No new numbered development phase is part of this freeze.
