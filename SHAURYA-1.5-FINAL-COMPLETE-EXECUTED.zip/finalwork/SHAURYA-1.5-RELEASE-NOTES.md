# SHAURYA 1.5 — Release Notes

## Version

**SHAURYA 1.5**

## Status

**RELEASE CANDIDATE — EXTERNAL INTEGRATION INCOMPLETE**

This is the frozen Phase 1–10 engineering state. It is not labeled production-ready.

## Implemented capabilities

- Authentication and project workspace architecture
- Files, versions, conversations, tasks, tool calls, executions and events
- Autonomous-agent runtime and model-provider abstraction
- Sandbox architecture and execution boundary
- Research and citation architecture
- Document intelligence and knowledge-base architecture
- Multimodal/vision architecture
- Local Git and GitHub provider architecture
- CI and deployment provider boundaries
- Approval-gated external actions and rollback boundary
- Security controls and observability structures
- Next.js/React workspace frontend
- PostgreSQL/Redis architecture and Alembic migrations

## Verified in the freeze environment

- Python compilation
- Focused Phase 8–10 tests
- Security boundary tests
- Local Git tests
- Static Alembic chain validation
- Docker Compose YAML validation
- Repository structure checks
- Secret-pattern scan
- API import/health checks previously recorded by the integration audit

## Blocked / unavailable

- PostgreSQL/asyncpg runtime integration
- Redis runtime integration
- Docker sandbox execution
- Frontend production build/browser E2E

## Not configured

- AI model provider
- GitHub credentials
- CI provider
- Deployment provider
- Research provider
- Vision provider
- Embedding provider

## Known limitations

`apps/api/tests/test_api.py::test_project_and_file` remains blocked by the missing `asyncpg` package in the current environment. The complete repository suite therefore does not pass in this environment.

Live autonomous coding repair is not verified because the required model provider and Docker sandbox are unavailable.

Provider-backed GitHub, CI, deployment, research, vision, and embedding operations are not verified without their real credentials/services.

No penetration test or security certification has been performed.

## Setup requirements

1. Install the declared backend dependencies from `apps/api/requirements.txt`.
2. Install frontend dependencies under `apps/web`.
3. Provide PostgreSQL and Redis.
4. Configure `.env` from `.env.example` with real secrets.
5. Run Alembic migrations.
6. Configure only the providers actually intended for use.
7. Run the available tests and then real integration tests against disposable/staging infrastructure.
8. Keep sensitive external mutations approval-gated.

## Freeze boundary

No Phase 11 is defined. Future work should activate the documented external dependencies and fix failures found by genuine integration tests rather than expanding the architecture speculatively.
