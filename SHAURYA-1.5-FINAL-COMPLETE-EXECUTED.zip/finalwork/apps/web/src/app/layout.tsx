import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = { title: "SHAURYA 1.5", description: "AI workspace by SHAURYA" };

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
