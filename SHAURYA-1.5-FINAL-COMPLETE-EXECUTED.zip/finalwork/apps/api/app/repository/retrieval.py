from typing import Protocol
from dataclasses import dataclass
@dataclass
class VectorHit: id:str; score:float; content:str; metadata:dict
class EmbeddingProvider(Protocol):
    async def embed(self,texts:list[str])->list[list[float]]: ...
class VectorStore(Protocol):
    async def upsert(self,items:list[VectorHit]): ...
    async def search(self,vector:list[float],limit:int=10)->list[VectorHit]: ...
class Reranker(Protocol):
    async def rerank(self,query:str,hits:list[VectorHit])->list[VectorHit]: ...
class Retriever:
    def __init__(self,vector_store=None,embedder=None,reranker=None): self.vector_store=vector_store; self.embedder=embedder; self.reranker=reranker
    async def retrieve(self,query,limit=10):
        if not (self.vector_store and self.embedder): return []
        vectors=await self.embedder.embed([query]); hits=await self.vector_store.search(vectors[0],limit)
        return await self.reranker.rerank(query,hits) if self.reranker else hits
