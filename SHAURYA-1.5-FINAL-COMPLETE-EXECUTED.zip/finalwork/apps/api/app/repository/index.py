from dataclasses import dataclass,asdict
from pathlib import Path
import re
@dataclass
class FileMeta:
    path:str; language:str; bytes:int; lines:int
def language_for(path):
    ext=Path(path).suffix.lower(); return {'.py':'python','.ts':'typescript','.tsx':'tsx','.js':'javascript','.jsx':'jsx','.html':'html','.css':'css','.java':'java','.go':'go','.rs':'rust','.cpp':'cpp','.c':'c','.cs':'csharp','.php':'php','.rb':'ruby','.swift':'swift','.kt':'kotlin','.dart':'dart','.sql':'sql','.sh':'bash','.ps1':'powershell','.json':'json','.yaml':'yaml','.yml':'yaml','.md':'markdown'}.get(ext,'text')
class RepositoryIndex:
    def __init__(self,files): self.files=files; self.metadata=[]; self.symbols=[]; self.imports=[]
    def build(self):
        for f in self.files:
            text=f.content if hasattr(f,'content') else str(f.get('content','')); path=f.path if hasattr(f,'path') else f['path']
            self.metadata.append(FileMeta(path,language_for(path),len(text.encode()),len(text.splitlines())))
            for m in re.finditer(r'(?m)^\s*(?:def|class|function|interface|type)\s+([A-Za-z_$][\w$]*)',text): self.symbols.append({'path':path,'name':m.group(1)})
            for m in re.finditer(r'(?m)^\s*(?:import|from|require\()\s+[\"\']?([^\"\'\s;]+)',text): self.imports.append({'path':path,'target':m.group(1)})
        return self
    def relevant(self,query,limit=12):
        terms={x.lower() for x in re.findall(r'[A-Za-z0-9_]+',query)}
        scored=[]
        for m in self.metadata:
            score=sum(t in m.path.lower() for t in terms)
            score += sum(1 for x in self.symbols if x['path']==m.path and any(t in x['name'].lower() for t in terms))
            score += sum(1 for x in self.imports if x['path']==m.path and any(t in x['target'].lower() for t in terms))
            if score: scored.append((score,m))
        return [asdict(m) for _,m in sorted(scored,key=lambda x:-x[0])[:limit]]
