from dataclasses import dataclass
from pathlib import Path
import csv, io, json, mimetypes, re, zipfile
SUPPORTED={'.pdf','.doc','.docx','.txt','.md','.csv','.xls','.xlsx','.json','.xml','.yaml','.yml','.rtf','.ppt','.pptx','.ods','.odp'}
@dataclass
class DocumentPage: page:int; text:str; reference:str=''
@dataclass
class DocumentResult:
    format:str; metadata:dict; pages:list[DocumentPage]; tables:list[dict]
class UnsupportedDocument(RuntimeError): pass
class DocumentParserUnavailable(RuntimeError): pass
class DocumentParseError(RuntimeError): pass

class DocumentPipeline:
    def __init__(self,parsers=None): self.parsers=parsers or {}; self.parsers.update(self._optional_parsers())
    def detect(self,name,content_type=None):
        ext=Path(name).suffix.lower()
        if ext not in SUPPORTED: raise UnsupportedDocument(f'UNSUPPORTED_DOCUMENT_FORMAT:{ext or "unknown"}')
        expected={'.pdf':{'application/pdf'},'.docx':{'application/vnd.openxmlformats-officedocument.wordprocessingml.document'},'.xlsx':{'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'},'.pptx':{'application/vnd.openxmlformats-officedocument.presentationml.presentation'},'.txt':{'text/plain'},'.md':{'text/markdown','text/plain'},'.csv':{'text/csv','text/plain'},'.json':{'application/json','text/plain'},'.xml':{'application/xml','text/xml','text/plain'},'.yaml':{'application/yaml','text/yaml','text/plain'},'.yml':{'application/yaml','text/yaml','text/plain'},'.rtf':{'application/rtf','text/rtf'}}
        if content_type and ext in expected and content_type not in expected[ext] and not (content_type.startswith('text/') and ext in {'.md','.csv','.json','.xml','.yaml','.yml'}):
            raise UnsupportedDocument(f'MIME_EXTENSION_MISMATCH:{content_type}:{ext}')
        return ext[1:]
    def _optional_parsers(self):
        p={}
        try:
            import pypdf
            def pdf(data):
                reader=pypdf.PdfReader(io.BytesIO(data)); pages=[]
                for i,page in enumerate(reader.pages,1): pages.append(DocumentPage(i,page.extract_text() or '',f'page:{i}'))
                return DocumentResult('pdf',dict(reader.metadata or {}),pages,[])
            p['pdf']=pdf
        except ImportError: pass
        try:
            import docx
            def docx_parser(data):
                d=docx.Document(io.BytesIO(data)); chunks=[]; current=[]; idx=1
                for para in d.paragraphs:
                    if para.text.strip(): chunks.append(DocumentPage(idx,para.text,f'paragraph:{idx}')); idx+=1
                tables=[]
                for t in d.tables: tables.append({'rows':[[c.text for c in r.cells] for r in t.rows]})
                return DocumentResult('docx',{},chunks,tables)
            p['docx']=docx_parser
        except ImportError: pass
        try:
            import openpyxl
            def xlsx_parser(data):
                wb=openpyxl.load_workbook(io.BytesIO(data),read_only=True,data_only=True); pages=[]; tables=[]
                for ws in wb.worksheets:
                    rows=[]; lines=[]
                    for row in ws.iter_rows(values_only=True):
                        vals=['' if v is None else str(v) for v in row]; rows.append(vals); lines.append('\t'.join(vals))
                    pages.append(DocumentPage(len(pages)+1,'\n'.join(lines),f'sheet:{ws.title}')); tables.append({'sheet':ws.title,'rows':rows})
                return DocumentResult('xlsx',{'sheets':wb.sheetnames},pages,tables)
            p['xlsx']=xlsx_parser
        except ImportError: pass
        try:
            from pptx import Presentation
            def pptx_parser(data):
                prs=Presentation(io.BytesIO(data)); pages=[]
                for i,slide in enumerate(prs.slides,1):
                    text='\n'.join(sh.text for sh in slide.shapes if hasattr(sh,'text'))
                    pages.append(DocumentPage(i,text,f'slide:{i}'))
                return DocumentResult('pptx',{},pages,[])
            p['pptx']=pptx_parser
        except ImportError: pass
        try:
            from odf.opendocument import load
            from odf import text as odf_text
            def odf_parser(data):
                with io.BytesIO(data) as bio: doc=load(bio)
                paras=[]
                for pnode in doc.getElementsByType(odf_text.P):
                    txt=''.join(str(x) for x in pnode.childNodes if getattr(x,'data',None));
                    if txt.strip(): paras.append(DocumentPage(len(paras)+1,txt,f'paragraph:{len(paras)+1}'))
                return DocumentResult('odf',{},paras,[])
            p['ods']=odf_parser; p['odp']=odf_parser
        except ImportError: pass
        return p
    def extract(self,name,data):
        fmt=self.detect(name)
        if len(data)>50*1024*1024: raise UnsupportedDocument('DOCUMENT_TOO_LARGE')
        parser=self.parsers.get(fmt)
        if parser:
            try: return parser(data)
            except DocumentParserUnavailable: raise
            except Exception as exc: raise DocumentParseError(f'DOCUMENT_PARSE_ERROR:{fmt}:{type(exc).__name__}') from exc
        if fmt in {'txt','md','json','xml','yaml','yml','csv','rtf'}:
            text=data.decode('utf-8',errors='replace')
            if fmt=='csv':
                rows=list(csv.reader(io.StringIO(text))); return DocumentResult(fmt,{},[DocumentPage(1,'\n'.join('\t'.join(r) for r in rows),'sheet:1')],[{'rows':rows}])
            if fmt=='rtf': text=re.sub(r'\\[a-z]+\d* ?', '', re.sub(r'[{}]','',text))
            return DocumentResult(fmt,{},[DocumentPage(1,text,'page:1')],[])
        raise DocumentParserUnavailable(f'DOCUMENT_PARSER_UNAVAILABLE:{fmt}')

def inspect_archive(data,max_files=500,max_total=100*1024*1024):
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        infos=z.infolist()
        if len(infos)>max_files: raise UnsupportedDocument('ARCHIVE_FILE_COUNT_LIMIT')
        total=sum(i.file_size for i in infos)
        if total>max_total: raise UnsupportedDocument('ARCHIVE_EXPANSION_LIMIT')
        for i in infos:
            n=Path(i.filename)
            if n.is_absolute() or '..' in n.parts: raise UnsupportedDocument('ARCHIVE_PATH_TRAVERSAL')
        return [{'name':i.filename,'size':i.file_size} for i in infos]
