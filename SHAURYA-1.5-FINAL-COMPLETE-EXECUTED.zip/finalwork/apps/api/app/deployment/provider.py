from dataclasses import dataclass
from enum import Enum
class DeploymentState(str,Enum): QUEUED='queued'; BUILDING='building'; TESTING='testing'; SECURITY='security'; PACKAGING='packaging'; DEPLOYING='deploying'; HEALTH_CHECK='health_check'; SUCCEEDED='succeeded'; FAILED='failed'
@dataclass
class DeploymentConfig: project_id:str; provider:str; environment:str='production'
@dataclass
class BuildArtifact: path:str; digest:str; size:int
@dataclass
class Deployment: id:str; status:DeploymentState; url:str|None=None; error:str|None=None
class DeploymentProvider:
    async def deploy(self,artifact,config): raise RuntimeError('DEPLOYMENT_PROVIDER_UNAVAILABLE')
    async def health_check(self,deployment): raise RuntimeError('DEPLOYMENT_PROVIDER_UNAVAILABLE')
