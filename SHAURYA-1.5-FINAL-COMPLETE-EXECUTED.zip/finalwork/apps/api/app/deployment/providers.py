from __future__ import annotations
import httpx
from dataclasses import dataclass
from enum import Enum

class DeploymentError(RuntimeError): pass
class DeploymentState(str,Enum): QUEUED='queued'; BUILDING='building'; DEPLOYING='deploying'; HEALTH_CHECK='health_check'; LIVE='live'; FAILED='failed'; ROLLED_BACK='rolled_back'; CANCELLED='cancelled'
@dataclass
class DeploymentResult:
    state: DeploymentState
    provider: str
    deployment_id: str|None=None
    url: str|None=None
    error: str|None=None

class DeploymentProvider:
    name='unconfigured'
    async def deploy(self, payload:dict)->DeploymentResult: return DeploymentResult(DeploymentState.FAILED,self.name,error='DEPLOYMENT_PROVIDER_UNAVAILABLE')
    async def health_check(self, deployment:DeploymentResult)->DeploymentResult: return DeploymentResult(DeploymentState.FAILED,self.name,deployment.deployment_id,error='DEPLOYMENT_PROVIDER_UNAVAILABLE')
    async def rollback(self, payload:dict)->DeploymentResult: return DeploymentResult(DeploymentState.FAILED,self.name,error='DEPLOYMENT_PROVIDER_UNAVAILABLE')

class HttpDeploymentProvider(DeploymentProvider):
    def __init__(self, base_url='', token='', name='http', timeout=60): self.base_url=base_url.rstrip('/'); self.token=token; self.name=name; self.timeout=timeout
    @property
    def configured(self): return bool(self.base_url and self.token)
    def _headers(self):
        if not self.configured: raise DeploymentError('DEPLOYMENT_PROVIDER_UNAVAILABLE')
        return {'Authorization':f'Bearer {self.token}','Content-Type':'application/json'}
    async def _post(self,path,payload):
        if not self.configured: raise DeploymentError('DEPLOYMENT_PROVIDER_UNAVAILABLE')
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as c: r=await c.post(self.base_url+path,headers=self._headers(),json=payload)
        except httpx.HTTPError as e: raise DeploymentError(f'DEPLOYMENT_NETWORK_ERROR:{type(e).__name__}') from e
        if r.status_code>=400: raise DeploymentError(f'DEPLOYMENT_PROVIDER_ERROR:{r.status_code}')
        return r.json()
    async def deploy(self,payload):
        try:
            data=await self._post('/deployments',payload); return DeploymentResult(DeploymentState.LIVE,self.name,str(data.get('id','')),data.get('url'))
        except DeploymentError as e: return DeploymentResult(DeploymentState.FAILED,self.name,error=str(e))
    async def health_check(self,deployment):
        if not deployment.url: return DeploymentResult(DeploymentState.FAILED,self.name,deployment.deployment_id,error='DEPLOYMENT_HEALTHCHECK_FAILED')
        try:
            async with httpx.AsyncClient(timeout=15,follow_redirects=True) as c: r=await c.get(deployment.url)
            return DeploymentResult(DeploymentState.LIVE if r.status_code<400 else DeploymentState.FAILED,self.name,deployment.deployment_id,deployment.url,None if r.status_code<400 else 'DEPLOYMENT_HEALTHCHECK_FAILED')
        except httpx.HTTPError as e: return DeploymentResult(DeploymentState.FAILED,self.name,deployment.deployment_id,deployment.url,'DEPLOYMENT_HEALTHCHECK_FAILED')
    async def rollback(self,payload):
        try:
            data=await self._post('/deployments/rollback',payload); return DeploymentResult(DeploymentState.ROLLED_BACK,self.name,str(data.get('id','')),data.get('url'))
        except DeploymentError as e: return DeploymentResult(DeploymentState.FAILED,self.name,error=str(e))
