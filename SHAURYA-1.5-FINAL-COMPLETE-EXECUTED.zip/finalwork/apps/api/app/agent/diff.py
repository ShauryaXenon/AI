import difflib

def unified(old,new,path):
    return ''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=path,tofile=path))
