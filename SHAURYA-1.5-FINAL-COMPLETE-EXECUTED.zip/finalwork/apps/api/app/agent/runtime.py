from __future__ import annotations
import asyncio,json,shutil,tempfile,time
from pathlib import Path
from datetime import datetime
from sqlalchemy import select
from .engine import AgentBudget,AgentState,AgentLimits
from .events import event_bus
from .model_loop import run_tool_loop,ModelLoopError
from ..db.models import ProjectFile,FileVersion,ToolCall,AuditLog,TaskEventRecord,ModelRequest,Usage,SecurityFindingRecord
from ..tools.agent_handlers import AgentToolHandlers
from ..review.engine import SecurityReview
from ..repository.index import RepositoryIndex
from .context import BoundedRepositoryContext
from .state import TaskPaused,TaskCancelled
from ..research.providers import ResearchEngine,HttpSearchProvider
from ..vision.provider import VisionProvider
from ..config import settings

class AgentRuntime:
    def __init__(self,db_factory,sandbox,limits=None,should_stop=None):
        self.db_factory=db_factory; self.sandbox=sandbox; self.budget=AgentBudget(limits); self.should_stop=should_stop
    async def emit(self,task_id,kind,**payload):
        event={'type':kind,'timestamp':datetime.utcnow().isoformat()+'Z','task_id':task_id,'subsystem':kind.split('.')[0],'status':'error' if payload.get('error') else 'ok',**payload}
        accepted=await event_bus.publish(task_id,event)
        if not accepted: return

        try:
            async with self.db_factory() as db:
                db.add(TaskEventRecord(task_id=task_id,event_type=kind,payload=payload)); await db.commit()
        except Exception: pass
    async def _materialize(self,files,root):
        for f in files:
            p=(root/f.path).resolve();
            if root not in p.parents and p!=root: raise ValueError('PATH_TRAVERSAL_BLOCKED')
            p.parent.mkdir(parents=True,exist_ok=True); p.write_text(f.content,encoding='utf-8')
    async def _sync(self,db,task,root):
        existing=(await db.execute(select(ProjectFile).where(ProjectFile.project_id==task.project_id))).scalars().all(); by_path={f.path:f for f in existing}; changed=[]
        for p in root.rglob('*'):
            if not p.is_file(): continue
            rel=str(p.relative_to(root)).replace('\\','/');
            try: content=p.read_text(encoding='utf-8')
            except UnicodeDecodeError: continue
            if len(content)>5_000_000: continue
            f=by_path.get(rel)
            if not f:
                f=ProjectFile(project_id=task.project_id,path=rel,content=content,version=1); db.add(f); await db.flush(); db.add(FileVersion(file_id=f.id,version=1,content=content)); changed.append({'path':rel,'action':'created','version':1})
            elif f.content!=content:
                f.version+=1; f.content=content; f.updated_at=datetime.utcnow(); db.add(FileVersion(file_id=f.id,version=f.version,content=content)); changed.append({'path':rel,'action':'updated','version':f.version})
        for item in changed: await self.emit(task.id,'file.changed',**item)
        return changed
    async def run(self,task,files):
        task.status='running'; task.current_step='planning'; task.updated_at=datetime.utcnow()
        await self.emit(task.id,'task.started',step='planning')
        root=Path(tempfile.mkdtemp(prefix=f'shaurya-agent-{task.id}-'))
        started=time.perf_counter(); limits=self.budget.limits
        try:
            await self._materialize(files,root)
            index=RepositoryIndex(files).build()
            request=str((task.result or {}).get('request',''))
            context=BoundedRepositoryContext(files).build(request)
            messages=[{'role':'system','content':'''You are the SHAURYA 1.5 software engineering agent. Work only through the provided tools. Never claim an operation succeeded unless its tool result says so. Inspect before editing. Make minimal, recoverable changes. After edits run build/tests when available. If execution is unavailable, report it honestly. Do not expose hidden reasoning; return concise engineering summaries.'''},{'role':'user','content':json.dumps({'task':request,'repository_context':context})}]
            research=ResearchEngine(HttpSearchProvider(settings.research_search_url,settings.research_api_key) if settings.research_search_url else None)
            vision=VisionProvider(settings.vision_base_url,settings.vision_api_key,settings.vision_model)
            handlers=AgentToolHandlers(root,self.sandbox,research=research,vision=vision)
            await self.emit(task.id,'task.planning',repository_files=len(index.metadata),request=request)
            async def loop_event(kind, **payload):
                await self.emit(task.id, kind, **payload)
            final,trace,usage,provider,model_trace=await run_tool_loop(messages,handlers,max_turns=limits.max_iterations,max_tool_calls=limits.max_tool_calls,max_seconds=limits.max_seconds,max_tokens=limits.max_tokens,should_stop=self.should_stop,event_callback=loop_event)
            task.iteration=len(trace)
            task.current_step='verifying'; task.status='verifying'; await self.emit(task.id,'verification.started')
            async with self.db_factory() as db:
                changes=await self._sync(db,task,root)
                for item in trace:
                    db.add(ToolCall(task_id=task.id,name=item['name'],status='completed' if item['result'].get('ok') else 'failed',input=item['arguments'],output=item['result']))
                
                for mr in model_trace:
                    db.add(ModelRequest(user_id=task.user_id,provider=mr['provider'],model=mr['model'],status=mr['status'],input_tokens=mr['input_tokens'],output_tokens=mr['output_tokens'],duration_ms=mr['duration_ms']))
                db.add(Usage(user_id=task.user_id,metric='input_tokens',amount=usage['input_tokens']))
                db.add(Usage(user_id=task.user_id,metric='output_tokens',amount=usage['output_tokens']))
                findings=SecurityReview().review((await db.execute(select(ProjectFile).where(ProjectFile.project_id==task.project_id))).scalars().all())
                for finding in findings:
                    db.add(SecurityFindingRecord(task_id=task.id,project_id=task.project_id,severity=finding.get('severity','INFO'),category=finding.get('category','security'),message=finding.get('message',''),path=finding.get('path',''),line=finding.get('line'),evidence=finding.get('evidence','')))
                if handlers.last_execution is not None:
                    ex=handlers.last_execution
                    db.add(__import__('apps.api.app.db.models',fromlist=['Execution']).Execution(user_id=task.user_id,project_id=task.project_id,command=getattr(ex,'command','agent'),status=ex.status,exit_code=ex.exit_code,stdout=ex.stdout,stderr=ex.stderr,duration_ms=ex.duration_ms,image=ex.image))
                sandbox_ok=handlers.last_execution is not None and handlers.last_execution.status=='passed'
                unavailable=any(str(x['result'].get('error','')).startswith('SANDBOX_RUNTIME_UNAVAILABLE') for x in trace)
                task.result={'request':request,'summary':final,'provider':provider.name,'model':provider.model,'tool_calls':trace,'file_changes':changes,'usage':usage,'model_requests':model_trace,'security_findings':findings,'sandbox_verified':sandbox_ok,'sandbox_unavailable':unavailable}
                task.current_step='completed' if sandbox_ok else 'verification_incomplete'; task.status='completed' if sandbox_ok else 'failed'
                if not sandbox_ok and unavailable: task.error='SANDBOX_RUNTIME_UNAVAILABLE'
                await db.commit()
            await self.emit(task.id,'verification.completed',passed=sandbox_ok,security_findings=len(findings))
            await self.emit(task.id,'task.completed' if sandbox_ok else 'task.failed',result=task.result,error=task.error)
        except ModelLoopError as exc:
            if self.should_stop and self.should_stop():
                task.status='paused' if task.id in getattr(__import__('apps.api.app.main',fromlist=['paused_tasks']),'paused_tasks',set()) else 'cancelled'
                task.error='TASK_PAUSED' if task.status=='paused' else 'TASK_CANCELLED'
                task.current_step='paused' if task.status=='paused' else 'cancelled'
                await self.emit(task.id,'task.controlled_stop',status=task.status,error=task.error)
            else:
                task.status='failed'; task.error=str(exc); task.current_step='failed'; await self.emit(task.id,'task.failed',error=str(exc))
        except asyncio.CancelledError:
            task.status='cancelled'; task.error='TASK_CANCELLED'; await self.emit(task.id,'task.failed',error='TASK_CANCELLED'); raise
        except Exception as exc:
            task.status='failed'; task.error=f'{type(exc).__name__}: {exc}'; task.current_step='failed'; await self.emit(task.id,'task.failed',error=task.error)
        finally: shutil.rmtree(root,ignore_errors=True)
