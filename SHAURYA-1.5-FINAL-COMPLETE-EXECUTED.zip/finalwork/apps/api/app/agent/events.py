import asyncio, hashlib, json
from collections import defaultdict
class TaskEventBus:
    def __init__(self): self._queues=defaultdict(list); self._seen=set()
    async def publish(self,task_id,event):
        raw=json.dumps([task_id,event.get("type"),event.get("payload",event)],sort_keys=True,default=str)
        eid=hashlib.sha256(raw.encode()).hexdigest()[:32]
        if eid in self._seen: return False
        self._seen.add(eid)
        for q in list(self._queues.get(task_id,[])): await q.put({**event,'event_id':eid})
        return True
    async def subscribe(self,task_id):
        q=asyncio.Queue(); self._queues[task_id].append(q)
        try:
            while True: yield await q.get()
        finally:
            if q in self._queues.get(task_id,[]): self._queues[task_id].remove(q)
event_bus=TaskEventBus()
