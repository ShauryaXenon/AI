from __future__ import annotations
import re
from pathlib import Path
from ..repository.index import RepositoryIndex

class BoundedRepositoryContext:
    def __init__(self, files, max_files=24, max_chars=60000):
        self.files=files; self.max_files=max_files; self.max_chars=max_chars
    def build(self, query=''):
        idx=RepositoryIndex(self.files).build()
        relevant=idx.relevant(query,self.max_files) if query else [x.__dict__ for x in idx.metadata[:self.max_files]]
        selected=[]; budget=self.max_chars
        by={f.path:f for f in self.files}
        for meta in relevant:
            f=by.get(meta['path'])
            if not f: continue
            text=f.content if hasattr(f,'content') else str(f.get('content',''))
            excerpt=text[:min(len(text),max(1000,budget))]
            if not excerpt: continue
            selected.append({'path':meta['path'],'language':meta['language'],'bytes':meta['bytes'],'excerpt':excerpt,'trust':'UNTRUSTED_REPOSITORY_DATA'})
            budget-=len(excerpt)
            if budget<=0: break
        return {'tree':[x.__dict__ for x in idx.metadata[:self.max_files]],'relevant_files':selected,'symbols':idx.symbols[:200],'imports':idx.imports[:300]}
