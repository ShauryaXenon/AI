from dataclasses import dataclass, field
from datetime import datetime, timezone

@dataclass
class AgentLimits:
    max_iterations:int=12
    max_seconds:int=900
    max_tool_calls:int=80
    max_file_changes:int=120
    max_tokens:int=120_000

@dataclass
class AgentState:
    task_id:str
    status:str='queued'
    step:str='planning'
    iteration:int=0
    tool_calls:int=0
    file_changes:int=0
    tokens:int=0
    started_at:datetime=field(default_factory=lambda: datetime.now(timezone.utc))
    error:str|None=None

class AgentBudget:
    def __init__(self, limits:AgentLimits|None=None): self.limits=limits or AgentLimits()
    def allow(self,s:AgentState)->tuple[bool,str|None]:
        if s.iteration>=self.limits.max_iterations:return False,'ITERATION_LIMIT'
        if s.tool_calls>=self.limits.max_tool_calls:return False,'TOOL_BUDGET_EXCEEDED'
        if s.file_changes>=self.limits.max_file_changes:return False,'FILE_CHANGE_LIMIT'
        if s.tokens>=self.limits.max_tokens:return False,'TOKEN_BUDGET_EXCEEDED'
        elapsed=(datetime.now(timezone.utc)-s.started_at).total_seconds()
        if elapsed>=self.limits.max_seconds:return False,'TASK_TIME_LIMIT'
        return True,None
    def next_iteration(self,s): s.iteration+=1; return self.allow(s)

PLAN_STEPS=['planning','researching','reading','editing','building','testing','debugging','security_review','verifying','completed']

def useful_progress(step:str, **extra): return {'type':f'task.{step}','step':step,**extra}
