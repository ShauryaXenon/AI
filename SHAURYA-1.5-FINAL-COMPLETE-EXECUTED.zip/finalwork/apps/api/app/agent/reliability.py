from __future__ import annotations
from dataclasses import dataclass
import json
from .protocol import ToolCallRequest

@dataclass(frozen=True)
class ReliabilityError:
    code: str
    retryable: bool
    detail: str=''

def normalize_tool_call(call_id, name, raw):
    if not name: return None, ReliabilityError('UNKNOWN_TOOL',False)
    if not isinstance(raw,dict):
        return ToolCallRequest(call_id,name,{'_malformed':True,'raw':str(raw)[:4000]}), ReliabilityError('MALFORMED_TOOL_ARGUMENTS',True)
    return ToolCallRequest(call_id,name,raw), None

def tool_result_event(name,result):
    err=result.get('error') if isinstance(result,dict) else 'INVALID_TOOL_RESULT'
    return {'tool':name,'ok':bool(isinstance(result,dict) and result.get('ok')),'error_code':err}
