from __future__ import annotations
import json, time, httpx
from ..config import settings
from ..providers import primary, fallback, ProviderError
from .protocol import parse_tool_calls, tool_schemas

class ModelLoopError(ProviderError): pass

async def model_turn(messages, tools, timeout=None):
    providers=[primary]+([fallback] if settings.model_fallback_enabled else [])
    errors=[]
    for provider in providers:
        if not provider.configured: continue
        payload={'model':provider.model,'messages':messages,'temperature':settings.model_temperature,'max_tokens':settings.model_max_output_tokens}
        if tools:
            payload['tools']=tools; payload['tool_choice']='auto'
        started=time.perf_counter()
        try:
            async with httpx.AsyncClient(timeout=httpx.Timeout(timeout or settings.request_timeout_seconds,connect=15.0)) as client:
                r=await client.post(f'{provider.base_url}/chat/completions',headers={'Authorization':f'Bearer {provider.api_key}','Content-Type':'application/json'},json=payload)
                if r.status_code>=400: raise ModelLoopError(f'{provider.name}: HTTP {r.status_code}: {r.text[:500]}')
                obj=r.json(); choice=(obj.get('choices') or [{}])[0]; msg=choice.get('message') or {}
                usage=obj.get('usage') or {}
                return provider,msg,usage,obj,int((time.perf_counter()-started)*1000)
        except (httpx.HTTPError,ValueError,ModelLoopError) as exc:
            errors.append(str(exc)[:500])
            continue
    raise ModelLoopError('MODEL_PROVIDER_UNAVAILABLE' if not errors else 'MODEL_PROVIDER_FAILED:'+ '; '.join(errors))

async def run_tool_loop(messages, handlers, max_turns=12, max_tool_calls=80, max_seconds=900, max_tokens=120000, should_stop=None, event_callback=None):
    tools=tool_schemas(handlers.registry)
    calls_used=0; turns=0; usage={'input_tokens':0,'output_tokens':0}; trace=[]; model_trace=[]
    started=time.monotonic()
    while turns<max_turns:
        if should_stop and should_stop(): raise ModelLoopError('TASK_CANCELLED')
        if time.monotonic()-started >= max_seconds: raise ModelLoopError('TASK_TIME_LIMIT')
        if usage['input_tokens']+usage['output_tokens'] >= max_tokens: raise ModelLoopError('TOKEN_BUDGET_EXCEEDED')
        turns+=1
        provider,msg,u,raw,duration_ms=await model_turn(messages,tools)
        if event_callback:
            await event_callback('model.completed', provider=provider.name, model=provider.model, duration_ms=duration_ms)
        inp=int(u.get('prompt_tokens',0)); out=int(u.get('completion_tokens',0))
        usage['input_tokens']+=inp; usage['output_tokens']+=out
        model_trace.append({'provider':provider.name,'model':provider.model,'input_tokens':inp,'output_tokens':out,'duration_ms':duration_ms,'status':'completed'})
        if msg.get('tool_calls'):
            messages.append({'role':'assistant','content':msg.get('content'),'tool_calls':msg.get('tool_calls')})
        else:
            messages.append({'role':'assistant','content':msg.get('content','')})
        calls=parse_tool_calls(msg)
        if not calls: return msg.get('content',''),trace,usage,provider,model_trace
        for call in calls:
            calls_used+=1
            if calls_used>max_tool_calls: raise ModelLoopError('TOOL_BUDGET_EXCEEDED')
            if event_callback:
                await event_callback('tool.started', name=call.name, call_id=call.call_id)
            result=await handlers.execute(call.name,call.arguments)
            if not isinstance(result,dict): result={'ok':False,'error':'INVALID_TOOL_RESULT'}
            if event_callback:
                await event_callback('tool.completed', name=call.name, call_id=call.call_id, ok=bool(result.get('ok')))
            trace.append({'call_id':call.call_id,'name':call.name,'arguments':call.arguments,'result':result})
            messages.append({'role':'tool','tool_call_id':call.call_id,'content':json.dumps(result,default=str)[:settings.max_tool_output_bytes]})
    raise ModelLoopError('MODEL_ITERATION_LIMIT')
