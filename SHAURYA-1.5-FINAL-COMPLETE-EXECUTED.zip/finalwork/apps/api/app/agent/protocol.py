from __future__ import annotations
from dataclasses import dataclass
from typing import Any

@dataclass
class ToolCallRequest:
    call_id: str
    name: str
    arguments: dict[str, Any]

def tool_schemas(registry):
    schemas=[]
    props={
      'list_files': {},
      'read_file': {'path': {'type':'string'}},
      'search_files': {'term': {'type':'string'}},
      'create_file': {'path': {'type':'string'},'content': {'type':'string'}},
      'write_file': {'path': {'type':'string'},'content': {'type':'string'}},
      'edit_file': {'path': {'type':'string'},'old': {'type':'string'},'new': {'type':'string'}},
      'delete_file': {'path': {'type':'string'}},
      'rename_file': {'path': {'type':'string'},'new_path': {'type':'string'}},
      'get_project_structure': {},
      'run_command': {'command': {'type':'string'}},
      'run_build': {}, 'run_tests': {}, 'get_execution_result': {'execution_id': {'type':'string'}},
      'get_git_status': {}, 'get_git_diff': {},
    }
    required={'read_file':['path'],'search_files':['term'],'create_file':['path','content'],'write_file':['path','content'],'edit_file':['path','old','new'],'delete_file':['path'],'rename_file':['path','new_path'],'run_command':['command'],'get_execution_result':['execution_id']}
    for name,spec in registry.items():
        p=props.get(name,{})
        schemas.append({'type':'function','function':{'name':name,'description':spec.description,'parameters':{'type':'object','properties':p,'required':required.get(name,[]),'additionalProperties':False}}})
    return schemas

def parse_tool_calls(message:dict[str,Any]):
    calls=[]
    for c in message.get('tool_calls') or []:
        c=c if isinstance(c,dict) else {}
        fn=c.get('function') or {}; raw=fn.get('arguments') or '{}'
        import json
        try: args=json.loads(raw)
        except Exception: args=None
        if not isinstance(args,dict):
            calls.append(ToolCallRequest(str(c.get('id','')),str(fn.get('name','')),{'_malformed':True,'raw':str(raw)[:4000]})); continue
        calls.append(ToolCallRequest(str(c.get('id','')),str(fn.get('name','')),args))
    return calls
