from __future__ import annotations
from dataclasses import dataclass

TERMINAL={'completed','failed','cancelled','budget_exceeded'}
ALLOWED={
 'queued': {'running','cancelled'},
 'running': {'paused','verifying','completed','failed','cancelled','budget_exceeded'},
 'paused': {'queued','cancelled'},
 'verifying': {'completed','failed'},
 'failed': {'queued'},
 'completed': set(), 'cancelled': set(), 'budget_exceeded': set(),
}

@dataclass(frozen=True)
class TransitionResult:
    ok: bool
    error: str|None=None

def transition(current: str, target: str) -> TransitionResult:
    if target in ALLOWED.get(current,set()): return TransitionResult(True)
    return TransitionResult(False, f'INVALID_TASK_TRANSITION:{current}->{target}')

class TaskPaused(Exception): pass
class TaskCancelled(Exception): pass
