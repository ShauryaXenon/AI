import re

def detect_runtime(path,language=None):
    names={p.name for p in path.iterdir() if p.is_file()}
    if 'package.json' in names: return 'node:22-alpine'
    if 'pyproject.toml' in names or 'requirements.txt' in names: return 'python:3.13-alpine'
    if 'Cargo.toml' in names: return 'rust:1-alpine'
    if 'go.mod' in names: return 'golang:1.25-alpine'
    if 'pom.xml' in names: return 'maven:3.9-eclipse-temurin-21'
    if any(n.endswith('.csproj') for n in names): return 'mcr.microsoft.com/dotnet/sdk:9.0'
    return {'python':'python:3.13-alpine','node':'node:22-alpine','javascript':'node:22-alpine'}.get((language or '').lower(),'alpine:3.22')

def command_allowed(command):
    if not command.strip() or len(command)>1000: return False
    banned=[r'(^|\s)docker(\s|$)',r'(^|\s)nsenter(\s|$)',r'/proc',r'/sys',r'--privileged',r'\bcurl\s+[^\n]*(169\.254|localhost)',r'\bwget\s+[^\n]*(169\.254|localhost)']
    return not any(re.search(p,command,re.I) for p in banned)
