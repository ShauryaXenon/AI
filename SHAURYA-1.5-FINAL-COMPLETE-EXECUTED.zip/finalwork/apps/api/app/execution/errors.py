import re

def normalize_error(stderr:str,stdout:str='',command:str=''):
    text=(stderr or stdout).strip(); m=re.search(r'([^\s:]+\.(?:py|js|ts|tsx|jsx|java|go|rs|cs)):(\d+)(?::(\d+))?',text)
    return {'error_type':('SyntaxError' if 'SyntaxError' in text else 'TypeError' if 'TypeError' in text else 'ModuleNotFound' if 'ModuleNotFound' in text or 'Cannot find module' in text else 'BuildError'),'file':m.group(1) if m else None,'line':int(m.group(2)) if m else None,'column':int(m.group(3)) if m and m.group(3) else None,'message':text[:2000],'stack':text[:4000],'command':command,'suggested_context':[]}
