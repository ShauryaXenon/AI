from pathlib import Path

def detect_commands(path:Path):
    names={p.name for p in path.iterdir()}
    if 'package.json' in names: return {'build':'npm run build','test':'npm test'}
    if 'pyproject.toml' in names or 'requirements.txt' in names: return {'build':None,'test':'pytest -q'}
    if 'Cargo.toml' in names: return {'build':'cargo build','test':'cargo test'}
    if 'go.mod' in names: return {'build':'go build ./...','test':'go test ./...'}
    if 'pom.xml' in names: return {'build':'mvn -q -DskipTests package','test':'mvn -q test'}
    if any(p.name.endswith('.csproj') for p in path.iterdir()): return {'build':'dotnet build','test':'dotnet test'}
    return {'build':None,'test':None}
