import asyncio, json, os, shutil, tempfile, time
from dataclasses import dataclass,asdict
from pathlib import Path
from .runtime import detect_runtime, command_allowed

@dataclass
class ExecutionResult:
    status:str; exit_code:int|None; stdout:str; stderr:str; duration_ms:int; execution_id:str; image:str

class SandboxUnavailable(RuntimeError): pass

class DockerSandbox:
    def __init__(self,timeout=120,memory='512m',cpus='1.0',pids=128,network='none'):
        self.timeout=timeout; self.memory=memory; self.cpus=cpus; self.pids=pids; self.network=network
    def available(self):
        return shutil.which('docker') is not None
    async def run(self,project_path:Path,command:str,language=None):
        if shutil.which('docker') is None: raise SandboxUnavailable('SANDBOX_RUNTIME_UNAVAILABLE')
        if not command_allowed(command): return ExecutionResult('rejected',None,'','Command not allowed by sandbox policy',0,'','')
        import uuid
        eid=str(uuid.uuid4()); image=detect_runtime(project_path,language)
        start=time.perf_counter()
        proc=await asyncio.create_subprocess_exec('docker','run','--rm','--network',self.network,'--memory',self.memory,'--cpus',self.cpus,'--pids-limit',str(self.pids),'--cap-drop','ALL','--security-opt','no-new-privileges','-e','HOME=/tmp','-v',f'{project_path.resolve()}:/workspace:rw','-w','/workspace',image,'sh','-lc',command,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
        try: out,err=await asyncio.wait_for(proc.communicate(),timeout=self.timeout)
        except asyncio.TimeoutError:
            proc.kill(); await proc.communicate(); return ExecutionResult('timeout',None,'','Execution timed out',int((time.perf_counter()-start)*1000),eid,image)
        return ExecutionResult('passed' if proc.returncode==0 else 'failed',proc.returncode,out.decode(errors='replace'),err.decode(errors='replace'),int((time.perf_counter()-start)*1000),eid,image)
