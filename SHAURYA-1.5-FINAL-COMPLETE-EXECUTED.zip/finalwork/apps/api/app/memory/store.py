from dataclasses import dataclass,asdict
from datetime import datetime,timezone
import uuid
@dataclass
class MemoryItem:
    id:str; scope:str; owner_id:str; content:str; source:str; created_at:str; updated_at:str
class MemoryStore:
    def __init__(self): self.items={}
    def add(self,owner_id,scope,content,source):
        now=datetime.now(timezone.utc).isoformat(); item=MemoryItem(str(uuid.uuid4()),scope,owner_id,content,source,now,now); self.items[item.id]=item; return item
    def list(self,owner_id,scope=None): return [asdict(x) for x in self.items.values() if x.owner_id==owner_id and (scope is None or x.scope==scope)]
    def get(self,owner_id,item_id):
        item=self.items.get(item_id)
        if not item or item.owner_id!=owner_id: raise PermissionError('MEMORY_ACCESS_DENIED')
        return asdict(item)
