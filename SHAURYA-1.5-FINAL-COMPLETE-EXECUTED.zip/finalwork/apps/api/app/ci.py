from __future__ import annotations
from enum import Enum
from dataclasses import dataclass

class CIState(str, Enum): QUEUED='queued'; RUNNING='running'; PASSED='passed'; FAILED='failed'; CANCELLED='cancelled'; UNAVAILABLE='unavailable'
@dataclass
class CIResult:
    state: CIState
    provider: str
    run_id: str|None=None
    url: str|None=None
    error: str|None=None

class CIProvider:
    async def verify(self, project_id: str, commit: str|None=None) -> CIResult:
        return CIResult(CIState.UNAVAILABLE,'unconfigured',error='CI_PROVIDER_UNAVAILABLE')

class HttpCIProvider(CIProvider):
    def __init__(self,base_url='',token='',name='http',timeout=30): self.base_url=base_url.rstrip('/'); self.token=token; self.name=name; self.timeout=timeout
    @property
    def configured(self): return bool(self.base_url and self.token)
    async def verify(self,project_id,commit=None):
        if not self.configured: return CIResult(CIState.UNAVAILABLE,self.name,error='CI_PROVIDER_UNAVAILABLE')
        import httpx
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as c:
                r=await c.post(self.base_url+'/verify',headers={'Authorization':f'Bearer {self.token}'},json={'project_id':project_id,'commit':commit})
            if r.status_code>=400:return CIResult(CIState.FAILED,self.name,error=f'CI_PROVIDER_ERROR:{r.status_code}')
            d=r.json(); return CIResult(CIState(d.get('status',CIState.RUNNING.value)),self.name,d.get('id'),d.get('url'),d.get('error'))
        except Exception as e:return CIResult(CIState.FAILED,self.name,error=f'CI_NETWORK_ERROR:{type(e).__name__}')
