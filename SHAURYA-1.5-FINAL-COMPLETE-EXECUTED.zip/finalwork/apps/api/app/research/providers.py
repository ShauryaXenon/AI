from dataclasses import dataclass
from datetime import datetime, timezone
from hashlib import sha256
from typing import Protocol
from urllib.parse import urlparse
import ipaddress, socket
import httpx
from ..config import settings

@dataclass(frozen=True)
class ResearchSource:
    id: str
    url: str
    title: str
    domain: str
    retrieved_at: str
    content: str
    content_hash: str
    @classmethod
    def create(cls, url: str, title: str, content: str, source: str='web'):
        digest=sha256((content or '').encode('utf-8')).hexdigest()
        return cls(digest[:16], url, title or url, urlparse(url).netloc or source,
                   datetime.now(timezone.utc).isoformat(), content or '', digest)

class SearchProvider(Protocol):
    async def search(self, query: str, limit: int=5) -> list[ResearchSource]: ...

class ResearchUnavailable(RuntimeError): pass


def _safe_public_url(url: str) -> bool:
    p=urlparse(url)
    if p.scheme not in {'http','https'} or not p.hostname: return False
    host=p.hostname
    try:
        infos=socket.getaddrinfo(host, None)
        for info in infos:
            ip=ipaddress.ip_address(info[4][0])
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast:
                return False
    except (OSError, ValueError):
        return False
    return True

class HttpSearchProvider:
    """Provider-neutral HTTP adapter. The configured service must return JSON results with url/title/content."""
    def __init__(self, endpoint: str, api_key: str=''):
        self.endpoint=endpoint.rstrip('/'); self.api_key=api_key
    @property
    def configured(self): return bool(self.endpoint)
    async def search(self, query: str, limit: int=5):
        if not self.configured: raise ResearchUnavailable('RESEARCH_PROVIDER_UNAVAILABLE')
        headers={'Accept':'application/json'}
        if self.api_key: headers['Authorization']=f'Bearer {self.api_key}'
        try:
            async with httpx.AsyncClient(timeout=20, follow_redirects=True) as c:
                r=await c.post(self.endpoint,json={'query':query,'limit':max(1,min(limit,20))},headers=headers)
                r.raise_for_status(); payload=r.json()
        except (httpx.HTTPError, ValueError) as exc:
            raise ResearchUnavailable(f'RESEARCH_PROVIDER_ERROR:{type(exc).__name__}') from exc
        items=payload.get('results',payload if isinstance(payload,list) else [])
        out=[]
        for item in items:
            url=str(item.get('url',''))
            if not _safe_public_url(url): continue
            out.append(ResearchSource.create(url,str(item.get('title','')),str(item.get('content','')),str(item.get('source','web'))))
        return out

class ResearchEngine:
    def __init__(self, search_provider=None): self.search_provider=search_provider
    async def search(self,query,limit=5):
        if not self.search_provider: raise ResearchUnavailable('RESEARCH_PROVIDER_UNAVAILABLE')
        return await self.search_provider.search(query,limit)
    async def open(self,url):
        if not _safe_public_url(url): raise ResearchUnavailable('UNSAFE_URL')
        try:
            async with httpx.AsyncClient(timeout=20,follow_redirects=True,headers={'User-Agent':'SHAURYA-Research/1.0'}) as c:
                r=await c.get(url); r.raise_for_status(); text=r.text[:2_000_000]
        except httpx.HTTPError as exc: raise ResearchUnavailable(f'PAGE_RETRIEVAL_FAILED:{type(exc).__name__}') from exc
        title=urlparse(url).netloc
        return ResearchSource.create(str(r.url),title,text)
    def dedupe(self,sources):
        seen=set(); out=[]
        for s in sources:
            key=(s.url,s.content_hash)
            if key in seen: continue
            seen.add(key); out.append(s)
        return out

research=ResearchEngine(HttpSearchProvider(settings.research_search_url,settings.research_api_key) if settings.research_search_url else None)
