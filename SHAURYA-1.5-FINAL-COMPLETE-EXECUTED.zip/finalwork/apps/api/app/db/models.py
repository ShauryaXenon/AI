from datetime import datetime
from uuid import uuid4
from sqlalchemy import DateTime, ForeignKey, Integer, String, Text, Boolean, JSON, Index, Float
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship

class Base(DeclarativeBase): pass

def uid(): return str(uuid4())
def now(): return datetime.utcnow()

class User(Base):
    __tablename__='users'
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    email: Mapped[str]=mapped_column(String(320),unique=True,index=True)
    password_hash: Mapped[str]=mapped_column(String(255))
    created_at: Mapped[datetime]=mapped_column(DateTime,default=now)

class Session(Base):
    __tablename__='sessions'
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    user_id: Mapped[str]=mapped_column(ForeignKey('users.id',ondelete='CASCADE'),index=True)
    token_hash: Mapped[str]=mapped_column(String(64),unique=True,index=True)
    expires_at: Mapped[datetime]=mapped_column(DateTime,index=True)
    created_at: Mapped[datetime]=mapped_column(DateTime,default=now)

class Project(Base):
    __tablename__='projects'
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    owner_id: Mapped[str]=mapped_column(ForeignKey('users.id',ondelete='CASCADE'),index=True)
    name: Mapped[str]=mapped_column(String(120))
    description: Mapped[str]=mapped_column(Text,default='')
    created_at: Mapped[datetime]=mapped_column(DateTime,default=now)
    updated_at: Mapped[datetime]=mapped_column(DateTime,default=now,onupdate=now)

class ProjectFile(Base):
    __tablename__='files'
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    project_id: Mapped[str]=mapped_column(ForeignKey('projects.id',ondelete='CASCADE'),index=True)
    path: Mapped[str]=mapped_column(String(1000))
    content: Mapped[str]=mapped_column(Text,default='')
    version: Mapped[int]=mapped_column(Integer,default=1)
    created_at: Mapped[datetime]=mapped_column(DateTime,default=now)
    updated_at: Mapped[datetime]=mapped_column(DateTime,default=now,onupdate=now)
    __table_args__=(Index('ix_files_project_path','project_id','path',unique=True),)

class FileVersion(Base):
    __tablename__='file_versions'
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    file_id: Mapped[str]=mapped_column(ForeignKey('files.id',ondelete='CASCADE'),index=True)
    version: Mapped[int]=mapped_column(Integer)
    content: Mapped[str]=mapped_column(Text)
    created_at: Mapped[datetime]=mapped_column(DateTime,default=now)

class Conversation(Base):
    __tablename__='conversations'
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    user_id: Mapped[str]=mapped_column(ForeignKey('users.id',ondelete='CASCADE'),index=True)
    project_id: Mapped[str|None]=mapped_column(ForeignKey('projects.id',ondelete='SET NULL'),nullable=True,index=True)
    title: Mapped[str]=mapped_column(String(200),default='New conversation')
    created_at: Mapped[datetime]=mapped_column(DateTime,default=now)
    updated_at: Mapped[datetime]=mapped_column(DateTime,default=now,onupdate=now)

class Message(Base):
    __tablename__='messages'
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    conversation_id: Mapped[str]=mapped_column(ForeignKey('conversations.id',ondelete='CASCADE'),index=True)
    role: Mapped[str]=mapped_column(String(20))
    content: Mapped[str]=mapped_column(Text)
    created_at: Mapped[datetime]=mapped_column(DateTime,default=now)

class Task(Base):
    __tablename__='tasks'
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    user_id: Mapped[str]=mapped_column(ForeignKey('users.id',ondelete='CASCADE'),index=True)
    project_id: Mapped[str]=mapped_column(ForeignKey('projects.id',ondelete='CASCADE'),index=True)
    status: Mapped[str]=mapped_column(String(30),default='queued')
    current_step: Mapped[str]=mapped_column(String(100),default='planning')
    iteration: Mapped[int]=mapped_column(Integer,default=0)
    result: Mapped[dict|None]=mapped_column(JSON,nullable=True)
    error: Mapped[str|None]=mapped_column(Text,nullable=True)
    created_at: Mapped[datetime]=mapped_column(DateTime,default=now)
    updated_at: Mapped[datetime]=mapped_column(DateTime,default=now,onupdate=now)

class ToolCall(Base):
    __tablename__='tool_calls'
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    task_id: Mapped[str|None]=mapped_column(ForeignKey('tasks.id',ondelete='SET NULL'),nullable=True,index=True)
    name: Mapped[str]=mapped_column(String(100)); status: Mapped[str]=mapped_column(String(30))
    input: Mapped[dict]=mapped_column(JSON); output: Mapped[dict|None]=mapped_column(JSON,nullable=True)
    created_at: Mapped[datetime]=mapped_column(DateTime,default=now)

class Execution(Base):
    __tablename__='executions'
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    user_id: Mapped[str]=mapped_column(ForeignKey('users.id',ondelete='CASCADE'),index=True)
    project_id: Mapped[str]=mapped_column(ForeignKey('projects.id',ondelete='CASCADE'),index=True)
    command: Mapped[str]=mapped_column(Text); status: Mapped[str]=mapped_column(String(30))
    exit_code: Mapped[int|None]=mapped_column(Integer,nullable=True)
    stdout: Mapped[str]=mapped_column(Text,default=''); stderr: Mapped[str]=mapped_column(Text,default='')
    duration_ms: Mapped[int]=mapped_column(Integer,default=0); image: Mapped[str]=mapped_column(String(120))
    created_at: Mapped[datetime]=mapped_column(DateTime,default=now)

class AuditLog(Base):
    __tablename__='audit_logs'
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    user_id: Mapped[str|None]=mapped_column(ForeignKey('users.id',ondelete='SET NULL'),nullable=True,index=True)
    action: Mapped[str]=mapped_column(String(120)); target: Mapped[str]=mapped_column(String(120),default=''); details: Mapped[dict]=mapped_column(JSON,default=dict)
    created_at: Mapped[datetime]=mapped_column(DateTime,default=now)

class ModelRequest(Base):
    __tablename__='model_requests'
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    user_id: Mapped[str]=mapped_column(ForeignKey('users.id',ondelete='CASCADE'),index=True)
    provider: Mapped[str]=mapped_column(String(100)); model: Mapped[str]=mapped_column(String(200)); status: Mapped[str]=mapped_column(String(30))
    input_tokens: Mapped[int]=mapped_column(Integer,default=0); output_tokens: Mapped[int]=mapped_column(Integer,default=0); duration_ms: Mapped[int]=mapped_column(Integer,default=0); estimated_cost: Mapped[float|None]=mapped_column(Float,nullable=True)
    created_at: Mapped[datetime]=mapped_column(DateTime,default=now)

class Usage(Base):
    __tablename__='usage'
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    user_id: Mapped[str]=mapped_column(ForeignKey('users.id',ondelete='CASCADE'),index=True)
    metric: Mapped[str]=mapped_column(String(80)); amount: Mapped[int]=mapped_column(Integer,default=0)
    created_at: Mapped[datetime]=mapped_column(DateTime,default=now)

class MessageBlock(Base):
    __tablename__='message_blocks'
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    message_id: Mapped[str]=mapped_column(ForeignKey('messages.id',ondelete='CASCADE'),index=True)
    block_type: Mapped[str]=mapped_column(String(30)); text: Mapped[str|None]=mapped_column(Text,nullable=True)
    mime_type: Mapped[str|None]=mapped_column(String(120),nullable=True); uri: Mapped[str|None]=mapped_column(Text,nullable=True)
    metadata_json: Mapped[dict]=mapped_column('metadata',JSON,default=dict)
    created_at: Mapped[datetime]=mapped_column(DateTime,default=now)

class ResearchSourceRecord(Base):
    __tablename__='research_sources'
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    user_id: Mapped[str]=mapped_column(ForeignKey('users.id',ondelete='CASCADE'),index=True)
    project_id: Mapped[str|None]=mapped_column(ForeignKey('projects.id',ondelete='CASCADE'),nullable=True,index=True)
    url: Mapped[str]=mapped_column(Text); title: Mapped[str]=mapped_column(Text,default=''); domain: Mapped[str]=mapped_column(String(255),default='')
    retrieved_at: Mapped[datetime]=mapped_column(DateTime,default=now); content_hash: Mapped[str]=mapped_column(String(64),index=True); content: Mapped[str]=mapped_column(Text,default='')
    __table_args__=(Index('ix_research_sources_url','user_id','url',unique=True),)

class MemoryItemRecord(Base):
    __tablename__='memory_items'
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    user_id: Mapped[str]=mapped_column(ForeignKey('users.id',ondelete='CASCADE'),index=True)
    project_id: Mapped[str|None]=mapped_column(ForeignKey('projects.id',ondelete='CASCADE'),nullable=True,index=True)
    scope: Mapped[str]=mapped_column(String(30)); content: Mapped[str]=mapped_column(Text); source: Mapped[str]=mapped_column(String(120))
    created_at: Mapped[datetime]=mapped_column(DateTime,default=now); updated_at: Mapped[datetime]=mapped_column(DateTime,default=now,onupdate=now)

class SecurityFindingRecord(Base):
    __tablename__='security_findings'
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    project_id: Mapped[str]=mapped_column(ForeignKey('projects.id',ondelete='CASCADE'),index=True)
    task_id: Mapped[str|None]=mapped_column(ForeignKey('tasks.id',ondelete='SET NULL'),nullable=True,index=True)
    severity: Mapped[str]=mapped_column(String(20)); category: Mapped[str]=mapped_column(String(80)); message: Mapped[str]=mapped_column(Text)
    path: Mapped[str]=mapped_column(String(1000),default=''); line: Mapped[int|None]=mapped_column(Integer,nullable=True); evidence: Mapped[str]=mapped_column(Text,default='')
    created_at: Mapped[datetime]=mapped_column(DateTime,default=now)

class DeploymentRecord(Base):
    __tablename__='deployments'
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    user_id: Mapped[str]=mapped_column(ForeignKey('users.id',ondelete='CASCADE'),index=True)
    project_id: Mapped[str]=mapped_column(ForeignKey('projects.id',ondelete='CASCADE'),index=True)
    provider: Mapped[str]=mapped_column(String(80)); status: Mapped[str]=mapped_column(String(40)); url: Mapped[str|None]=mapped_column(Text,nullable=True); error: Mapped[str|None]=mapped_column(Text,nullable=True)
    created_at: Mapped[datetime]=mapped_column(DateTime,default=now); updated_at: Mapped[datetime]=mapped_column(DateTime,default=now,onupdate=now)

class TaskEventRecord(Base):
    __tablename__='task_events'
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    task_id: Mapped[str]=mapped_column(ForeignKey('tasks.id',ondelete='CASCADE'),index=True)
    event_type: Mapped[str]=mapped_column(String(80)); payload: Mapped[dict]=mapped_column(JSON,default=dict)
    created_at: Mapped[datetime]=mapped_column(DateTime,default=now)

class EvaluationRecord(Base):
    __tablename__='evaluations'
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    case_id: Mapped[str]=mapped_column(String(120)); category: Mapped[str]=mapped_column(String(80)); input: Mapped[str]=mapped_column(Text)
    expected: Mapped[list]=mapped_column(JSON,default=list); actual: Mapped[str]=mapped_column(Text,default=''); score: Mapped[float]=mapped_column(default=0)
    failure_reason: Mapped[str|None]=mapped_column(Text,nullable=True); model_version: Mapped[str]=mapped_column(String(200),default=''); created_at: Mapped[datetime]=mapped_column(DateTime,default=now)

class KnowledgeDocument(Base):
    __tablename__='knowledge_documents'
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    user_id: Mapped[str]=mapped_column(ForeignKey('users.id',ondelete='CASCADE'),index=True)
    project_id: Mapped[str]=mapped_column(ForeignKey('projects.id',ondelete='CASCADE'),index=True)
    filename: Mapped[str]=mapped_column(String(1000)); format: Mapped[str]=mapped_column(String(30))
    mime_type: Mapped[str|None]=mapped_column(String(120),nullable=True); size_bytes: Mapped[int]=mapped_column(Integer)
    metadata_json: Mapped[dict]=mapped_column('metadata',JSON,default=dict); extracted_text: Mapped[str]=mapped_column(Text,default='')
    status: Mapped[str]=mapped_column(String(40),default='indexed'); created_at: Mapped[datetime]=mapped_column(DateTime,default=now); updated_at: Mapped[datetime]=mapped_column(DateTime,default=now,onupdate=now)

class DocumentChunk(Base):
    __tablename__='document_chunks'
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    document_id: Mapped[str]=mapped_column(ForeignKey('knowledge_documents.id',ondelete='CASCADE'),index=True)
    project_id: Mapped[str]=mapped_column(ForeignKey('projects.id',ondelete='CASCADE'),index=True)
    chunk_index: Mapped[int]=mapped_column(Integer); text: Mapped[str]=mapped_column(Text); reference: Mapped[str]=mapped_column(String(500),default=''); metadata_json: Mapped[dict]=mapped_column('metadata',JSON,default=dict)

class EmbeddingRecord(Base):
    __tablename__='embeddings'
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    chunk_id: Mapped[str]=mapped_column(ForeignKey('document_chunks.id',ondelete='CASCADE'),index=True)
    project_id: Mapped[str]=mapped_column(ForeignKey('projects.id',ondelete='CASCADE'),index=True)
    model: Mapped[str]=mapped_column(String(200)); dimension: Mapped[int]=mapped_column(Integer); vector: Mapped[list]=mapped_column(JSON); created_at: Mapped[datetime]=mapped_column(DateTime,default=now)

class CitationRecord(Base):
    __tablename__='citations'
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    user_id: Mapped[str]=mapped_column(ForeignKey('users.id',ondelete='CASCADE'),index=True)
    project_id: Mapped[str|None]=mapped_column(ForeignKey('projects.id',ondelete='CASCADE'),nullable=True,index=True)
    source_type: Mapped[str]=mapped_column(String(30)); source_id: Mapped[str]=mapped_column(String(36)); claim: Mapped[str]=mapped_column(Text); reference: Mapped[str]=mapped_column(String(500),default=''); created_at: Mapped[datetime]=mapped_column(DateTime,default=now)

class VisionAnalysis(Base):
    __tablename__='vision_analyses'
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    user_id: Mapped[str]=mapped_column(ForeignKey('users.id',ondelete='CASCADE'),index=True)
    message_id: Mapped[str|None]=mapped_column(ForeignKey('messages.id',ondelete='SET NULL'),nullable=True,index=True)
    task: Mapped[str]=mapped_column(String(200)); provider: Mapped[str]=mapped_column(String(100)); model: Mapped[str]=mapped_column(String(200)); status: Mapped[str]=mapped_column(String(30)); response: Mapped[dict|None]=mapped_column(JSON,nullable=True); created_at: Mapped[datetime]=mapped_column(DateTime,default=now)

class GitRepositoryRecord(Base):
    __tablename__='git_repositories'
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    project_id: Mapped[str]=mapped_column(ForeignKey('projects.id',ondelete='CASCADE'),unique=True,index=True)
    provider: Mapped[str]=mapped_column(String(40),default='local')
    remote_url: Mapped[str|None]=mapped_column(Text,nullable=True)
    remote_name: Mapped[str]=mapped_column(String(80),default='origin')
    default_branch: Mapped[str]=mapped_column(String(255),default='main')
    external_repo_id: Mapped[str|None]=mapped_column(String(255),nullable=True)
    created_at: Mapped[datetime]=mapped_column(DateTime,default=now)
    updated_at: Mapped[datetime]=mapped_column(DateTime,default=now,onupdate=now)

class ApprovalRecord(Base):
    __tablename__='approvals'
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    user_id: Mapped[str]=mapped_column(ForeignKey('users.id',ondelete='CASCADE'),index=True)
    project_id: Mapped[str]=mapped_column(ForeignKey('projects.id',ondelete='CASCADE'),index=True)
    task_id: Mapped[str|None]=mapped_column(ForeignKey('tasks.id',ondelete='SET NULL'),nullable=True,index=True)
    action: Mapped[str]=mapped_column(String(100)); state: Mapped[str]=mapped_column(String(30),default='pending')
    payload: Mapped[dict]=mapped_column(JSON,default=dict); result: Mapped[dict|None]=mapped_column(JSON,nullable=True)
    created_at: Mapped[datetime]=mapped_column(DateTime,default=now); updated_at: Mapped[datetime]=mapped_column(DateTime,default=now,onupdate=now)

class CIRecord(Base):
    __tablename__='ci_runs'
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    user_id: Mapped[str]=mapped_column(ForeignKey('users.id',ondelete='CASCADE'),index=True)
    project_id: Mapped[str]=mapped_column(ForeignKey('projects.id',ondelete='CASCADE'),index=True)
    provider: Mapped[str]=mapped_column(String(80)); status: Mapped[str]=mapped_column(String(30)); external_run_id: Mapped[str|None]=mapped_column(String(255),nullable=True); url: Mapped[str|None]=mapped_column(Text,nullable=True); details: Mapped[dict]=mapped_column(JSON,default=dict)
    created_at: Mapped[datetime]=mapped_column(DateTime,default=now); updated_at: Mapped[datetime]=mapped_column(DateTime,default=now,onupdate=now)

class ProjectEnvironment(Base):
    __tablename__='project_environments'
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    project_id: Mapped[str]=mapped_column(ForeignKey('projects.id',ondelete='CASCADE'),index=True)
    environment: Mapped[str]=mapped_column(String(30)); key: Mapped[str]=mapped_column(String(200)); value_ref: Mapped[str|None]=mapped_column(Text,nullable=True); is_secret: Mapped[bool]=mapped_column(Boolean,default=False); is_public: Mapped[bool]=mapped_column(Boolean,default=False)
    created_at: Mapped[datetime]=mapped_column(DateTime,default=now)
    __table_args__=(Index('ix_project_env_key','project_id','environment','key',unique=True),)
