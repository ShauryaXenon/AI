from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
from ..config import settings

engine = None
SessionLocal = None

def _ensure_engine():
    global engine, SessionLocal
    if engine is None:
        engine = create_async_engine(settings.database_url, pool_pre_ping=True)
        SessionLocal = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)
    return engine

async def init_db():
    """Validate connectivity only. Schema lifecycle is owned by Alembic."""
    from sqlalchemy import text
    e = _ensure_engine()
    async with e.connect() as conn:
        await conn.execute(text('SELECT 1'))

async def get_db():
    _ensure_engine()
    async with SessionLocal() as s:
        yield s
