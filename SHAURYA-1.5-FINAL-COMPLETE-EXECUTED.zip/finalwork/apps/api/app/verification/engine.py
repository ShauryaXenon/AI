from dataclasses import dataclass, field
@dataclass
class VerificationReport:
    generated: bool=False
    edited: bool=False
    built: bool=False
    tested: bool=False
    verified: bool=False
    details: list[str]=field(default_factory=list)

def verify(build_passed:bool,test_passed:bool,expected_files=True):
    r=VerificationReport(generated=True,edited=True,built=build_passed,tested=test_passed)
    r.verified=build_passed and test_passed and expected_files
    if not build_passed: r.details.append('Build did not pass.')
    if not test_passed: r.details.append('Tests did not pass.')
    if not expected_files: r.details.append('Expected files were not present.')
    if r.verified: r.details.append('Build and tests passed; verification criteria satisfied.')
    return r
