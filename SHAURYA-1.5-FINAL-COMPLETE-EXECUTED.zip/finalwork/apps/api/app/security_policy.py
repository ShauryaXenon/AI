from enum import Enum
class Permission(str,Enum): READ='READ'; WRITE='WRITE'; EXECUTE='EXECUTE'; NETWORK='NETWORK'; EXTERNAL_ACCOUNT='EXTERNAL_ACCOUNT'; DEPLOY='DEPLOY'; PUBLISH='PUBLISH'
DESTRUCTIVE={'delete_file','run_command','git_push','create_pull_request','deploy'}
def require_permissions(tool_permissions,granted):
    missing=[p for p in tool_permissions if p not in granted]
    if missing: raise PermissionError('PERMISSION_REQUIRED:'+','.join(missing))
    return True
