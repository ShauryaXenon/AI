from __future__ import annotations
import subprocess
from pathlib import Path
from dataclasses import dataclass

class GitError(RuntimeError): pass

@dataclass
class GitResult:
    ok: bool
    stdout: str = ''
    stderr: str = ''
    returncode: int = 0

class LocalGitService:
    def __init__(self, root: str|Path):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def _run(self, *args: str) -> GitResult:
        try:
            p = subprocess.run(['git', *args], cwd=self.root, text=True, capture_output=True, timeout=60)
        except FileNotFoundError as e:
            raise GitError('GIT_RUNTIME_UNAVAILABLE') from e
        except subprocess.TimeoutExpired as e:
            raise GitError('GIT_OPERATION_TIMEOUT') from e
        return GitResult(p.returncode == 0, p.stdout, p.stderr, p.returncode)

    def init(self) -> GitResult: return self._run('init')
    def status(self) -> GitResult: return self._run('status', '--short', '--branch')
    def branches(self) -> GitResult: return self._run('branch', '--list', '--no-color')
    def current_branch(self) -> GitResult: return self._run('branch', '--show-current')
    def create_branch(self, name: str) -> GitResult:
        self._validate_branch(name); return self._run('switch', '-c', name)
    def switch_branch(self, name: str) -> GitResult:
        self._validate_branch(name); return self._run('switch', name)
    def diff(self, staged: bool=False) -> GitResult: return self._run('diff', '--cached' if staged else '--no-ext-diff', '--unified=3')
    def changed_files(self) -> GitResult: return self._run('diff', '--name-status')
    def history(self, limit: int=20) -> GitResult:
        limit=max(1,min(limit,100)); return self._run('log', f'-{limit}', '--oneline', '--decorate')
    def stage(self, paths: list[str]|None=None) -> GitResult:
        if not paths: return self._run('add', '-A')
        safe=[self._safe_relative(p) for p in paths]; return self._run('add', '--', *safe)
    def commit(self, message: str) -> GitResult:
        if not message.strip(): raise GitError('COMMIT_MESSAGE_REQUIRED')
        if len(message)>500: raise GitError('COMMIT_MESSAGE_TOO_LONG')
        return self._run('commit', '-m', message.strip())

    def _safe_relative(self, value: str) -> str:
        p=Path(value)
        if p.is_absolute() or '..' in p.parts: raise GitError('GIT_PATH_ESCAPE')
        return str(p)
    @staticmethod
    def _validate_branch(name: str):
        if not name or name.startswith('-') or '..' in name or name.endswith('.') or any(c in name for c in ['~','^',':','?','*','[','\\']):
            raise GitError('INVALID_BRANCH_NAME')

    def add_remote(self, name: str, url: str) -> GitResult:
        if name in ('','--') or '\n' in url or '\r' in url: raise GitError('INVALID_REMOTE')
        return self._run('remote','add',name,url)
    def remote(self, name='origin') -> GitResult: return self._run('remote','get-url',name)
    def push(self, remote='origin', branch=None) -> GitResult:
        branch = branch or self.current_branch().stdout.strip()
        if not branch: raise GitError('BRANCH_REQUIRED')
        return self._run('push',remote,branch)
