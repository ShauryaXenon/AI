import httpx
from ..config import settings
class VisionUnavailable(RuntimeError): pass
class VisionProvider:
    def __init__(self,base_url='',api_key='',model=''):
        self.base_url=base_url.rstrip('/'); self.api_key=api_key; self.model=model
    @property
    def configured(self): return bool(self.base_url and self.api_key and self.model)
    async def analyze(self,blocks,task='describe'):
        if not self.configured: raise VisionUnavailable('VISION_CAPABILITY_UNAVAILABLE')
        content=[{'type':'text','text':task}]
        for b in blocks: content.append({'type':'image_url','image_url':{'url':b.get('data') if str(b.get('data','')).startswith('data:') else f"data:{b.get('mime_type','image/png')};base64,{b.get('data','') }"}})
        payload={'model':self.model,'messages':[{'role':'user','content':content}]}
        try:
            async with httpx.AsyncClient(timeout=60) as c:
                r=await c.post(self.base_url+'/chat/completions',headers={'Authorization':f'Bearer {self.api_key}'},json=payload); r.raise_for_status(); return r.json()
        except Exception as exc: raise VisionUnavailable(f'VISION_PROVIDER_ERROR:{type(exc).__name__}') from exc
