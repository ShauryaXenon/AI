from enum import Enum
class ApprovalState(str,Enum): PENDING='pending'; APPROVED='approved'; REJECTED='rejected'; EXECUTED='executed'; FAILED='failed'
SENSITIVE_ACTIONS={'git_push','github_pull_request','github_merge','github_delete_branch','deploy','publish','deployment_rollback','external_repository_modify'}
