from sqlalchemy import text
from .config import settings
from .db.session import _ensure_engine

async def postgres_health() -> dict:
    try:
        engine = _ensure_engine()
        async with engine.connect() as conn:
            await conn.execute(text('SELECT 1'))
        return {'status':'PASS'}
    except Exception as exc:
        return {'status':'BLOCKED','error':f'{type(exc).__name__}: {exc}'}

async def redis_health() -> dict:
    try:
        from redis.asyncio import from_url
        client = from_url(settings.redis_url, decode_responses=True)
        try:
            pong = await client.ping()
            return {'status':'PASS' if pong else 'FAIL'}
        finally:
            await client.aclose()
    except Exception as exc:
        return {'status':'BLOCKED','error':f'{type(exc).__name__}: {exc}'}
