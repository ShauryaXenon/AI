from __future__ import annotations
from dataclasses import dataclass, asdict
from urllib.parse import urlparse
import os

SECRET_KEYS = {'ai_api_key','model_fallback_api_key','github_token','github_client_secret','deployment_api_key','ci_api_key','jwt_secret'}

@dataclass(frozen=True)
class ConfigFinding:
    key: str
    status: str
    message: str


def _url_ok(value: str, schemes=('http','https')) -> bool:
    try:
        p=urlparse(value)
        return bool(p.scheme in schemes and p.netloc)
    except Exception:
        return False


def validate_production_config(settings) -> dict:
    f: list[ConfigFinding] = []
    prod=str(settings.environment).lower() == 'production'
    if not settings.database_url or 'localhost' in settings.database_url or '127.0.0.1' in settings.database_url:
        f.append(ConfigFinding('database_url','BLOCKED' if prod else 'NOT_CONFIGURED','Database URL is local/default or missing.'))
    else: f.append(ConfigFinding('database_url','CONFIGURED','Database URL is configured; live connectivity is verified separately.'))
    if not settings.redis_url or 'localhost' in settings.redis_url:
        f.append(ConfigFinding('redis_url','BLOCKED' if prod else 'NOT_CONFIGURED','Redis URL is local/default or missing.'))
    else: f.append(ConfigFinding('redis_url','CONFIGURED','Redis URL is configured; live connectivity is verified separately.'))
    if not (settings.ai_base_url and settings.ai_api_key and settings.ai_model):
        f.append(ConfigFinding('model_provider','NOT_CONFIGURED','Primary model provider is incomplete.'))
    elif not _url_ok(settings.ai_base_url): f.append(ConfigFinding('model_provider','BLOCKED','Primary model URL is invalid.'))
    else: f.append(ConfigFinding('model_provider','AVAILABLE','Primary model provider configuration is present.'))
    f.append(ConfigFinding('sandbox','AVAILABLE' if os.path.exists('/var/run/docker.sock') else 'UNAVAILABLE','Docker runtime availability is environment-dependent.'))
    if prod and settings.jwt_secret == 'change-me-in-production': f.append(ConfigFinding('jwt_secret','BLOCKED','Default JWT secret is unsafe for production.'))
    else: f.append(ConfigFinding('jwt_secret','CONFIGURED' if settings.jwt_secret else 'BLOCKED','Session signing secret is configured without printing it; runtime security checks are separate.'))
    origins=[x.strip() for x in str(settings.cors_origins).split(',') if x.strip()]
    if prod and ('*' in origins or any(o.startswith('http://') for o in origins)):
        f.append(ConfigFinding('cors_origins','BLOCKED','Production CORS must use explicit HTTPS origins.'))
    else: f.append(ConfigFinding('cors_origins','CONFIGURED' if origins else 'BLOCKED','Explicit CORS origins are configured.'))
    if settings.github_token: f.append(ConfigFinding('github','AVAILABLE','GitHub token is configured server-side.'))
    else: f.append(ConfigFinding('github','NOT_CONFIGURED','GitHub credentials are not configured.'))
    if settings.ci_provider_url and settings.ci_api_key: f.append(ConfigFinding('ci','AVAILABLE','CI provider configuration is present.'))
    else: f.append(ConfigFinding('ci','NOT_CONFIGURED','CI provider is not configured.'))
    if settings.deployment_base_url and settings.deployment_api_key: f.append(ConfigFinding('deployment','AVAILABLE','Deployment provider configuration is present.'))
    else: f.append(ConfigFinding('deployment','NOT_CONFIGURED','Deployment provider is not configured.'))
    status='CONFIGURED' if all(x.status in {'VERIFIED','AVAILABLE','CONFIGURED'} for x in f) else ('BLOCKED' if any(x.status=='BLOCKED' for x in f) else 'NOT_CONFIGURED')
    return {'status':status,'findings':[asdict(x) for x in f],'secrets_checked':sorted(SECRET_KEYS),'secret_values_exposed':False}
