from pydantic import BaseModel, Field
from typing import Literal

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=100_000)
    conversation_id: str | None = None
    project_id: str | None = None

class ProjectCreate(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    description: str = Field(default="", max_length=1000)

class FileCreate(BaseModel):
    path: str = Field(min_length=1, max_length=500)
    content: str = Field(default="", max_length=5_000_000)

class ProviderStatus(BaseModel):
    name: str
    configured: bool
    model: str | None = None
