from dataclasses import dataclass
from .embeddings import cosine
@dataclass(frozen=True)
class VectorItem: id:str; project_id:str; document_id:str; vector:list[float]; metadata:dict
class VectorStore:
    def __init__(self): self.items=[]
    def add(self,item): self.items.append(item)
    def search(self,query,top_k=5,project_id=None,document_id=None,threshold=0.0):
        rows=[]
        for x in self.items:
            if project_id and x.project_id!=project_id: continue
            if document_id and x.document_id!=document_id: continue
            s=cosine(query,x.vector)
            if s>=threshold: rows.append((s,x))
        return sorted(rows,key=lambda z:z[0],reverse=True)[:top_k]
