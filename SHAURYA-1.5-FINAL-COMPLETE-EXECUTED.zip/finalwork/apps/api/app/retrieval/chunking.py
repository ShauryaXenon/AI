from dataclasses import dataclass
@dataclass(frozen=True)
class Chunk:
    text:str; reference:str; metadata:dict

def chunk_document(pages,max_chars=4000,overlap=300):
    out=[]
    for page in pages:
        text=page.text or ''
        if not text: continue
        start=0
        while start<len(text):
            end=min(len(text),start+max_chars)
            out.append(Chunk(text[start:end],page.reference or f'page:{page.page}',{'page':page.page,'reference':page.reference}))
            if end==len(text): break
            start=max(start+1,end-overlap)
    return out
