from dataclasses import dataclass
from typing import Protocol
import httpx, math
from ..config import settings
class EmbeddingUnavailable(RuntimeError): pass
@dataclass(frozen=True)
class Embedding:
    vector:list[float]; model:str; dimension:int
class EmbeddingProvider(Protocol):
    async def embed(self,texts:list[str])->list[Embedding]: ...
class HttpEmbeddingProvider:
    def __init__(self,url='',key='',model=''): self.url=url.rstrip('/'); self.key=key; self.model=model
    @property
    def configured(self): return bool(self.url and self.key and self.model)
    async def embed(self,texts):
        if not self.configured: raise EmbeddingUnavailable('EMBEDDING_PROVIDER_UNAVAILABLE')
        try:
            async with httpx.AsyncClient(timeout=30) as c:
                r=await c.post(self.url+'/embeddings',headers={'Authorization':f'Bearer {self.key}'},json={'model':self.model,'input':texts}); r.raise_for_status(); data=r.json()['data']
        except Exception as exc: raise EmbeddingUnavailable(f'EMBEDDING_PROVIDER_ERROR:{type(exc).__name__}') from exc
        out=[Embedding(list(x['embedding']),self.model,len(x['embedding'])) for x in data]
        if len(out)!=len(texts): raise EmbeddingUnavailable('EMBEDDING_RESPONSE_COUNT_MISMATCH')
        return out

def cosine(a,b):
    if len(a)!=len(b) or not a or not b: return 0.0
    den=math.sqrt(sum(x*x for x in a))*math.sqrt(sum(x*x for x in b)); return sum(x*y for x,y in zip(a,b))/den if den else 0.0
