from pathlib import Path
from .registry import TOOL_REGISTRY
from ..filesafe.paths import safe_project_path
from ..security.policy import Permission,require_permissions

TOOL_PERMISSIONS={
 'list_files':[Permission.READ], 'read_file':[Permission.READ], 'search_files':[Permission.READ],
 'create_file':[Permission.WRITE], 'write_file':[Permission.WRITE], 'edit_file':[Permission.WRITE],
 'delete_file':[Permission.WRITE], 'rename_file':[Permission.WRITE], 'get_project_structure':[Permission.READ],
 'run_command':[Permission.EXECUTE], 'run_build':[Permission.EXECUTE], 'run_tests':[Permission.EXECUTE],
 'get_execution_result':[Permission.READ], 'get_git_status':[Permission.READ], 'get_git_diff':[Permission.READ],
}
def authorize(tool,granted): return require_permissions(TOOL_PERMISSIONS.get(tool,[]),granted)
def list_project_files(root): return [str(p.relative_to(root)) for p in Path(root).rglob('*') if p.is_file()]
def read_file(root,path): return safe_project_path(root,path).read_text(encoding='utf-8')
def write_file(root,path,content):
    p=safe_project_path(root,path); p.parent.mkdir(parents=True,exist_ok=True); p.write_text(content,encoding='utf-8'); return str(p.relative_to(root))
def search_files(root,term):
    hits=[]
    for p in Path(root).rglob('*'):
        if not p.is_file(): continue
        try:
            for i,line in enumerate(p.read_text(encoding='utf-8').splitlines(),1):
                if term.lower() in line.lower(): hits.append({'path':str(p.relative_to(root)),'line':i,'text':line[:500]})
        except UnicodeDecodeError: continue
    return hits
