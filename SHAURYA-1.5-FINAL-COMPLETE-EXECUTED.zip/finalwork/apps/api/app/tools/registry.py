from dataclasses import dataclass
from typing import Any,Callable
from . import __name__ as _
@dataclass(frozen=True)
class ToolSpec:
    name:str; description:str; risk:str; destructive:bool; timeout:int
TOOLS={
 'list_files':ToolSpec('list_files','List files in the authorized project','low',False,10),
 'read_file':ToolSpec('read_file','Read one authorized project file','low',False,10),
 'search_files':ToolSpec('search_files','Search authorized project files','low',False,20),
 'create_file':ToolSpec('create_file','Create a project file','medium',False,20),
 'write_file':ToolSpec('write_file','Replace a project file version','medium',False,20),
 'edit_file':ToolSpec('edit_file','Apply a targeted edit','medium',False,20),
 'delete_file':ToolSpec('delete_file','Delete a project file','high',True,20),
 'rename_file':ToolSpec('rename_file','Rename a project file','medium',False,20),
 'get_project_structure':ToolSpec('get_project_structure','Inspect project structure','low',False,10),
 'run_command':ToolSpec('run_command','Run an allowlisted command in the isolated sandbox','high',False,120),
 'run_build':ToolSpec('run_build','Run detected project build command in the isolated sandbox','high',False,120),
 'run_tests':ToolSpec('run_tests','Run detected project tests in the isolated sandbox','high',False,120),
 'get_execution_result':ToolSpec('get_execution_result','Read an authorized execution result','low',False,10),
 'get_git_status':ToolSpec('get_git_status','Inspect git status in sandbox','medium',False,60),
 'get_git_diff':ToolSpec('get_git_diff','Inspect git diff in sandbox','medium',False,60),
 'search_web':ToolSpec('search_web','Search configured external research provider; requires NETWORK permission','high',False,30),
 'retrieve_url':ToolSpec('retrieve_url','Retrieve a public URL through the configured research boundary','high',False,30),
 'search_documents':ToolSpec('search_documents','Search documents already materialized in the authorized project','low',False,20),
 'analyze_image':ToolSpec('analyze_image','Analyze an image through a configured vision provider','high',False,60),
}
def get_tool(name): return TOOLS.get(name)
