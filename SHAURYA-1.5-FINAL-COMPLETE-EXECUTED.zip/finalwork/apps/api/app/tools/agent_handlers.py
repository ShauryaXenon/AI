from __future__ import annotations
from pathlib import Path
import subprocess, difflib
from ..filesafe.paths import safe_project_path,UnsafePath
from ..security_policy import Permission,require_permissions
from ..tools.registry import TOOLS
from ..execution.sandbox import SandboxUnavailable
from ..research.providers import ResearchEngine,ResearchUnavailable
from ..vision.provider import VisionProvider,VisionUnavailable
from ..research.safety import untrusted_context
from ..security_hardening import bounded_text

class AgentToolHandlers:
    registry=TOOLS
    def __init__(self,root,sandbox,granted=None,research=None,vision=None):
        self.root=Path(root).resolve(); self.sandbox=sandbox; self.granted=set(granted or [Permission.READ,Permission.WRITE,Permission.EXECUTE]); self.research=research; self.vision=vision; self.last_execution=None
    def _path(self,p):
        try:return safe_project_path(self.root,p)
        except UnsafePath as e: raise ValueError(str(e))
    def _check(self,name):
        if name in {'list_files','read_file','search_files','get_project_structure','get_execution_result','get_git_status','get_git_diff','search_documents'}: perms=[Permission.READ]
        elif name in {'create_file','write_file','edit_file','rename_file'}: perms=[Permission.WRITE]
        elif name in {'search_web','retrieve_url','analyze_image'}: perms=[Permission.NETWORK]
        else: perms=[Permission.EXECUTE]
        require_permissions(perms,self.granted)
    async def execute(self,name,args):
        try:
            if name not in self.registry: return {'ok':False,'error':'UNKNOWN_TOOL'}
            if args.get('_malformed'): return {'ok':False,'error':'MALFORMED_TOOL_ARGUMENTS'}
            if name=='delete_file': return {'ok':False,'error':'HUMAN_APPROVAL_REQUIRED','permission':'WRITE'}
            self._check(name)
            if name=='list_files': return {'ok':True,'files':[str(p.relative_to(self.root)) for p in self.root.rglob('*') if p.is_file()]}
            if name=='get_project_structure': return {'ok':True,'files':[str(p.relative_to(self.root)) for p in self.root.rglob('*') if p.is_file()]}
            if name=='read_file':
                p=self._path(args['path']);
                if not p.is_file(): return {'ok':False,'error':'FILE_NOT_FOUND'}
                return {'ok':True,'path':args['path'],'content':p.read_text(encoding='utf-8')[:100000]}
            if name=='search_files':
                term=args['term'].lower(); hits=[]
                for p in self.root.rglob('*'):
                    if p.is_file():
                        try:
                            for i,line in enumerate(p.read_text(encoding='utf-8').splitlines(),1):
                                if term in line.lower(): hits.append({'path':str(p.relative_to(self.root)),'line':i,'text':line[:500]})
                        except UnicodeDecodeError: pass
                return {'ok':True,'hits':hits[:500]}
            if name in {'create_file','write_file'}:
                p=self._path(args['path']); content=bounded_text(args['content'])
                if len(content)>2_000_000:return {'ok':False,'error':'FILE_SIZE_LIMIT'}
                if name=='create_file' and p.exists():return {'ok':False,'error':'FILE_EXISTS'}
                p.parent.mkdir(parents=True,exist_ok=True); tmp=p.with_suffix(p.suffix+'.tmp'); tmp.write_text(content,encoding='utf-8'); tmp.replace(p)
                return {'ok':True,'path':args['path'],'bytes':len(content.encode())}
            if name=='edit_file':
                p=self._path(args['path']); old=args['old']; new=bounded_text(args['new']); text=p.read_text(encoding='utf-8')
                if old not in text:return {'ok':False,'error':'PATCH_TARGET_NOT_FOUND'}
                if len(new)>2_000_000:return {'ok':False,'error':'PATCH_SIZE_LIMIT'}
                p.write_text(text.replace(old,new,1),encoding='utf-8'); return {'ok':True,'path':args['path'],'diff':''.join(difflib.unified_diff(text.splitlines(True),p.read_text(encoding='utf-8').splitlines(True),fromfile=args['path'],tofile=args['path']))[:30000]}
            if name=='rename_file':
                p=self._path(args['path']); q=self._path(args['new_path']); q.parent.mkdir(parents=True,exist_ok=True); p.rename(q); return {'ok':True,'path':args['new_path']}
            if name in {'run_command','run_build','run_tests'}:
                command=args.get('command') or ''
                if name!='run_command':
                    from ..execution.detect import detect_commands
                    cmds=detect_commands(self.root); command=cmds.get('build' if name=='run_build' else 'test') or ''
                    if not command:return {'ok':False,'error':f'{name.upper()}_COMMAND_UNAVAILABLE'}
                if not command:return {'ok':False,'error':'COMMAND_REQUIRED'}
                result=await self.sandbox.run(self.root,command); self.last_execution=result
                return {'ok':result.status=='passed','execution_id':result.execution_id,'status':result.status,'exit_code':result.exit_code,'stdout':result.stdout[:30000],'stderr':result.stderr[:30000],'image':result.image}
            if name=='get_execution_result':
                r=self.last_execution
                return {'ok':bool(r and r.execution_id==args['execution_id']),'execution':None if not r else {'status':r.status,'exit_code':r.exit_code,'stdout':r.stdout,'stderr':r.stderr}}
            if name=='search_web':
                if not self.research: return {'ok':False,'error':'RESEARCH_PROVIDER_UNAVAILABLE'}
                try: results=await self.research.search(str(args.get('query','')),int(args.get('limit',5)))
                except ResearchUnavailable as e: return {'ok':False,'error':str(e)}
                return {'ok':True,'results':[{'url':x.url,'title':x.title,'domain':x.domain,'retrieved_at':x.retrieved_at,'content_hash':x.content_hash,'content':x.content[:12000],**untrusted_context(x.content[:12000],x.domain)} for x in results]}
            if name=='retrieve_url':
                if not self.research: return {'ok':False,'error':'RESEARCH_PROVIDER_UNAVAILABLE'}
                try: x=await self.research.open(str(args.get('url','')))
                except ResearchUnavailable as e: return {'ok':False,'error':str(e)}
                return {'ok':True,'source':{'url':x.url,'title':x.title,'domain':x.domain,'retrieved_at':x.retrieved_at,'content_hash':x.content_hash,'content':x.content[:12000],**untrusted_context(x.content[:12000],x.domain)}}
            if name=='search_documents':
                term=str(args.get('query','')).lower(); hits=[]
                for p in self.root.rglob('*'):
                    if p.is_file():
                        try:
                            text=p.read_text(encoding='utf-8')
                            score=sum(text.lower().count(w) for w in term.split())
                            if score: hits.append({'path':str(p.relative_to(self.root)),'score':score,'text':text[:4000]})
                        except UnicodeDecodeError: pass
                return {'ok':True,'results':sorted(hits,key=lambda x:x['score'],reverse=True)[:20]}
            if name=='analyze_image':
                if not self.vision: return {'ok':False,'error':'VISION_CAPABILITY_UNAVAILABLE'}
                return {'ok':False,'error':'IMAGE_REFERENCE_REQUIRED'}
            if name in {'get_git_status','get_git_diff'}:
                cmd='git status --short --branch' if name.endswith('status') else 'git diff --no-ext-diff --unified=3'
                result=await self.sandbox.run(self.root,cmd); return {'ok':result.status=='passed','status':result.status,'stdout':result.stdout[:30000],'stderr':result.stderr[:10000]}
            return {'ok':False,'error':'UNIMPLEMENTED_TOOL'}
        except SandboxUnavailable:return {'ok':False,'error':'SANDBOX_RUNTIME_UNAVAILABLE'}
        except Exception as e:return {'ok':False,'error':type(e).__name__+': '+str(e)}
