from pydantic_settings import BaseSettings,SettingsConfigDict
class Settings(BaseSettings):
 app_name:str='SHAURYA 1.5 API'; environment:str='development'; cors_origins:str='http://localhost:3000'; database_url:str='postgresql+asyncpg://shaurya:shaurya@localhost:5432/shaurya'; jwt_secret:str='change-me-in-production'
 ai_base_url:str=''; ai_api_key:str=''; ai_model:str=''; request_timeout_seconds:float=90; model_max_output_tokens:int=4096; model_temperature:float=.2
 model_fallback_base_url:str=''; model_fallback_api_key:str=''; model_fallback_name:str=''; model_fallback_enabled:bool=True
 sandbox_timeout_seconds:int=120; sandbox_memory:str='512m'; sandbox_cpus:str='1.0'; sandbox_pids:int=128; redis_url:str='redis://localhost:6379/0'; max_tool_output_bytes:int=50000
 research_search_url:str=''; research_api_key:str=''
 embedding_base_url:str=''; embedding_api_key:str=''; embedding_model:str=''
 vision_base_url:str=''; vision_api_key:str=''; vision_model:str=''
 github_api_url:str='https://api.github.com'; github_token:str=''; github_client_id:str=''; github_client_secret:str=''; github_redirect_uri:str=''
 deployment_base_url:str=''; deployment_api_key:str=''; deployment_provider:str=''
 ci_provider_url:str=''; ci_api_key:str=''; ci_provider:str=''
 max_document_bytes:int=52428800; max_image_bytes:int=10485760
 model_config=SettingsConfigDict(env_file='.env',extra='ignore')
settings=Settings()
