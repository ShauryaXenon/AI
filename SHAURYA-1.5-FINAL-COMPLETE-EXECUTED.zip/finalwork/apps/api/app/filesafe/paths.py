from pathlib import Path
class UnsafePath(ValueError): pass
def safe_project_path(root,relative):
    if not isinstance(relative,str) or not relative or "\x00" in relative: raise UnsafePath("INVALID_PATH")
    r=Path(root).resolve(); p=(r/relative).resolve(strict=False)
    try: p.relative_to(r)
    except ValueError: raise UnsafePath("PATH_TRAVERSAL_BLOCKED")
    cur=r
    for part in Path(relative).parts:
        cur=cur/part
        if cur.is_symlink():
            target=cur.resolve()
            try: target.relative_to(r)
            except ValueError: raise UnsafePath("SYMLINK_ESCAPE_BLOCKED")
    return p
def safe_archive_member(name):
    if not isinstance(name,str) or "\x00" in name: raise UnsafePath("INVALID_ARCHIVE_NAME")
    p=Path(name)
    if p.is_absolute() or ".." in p.parts: raise UnsafePath("ARCHIVE_PATH_TRAVERSAL_BLOCKED")
    return str(p)
