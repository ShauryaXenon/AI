from dataclasses import dataclass
import tarfile,zipfile
from .paths import safe_archive_member,UnsafePath
@dataclass(frozen=True)
class ArchiveLimits:
    max_files:int=2000; max_total_bytes:int=200*1024*1024; max_member_bytes:int=50*1024*1024
def inspect_zip(path,limits=ArchiveLimits()):
    with zipfile.ZipFile(path) as z:
        infos=z.infolist()
        if len(infos)>limits.max_files: raise UnsafePath('ARCHIVE_FILE_COUNT_LIMIT')
        total=0; names=[]
        for i in infos:
            safe_archive_member(i.filename)
            if i.file_size>limits.max_member_bytes: raise UnsafePath('ARCHIVE_MEMBER_SIZE_LIMIT')
            total+=i.file_size
            if total>limits.max_total_bytes: raise UnsafePath('ARCHIVE_TOTAL_SIZE_LIMIT')
            names.append(i.filename)
        return names
def inspect_tar(path,limits=ArchiveLimits()):
    with tarfile.open(path) as t:
        members=t.getmembers()
        if len(members)>limits.max_files: raise UnsafePath('ARCHIVE_FILE_COUNT_LIMIT')
        total=0; names=[]
        for m in members:
            safe_archive_member(m.name)
            if m.size>limits.max_member_bytes: raise UnsafePath('ARCHIVE_MEMBER_SIZE_LIMIT')
            total+=m.size
            if total>limits.max_total_bytes: raise UnsafePath('ARCHIVE_TOTAL_SIZE_LIMIT')
            names.append(m.name)
        return names
