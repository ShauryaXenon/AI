from datetime import datetime,timedelta
import hashlib,secrets,hmac
from fastapi import Depends,HTTPException,Request
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from .db.session import get_db
from .db.models import User,Session
try:
    from passlib.context import CryptContext
    pwd=CryptContext(schemes=['bcrypt'],deprecated='auto')
except Exception:
    class _PBKDF2:
        def hash(self,password):
            salt=secrets.token_bytes(16); digest=hashlib.pbkdf2_hmac('sha256',password.encode(),salt,310000); return 'pbkdf2$310000$'+salt.hex()+'$'+digest.hex()
        def verify(self,password,stored):
            try:
                _,iters,salt_hex,digest_hex=stored.split('$'); got=hashlib.pbkdf2_hmac('sha256',password.encode(),bytes.fromhex(salt_hex),int(iters)); return hmac.compare_digest(got.hex(),digest_hex)
            except Exception:return False
    pwd=_PBKDF2()
def hash_token(t): return hashlib.sha256(t.encode()).hexdigest()
def new_token(): return secrets.token_urlsafe(48)
async def current_user(request:Request,db:AsyncSession=Depends(get_db)):
    token=request.cookies.get('shaurya_session')
    if not token: raise HTTPException(401,'AUTHENTICATION_REQUIRED')
    r=await db.execute(select(Session).where(Session.token_hash==hash_token(token)))
    sess=r.scalar_one_or_none()
    if not sess or sess.expires_at<datetime.utcnow(): raise HTTPException(401,'AUTHENTICATION_REQUIRED')
    r=await db.execute(select(User).where(User.id==sess.user_id)); user=r.scalar_one_or_none()
    if not user: raise HTTPException(401,'AUTHENTICATION_REQUIRED')
    return user
async def require_project(db,user_id,project_id):
    from .db.models import Project
    r=await db.execute(select(Project).where(Project.id==project_id,Project.owner_id==user_id)); p=r.scalar_one_or_none()
    if not p: raise HTTPException(404,'PROJECT_NOT_FOUND')
    return p
