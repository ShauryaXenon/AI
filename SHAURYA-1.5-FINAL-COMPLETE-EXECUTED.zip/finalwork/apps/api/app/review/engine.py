from dataclasses import dataclass,asdict
from pathlib import Path
import re
SEVERITIES=('INFO','LOW','MEDIUM','HIGH','CRITICAL')
@dataclass
class Finding:
    severity:str; category:str; message:str; path:str=''; line:int|None=None; evidence:str=''
class CodeReview:
    def review(self,files):
        out=[]
        for f in files:
            path=f.path; text=f.content
            for i,line in enumerate(text.splitlines(),1):
                if re.search(r'(api[_-]?key|secret|password)\s*=\s*[\"\'][^\"\']+[\"\']',line,re.I): out.append(Finding('HIGH','secrets','Possible hard-coded secret.',path,i,line.strip()))
                if 'eval(' in line: out.append(Finding('MEDIUM','security','Dynamic eval detected; review input flow.',path,i,line.strip()))
                if 'TODO' in line: out.append(Finding('INFO','maintainability','TODO marker remains.',path,i,line.strip()))
        return [asdict(x) for x in out]
class SecurityReview(CodeReview):
    pass
