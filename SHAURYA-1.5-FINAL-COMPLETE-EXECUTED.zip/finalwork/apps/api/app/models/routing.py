from dataclasses import dataclass
@dataclass(frozen=True)
class ModelCapabilities: text:bool=True; vision:bool=False; tool_calling:bool=False; long_context:bool=False; structured_output:bool=False; coding:bool=False
@dataclass(frozen=True)
class ModelSpec: provider:str; model:str; capabilities:ModelCapabilities
class ModelRegistry:
    def __init__(self): self.models=[]
    def register(self,spec): self.models.append(spec)
    def select(self,required):
        for m in self.models:
            if all(getattr(m.capabilities,k,False) for k,v in required.items() if v): return m
        return None
