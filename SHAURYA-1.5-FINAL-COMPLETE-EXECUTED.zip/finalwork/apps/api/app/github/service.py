from __future__ import annotations
import httpx
from dataclasses import dataclass

class GitHubError(RuntimeError): pass

@dataclass
class GitHubService:
    base_url: str = 'https://api.github.com'
    token: str = ''
    timeout: float = 30

    @property
    def configured(self): return bool(self.token)

    def _headers(self):
        if not self.token: raise GitHubError('GITHUB_PROVIDER_UNAVAILABLE')
        return {'Authorization': f'Bearer {self.token}', 'Accept':'application/vnd.github+json', 'X-GitHub-Api-Version':'2022-11-28'}

    async def _request(self, method, path, **kwargs):
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as c:
                r=await c.request(method, self.base_url.rstrip('/')+path, headers=self._headers(), **kwargs)
        except httpx.HTTPError as e: raise GitHubError(f'GITHUB_NETWORK_ERROR:{type(e).__name__}') from e
        if r.status_code >= 400:
            detail=''
            try: detail=r.json().get('message','')
            except Exception: pass
            raise GitHubError(f'GITHUB_API_ERROR:{r.status_code}:{detail[:300]}')
        return r.json() if r.content else {}

    async def repositories(self): return await self._request('GET','/user/repos',params={'per_page':100,'sort':'updated'})
    async def repository(self, owner, repo): return await self._request('GET',f'/repos/{owner}/{repo}')
    async def branches(self, owner, repo): return await self._request('GET',f'/repos/{owner}/{repo}/branches',params={'per_page':100})
    async def commits(self, owner, repo, limit=20): return await self._request('GET',f'/repos/{owner}/{repo}/commits',params={'per_page':max(1,min(limit,100))})
    async def create_repository(self, name, private=True, description=''):
        return await self._request('POST','/user/repos',json={'name':name,'private':private,'description':description})
    async def create_branch(self, owner, repo, branch, sha):
        return await self._request('POST',f'/repos/{owner}/{repo}/git/refs',json={'ref':f'refs/heads/{branch}','sha':sha})
    async def pull_request(self, owner, repo, title, head, base, body=''):
        return await self._request('POST',f'/repos/{owner}/{repo}/pulls',json={'title':title,'head':head,'base':base,'body':body})
    async def pull_request_diff(self, owner, repo, number):
        return await self._request('GET',f'/repos/{owner}/{repo}/pulls/{number}',headers={'Accept':'application/vnd.github.diff'})
    async def issues(self, owner, repo, limit=20): return await self._request('GET',f'/repos/{owner}/{repo}/issues',params={'per_page':max(1,min(limit,100))})

    async def clone_url(self, owner, repo):
        meta=await self.repository(owner,repo)
        return {'clone_url':meta.get('clone_url'),'ssh_url':meta.get('ssh_url'),'default_branch':meta.get('default_branch'),'full_name':meta.get('full_name')}
