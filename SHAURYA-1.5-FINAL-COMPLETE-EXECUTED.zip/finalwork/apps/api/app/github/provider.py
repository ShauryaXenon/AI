from dataclasses import dataclass
class GitHubAuthError(RuntimeError): pass
@dataclass
class GitHubRepository: id:int; full_name:str; default_branch:str; private:bool
class GitHubProvider:
    def __init__(self,access_token=None): self.access_token=access_token
    def require_auth(self):
        if not self.access_token: raise GitHubAuthError('GITHUB_AUTHORIZATION_REQUIRED')
    async def repositories(self): self.require_auth(); raise GitHubAuthError('GITHUB_PROVIDER_NOT_CONFIGURED')
    async def clone(self,*args,**kwargs): self.require_auth(); raise GitHubAuthError('GITHUB_PROVIDER_NOT_CONFIGURED')
    async def create_pull_request(self,*args,**kwargs): self.require_auth(); raise GitHubAuthError('GITHUB_PROVIDER_NOT_CONFIGURED')
