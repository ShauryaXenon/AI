from dataclasses import dataclass
@dataclass(frozen=True)
class Citation:
    source_id:str; claim:str; reference:str=''
