import asyncio, json, tempfile, shutil, time, base64, zipfile
from datetime import datetime,timedelta
from pathlib import Path
from fastapi import FastAPI,HTTPException,Depends,Response,BackgroundTasks,UploadFile,File,WebSocket,WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from sqlalchemy import select,delete
from sqlalchemy.ext.asyncio import AsyncSession
from .config import settings
from .db import session as db_session
from .db.session import get_db,init_db,_ensure_engine
from .db.models import User,Session,Project,ProjectFile,FileVersion,Conversation,Message,MessageBlock,Execution,Task,ToolCall,AuditLog,ResearchSourceRecord,MemoryItemRecord,SecurityFindingRecord,DeploymentRecord,TaskEventRecord,ModelRequest,Usage,KnowledgeDocument,DocumentChunk,EmbeddingRecord,CitationRecord,VisionAnalysis
from .security import pwd,hash_token,new_token,current_user,require_project
from .providers import route_stream,ProviderError,primary,fallback
from .schemas import ChatRequest,ProjectCreate,FileCreate,ProviderStatus
from .execution.sandbox import DockerSandbox,SandboxUnavailable
from .execution.detect import detect_commands
from .agent.events import event_bus
from .agent.runtime import AgentRuntime
from .repository.index import RepositoryIndex
from .review.engine import CodeReview,SecurityReview
from .research.providers import ResearchEngine,ResearchUnavailable,ResearchSource, HttpSearchProvider
from .multimodal.content import validate_image,validate_image_bytes
from .documents.pipeline import DocumentPipeline,UnsupportedDocument,DocumentParserUnavailable,DocumentParseError,inspect_archive
from .memory.store import MemoryStore
from .filesafe.paths import safe_project_path,UnsafePath
from .infrastructure import postgres_health, redis_health
from .retrieval.chunking import chunk_document
from .retrieval.embeddings import HttpEmbeddingProvider,EmbeddingUnavailable
from .retrieval.vector import VectorStore,VectorItem
from .vision.provider import VisionProvider,VisionUnavailable
from .multimodal.content import ContentBlock
from .production_config import validate_production_config

app=FastAPI(title=settings.app_name,version='0.4.0')
app.add_middleware(CORSMiddleware,allow_origins=[x.strip() for x in settings.cors_origins.split(',') if x.strip()],allow_credentials=True,allow_methods=['*'],allow_headers=['*'])
sandbox=DockerSandbox(timeout=settings.sandbox_timeout_seconds,memory=settings.sandbox_memory,cpus=settings.sandbox_cpus,pids=settings.sandbox_pids)
research=ResearchEngine(HttpSearchProvider(settings.research_search_url,settings.research_api_key) if settings.research_search_url else None); memory=MemoryStore(); running_tasks={}; vector_store=VectorStore(); embedding_provider=HttpEmbeddingProvider(settings.embedding_base_url,settings.embedding_api_key,settings.embedding_model); vision_provider=VisionProvider(settings.vision_base_url,settings.vision_api_key,settings.vision_model); cancelled_tasks=set(); paused_tasks=set()

@app.on_event('startup')
async def startup():
    try:
        await init_db()
        async with db_session.SessionLocal() as db:
            rows=(await db.execute(select(Task).where(Task.status.in_(['queued','planning','researching','reading','editing','building','testing','debugging','security_review','verifying'])))).scalars().all()
            for task in rows:
                request=str((task.result or {}).get('request',''))
                if request: asyncio.create_task(run_agent_task(task.id,task.user_id,task.project_id,request))
    except Exception:
        pass

@app.get('/v1/production-config')
async def production_config(user=Depends(current_user)):
    return validate_production_config(settings)

@app.get('/health')
async def health():
    return {'status':'ok','service':'shaurya-api','version':'0.4.0','capabilities':{'sandbox':sandbox.available(),'research':research.search_provider is not None,'vision':vision_provider.configured,'documents':True,'embeddings':embedding_provider.configured},'note':'Service liveness only; dependency verification is exposed at /health/dependencies'}

@app.get('/health/dependencies')
async def health_dependencies():
    pg, rd = await asyncio.gather(postgres_health(), redis_health())
    configured = {
        'model': primary.configured or fallback.configured,
        'research': research.search_provider is not None,
        'vision': vision_provider.configured,
        'embeddings': embedding_provider.configured,
        'github': github_service.configured if 'github_service' in globals() else bool(settings.github_token),
        'ci': ci_provider.configured if 'ci_provider' in globals() else bool(settings.ci_provider_url and settings.ci_api_key),
        'deployment': deployment_provider.configured if 'deployment_provider' in globals() else bool(settings.deployment_base_url and settings.deployment_api_key),
    }
    model = {'status':'CONFIGURED' if configured['model'] else 'NOT_CONFIGURED','error':None if configured['model'] else 'MODEL_PROVIDER_UNAVAILABLE'}
    docker = {'status':'AVAILABLE' if sandbox.available() else 'UNAVAILABLE','error':None if sandbox.available() else 'SANDBOX_RUNTIME_UNAVAILABLE'}
    services = {
        'postgres': pg,
        'redis': rd,
        'model': model,
        'docker': docker,
        'research': {'status':'CONFIGURED' if configured['research'] else 'NOT_CONFIGURED'},
        'vision': {'status':'CONFIGURED' if configured['vision'] else 'NOT_CONFIGURED'},
        'embeddings': {'status':'CONFIGURED' if configured['embeddings'] else 'NOT_CONFIGURED'},
        'github': {'status':'CONFIGURED' if configured['github'] else 'NOT_CONFIGURED'},
        'ci': {'status':'CONFIGURED' if configured['ci'] else 'NOT_CONFIGURED'},
        'deployment': {'status':'CONFIGURED' if configured['deployment'] else 'NOT_CONFIGURED'},
    }
    live_failures=[services['postgres']['status'],services['redis']['status']]
    overall='VERIFIED' if all(x=='PASS' for x in live_failures) and all(services[k]['status'] in {'CONFIGURED','AVAILABLE'} for k in configured) else ('FAILED' if 'FAIL' in live_failures else 'BLOCKED')
    return {'status':overall,'services':services,'note':'CONFIGURED means credentials/settings are present; VERIFIED is reserved for a successful live check.'}

@app.get('/v1/models',response_model=list[ProviderStatus])
async def models(): return [ProviderStatus(name='primary',configured=primary.configured,model=primary.model or None),ProviderStatus(name='fallback',configured=fallback.configured,model=fallback.model or None)]

@app.post('/v1/auth/register')
async def register(body:dict,response:Response,db:AsyncSession=Depends(get_db)):
    email=str(body.get('email','')).strip().lower(); password=str(body.get('password',''))
    if '@' not in email or len(password)<8: raise HTTPException(400,'INVALID_CREDENTIALS')
    if (await db.execute(select(User).where(User.email==email))).scalar_one_or_none(): raise HTTPException(409,'ACCOUNT_EXISTS')
    u=User(email=email,password_hash=pwd.hash(password)); db.add(u); await db.flush(); raw=new_token(); db.add(Session(user_id=u.id,token_hash=hash_token(raw),expires_at=datetime.utcnow()+timedelta(days=7))); await db.commit()
    response.set_cookie('shaurya_session',raw,httponly=True,samesite='lax',secure=settings.environment=='production',max_age=604800); return {'id':u.id,'email':u.email}
@app.post('/v1/auth/login')
async def login(body:dict,response:Response,db:AsyncSession=Depends(get_db)):
    email=str(body.get('email','')).strip().lower(); password=str(body.get('password','')); u=(await db.execute(select(User).where(User.email==email))).scalar_one_or_none()
    if not u or not pwd.verify(password,u.password_hash): raise HTTPException(401,'AUTHENTICATION_REQUIRED')
    raw=new_token(); db.add(Session(user_id=u.id,token_hash=hash_token(raw),expires_at=datetime.utcnow()+timedelta(days=7))); await db.commit(); response.set_cookie('shaurya_session',raw,httponly=True,samesite='lax',secure=settings.environment=='production',max_age=604800); return {'id':u.id,'email':u.email}
@app.post('/v1/auth/logout')
async def logout(request, response:Response, request_user=Depends(current_user), db:AsyncSession=Depends(get_db)):
    raw=request.cookies.get('shaurya_session')
    if raw:
        await db.execute(delete(Session).where(Session.token_hash==hash_token(raw),Session.user_id==request_user.id))
        await db.commit()
    response.delete_cookie('shaurya_session',httponly=True,samesite='lax',secure=settings.environment=='production')
    return {'status':'ok'}
@app.get('/v1/auth/me')
async def me(user=Depends(current_user)): return {'id':user.id,'email':user.email}

@app.post('/v1/projects')
async def create_project(body:ProjectCreate,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    p=Project(owner_id=user.id,name=body.name,description=body.description); db.add(p); await db.commit(); return {'id':p.id,'name':p.name,'description':p.description}
@app.get('/v1/projects')
async def list_projects(user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    rows=(await db.execute(select(Project).where(Project.owner_id==user.id).order_by(Project.updated_at.desc()))).scalars().all(); return [{'id':p.id,'name':p.name,'description':p.description} for p in rows]
@app.delete('/v1/projects/{project_id}')
async def delete_project(project_id:str,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    p=await require_project(db,user.id,project_id); await db.delete(p); await db.commit(); return {'status':'deleted'}


@app.get('/v1/projects/{project_id}/files/{file_id}/versions')
async def file_versions(project_id:str,file_id:str,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id)
    f=(await db.execute(select(ProjectFile).where(ProjectFile.id==file_id,ProjectFile.project_id==project_id))).scalar_one_or_none()
    if not f: raise HTTPException(404,'FILE_NOT_FOUND')
    vs=(await db.execute(select(FileVersion).where(FileVersion.file_id==file_id).order_by(FileVersion.version.desc()))).scalars().all()
    return [{'id':v.id,'version':v.version,'content':v.content,'created_at':v.created_at.isoformat()} for v in vs]

@app.post('/v1/projects/{project_id}/files/{file_id}/rollback/{version}')
async def rollback_file(project_id:str,file_id:str,version:int,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id)
    f=(await db.execute(select(ProjectFile).where(ProjectFile.id==file_id,ProjectFile.project_id==project_id))).scalar_one_or_none()
    v=(await db.execute(select(FileVersion).where(FileVersion.file_id==file_id,FileVersion.version==version))).scalar_one_or_none()
    if not f or not v: raise HTTPException(404,'VERSION_NOT_FOUND')
    f.version+=1; f.content=v.content; f.updated_at=datetime.utcnow(); db.add(FileVersion(file_id=f.id,version=f.version,content=f.content)); db.add(AuditLog(user_id=user.id,action='file.rollback',target=f.id,details={'from_version':version,'new_version':f.version})); await db.commit()
    return {'id':f.id,'path':f.path,'version':f.version,'rolled_back_to':version}

@app.post('/v1/projects/{project_id}/files')
async def create_file(project_id:str,body:FileCreate,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id)
    try: safe_project_path('/workspace',body.path)
    except UnsafePath: raise HTTPException(400,'PATH_TRAVERSAL_BLOCKED')
    f=ProjectFile(project_id=project_id,path=body.path,content=body.content); db.add(f); await db.flush(); db.add(FileVersion(file_id=f.id,version=1,content=body.content)); await db.commit(); return {'id':f.id,'path':f.path,'content':f.content,'version':f.version}
@app.get('/v1/projects/{project_id}/files')
async def list_files(project_id:str,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id); fs=(await db.execute(select(ProjectFile).where(ProjectFile.project_id==project_id).order_by(ProjectFile.path))).scalars().all(); return [{'id':f.id,'path':f.path,'version':f.version,'content':f.content} for f in fs]
@app.get('/v1/projects/{project_id}/files/{file_id}')
async def read_file(project_id:str,file_id:str,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id); f=(await db.execute(select(ProjectFile).where(ProjectFile.id==file_id,ProjectFile.project_id==project_id))).scalar_one_or_none()
    if not f: raise HTTPException(404,'FILE_NOT_FOUND')
    return {'id':f.id,'path':f.path,'content':f.content,'version':f.version}
@app.put('/v1/projects/{project_id}/files/{file_id}')
async def write_file(project_id:str,file_id:str,body:dict,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id); f=(await db.execute(select(ProjectFile).where(ProjectFile.id==file_id,ProjectFile.project_id==project_id))).scalar_one_or_none()
    if not f: raise HTTPException(404,'FILE_NOT_FOUND')
    f.version+=1; f.content=str(body.get('content','')); f.updated_at=datetime.utcnow(); db.add(FileVersion(file_id=f.id,version=f.version,content=f.content)); await db.commit(); return {'id':f.id,'path':f.path,'version':f.version,'content':f.content}
@app.delete('/v1/projects/{project_id}/files/{file_id}')
async def delete_file(project_id:str,file_id:str,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id); f=(await db.execute(select(ProjectFile).where(ProjectFile.id==file_id,ProjectFile.project_id==project_id))).scalar_one_or_none()
    if not f: raise HTTPException(404,'FILE_NOT_FOUND')
    await db.delete(f); await db.commit(); return {'status':'deleted'}

async def project_context(db,project_id,active_path=None,budget=30000):
    fs=(await db.execute(select(ProjectFile).where(ProjectFile.project_id==project_id).order_by(ProjectFile.updated_at.desc()))).scalars().all(); out=[]; used=0
    for f in fs:
        score=2 if f.path==active_path else (1 if f.path.endswith(('.json','.toml','.yaml','.yml','.py','.ts','.tsx','.js','.jsx')) else 0)
        if score==0 and used>budget//2: continue
        chunk=f'FILE {f.path}\n{f.content[:min(len(f.content),budget-used)]}'; out.append(chunk); used+=len(chunk)
        if used>=budget: break
    return '\n\n'.join(out)

@app.post('/v1/chat/stream')
async def chat_stream(request:ChatRequest,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    cid=request.conversation_id
    if cid:
        c=(await db.execute(select(Conversation).where(Conversation.id==cid,Conversation.user_id==user.id))).scalar_one_or_none()
        if not c: raise HTTPException(404,'CONVERSATION_NOT_FOUND')
    else:
        c=Conversation(user_id=user.id,project_id=request.project_id,title=request.message[:60]); db.add(c); await db.flush(); cid=c.id
    msg=Message(conversation_id=cid,role='user',content=request.message); db.add(msg); await db.flush(); await db.commit()
    context=await project_context(db,request.project_id) if request.project_id else ''; prompt=request.message + ('\n\nPROJECT CONTEXT:\n'+context if context else '')
    async def events():
        started=time.perf_counter(); full=[]; yield 'data: '+json.dumps({'type':'status','message':'Analyzing project context.'})+'\n\n'
        try:
            async for kind,value in route_stream(prompt):
                if kind=='status': yield 'data: '+json.dumps({'type':'status','message':value})+'\n\n'
                else: full.append(value); yield 'data: '+json.dumps({'type':'token','text':value})+'\n\n'
            text=''.join(full)
            async with db.begin(): db.add(Message(conversation_id=cid,role='assistant',content=text)); db.add(ModelRequest(user_id=user.id,provider='routed',model=primary.model or fallback.model or 'unconfigured',status='completed',duration_ms=int((time.perf_counter()-started)*1000),input_tokens=len(prompt)//4,output_tokens=len(text)//4)); db.add(Usage(user_id=user.id,metric='tokens',amount=(len(prompt)+len(text))//4))
            yield 'data: '+json.dumps({'type':'done','conversation_id':cid})+'\n\n'
        except ProviderError as exc: yield 'data: '+json.dumps({'type':'error','message':str(exc)})+'\n\n'
    return StreamingResponse(events(),media_type='text/event-stream',headers={'Cache-Control':'no-cache','X-Accel-Buffering':'no'})

@app.get('/v1/conversations')
async def conversations(user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    cs=(await db.execute(select(Conversation).where(Conversation.user_id==user.id).order_by(Conversation.updated_at.desc()))).scalars().all(); return [{'id':c.id,'project_id':c.project_id,'title':c.title,'updated_at':c.updated_at.isoformat()} for c in cs]
@app.get('/v1/conversations/{conversation_id}/messages')
async def conversation_messages(conversation_id:str,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    c=(await db.execute(select(Conversation).where(Conversation.id==conversation_id,Conversation.user_id==user.id))).scalar_one_or_none()
    if not c: raise HTTPException(404,'CONVERSATION_NOT_FOUND')
    ms=(await db.execute(select(Message).where(Message.conversation_id==conversation_id).order_by(Message.created_at))).scalars().all(); return [{'id':m.id,'role':m.role,'content':m.content} for m in ms]

async def run_agent_task(task_id:str,user_id:str,project_id:str,request:str):
    if task_id in running_tasks: return
    running_tasks[task_id]=time.time()
    try:
      async with db_session.SessionLocal() as db:
        task=(await db.execute(select(Task).where(Task.id==task_id,Task.user_id==user_id,Task.project_id==project_id))).scalar_one_or_none()
        if not task:return
        fs=(await db.execute(select(ProjectFile).where(ProjectFile.project_id==project_id))).scalars().all(); task.result={'request':request}; await db.commit()
        runtime=AgentRuntime(db_session.SessionLocal,sandbox,should_stop=lambda: task.id in cancelled_tasks or task.id in paused_tasks)
        await runtime.run(task,fs); await db.commit()
    finally:
      running_tasks.pop(task_id,None)

@app.post('/v1/projects/{project_id}/tasks')
async def create_task(project_id:str,body:dict,background:BackgroundTasks,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id); request=str(body.get('request','')).strip()
    if not request: raise HTTPException(400,'TASK_REQUEST_REQUIRED')
    t=Task(user_id=user.id,project_id=project_id,status='queued',current_step='planning',result={'request':request}); db.add(t); await db.commit(); background.add_task(run_agent_task,t.id,user.id,project_id,request); return {'task_id':t.id,'status':t.status}
@app.get('/v1/tasks')
async def tasks(user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    ts=(await db.execute(select(Task).where(Task.user_id==user.id).order_by(Task.updated_at.desc()))).scalars().all(); return [{'id':t.id,'project_id':t.project_id,'status':t.status,'current_step':t.current_step,'iteration':t.iteration,'error':t.error,'result':t.result} for t in ts]
@app.get('/v1/tasks/{task_id}')
async def task_detail(task_id:str,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    t=(await db.execute(select(Task).where(Task.id==task_id,Task.user_id==user.id))).scalar_one_or_none();
    if not t: raise HTTPException(404,'TASK_NOT_FOUND')
    return {'id':t.id,'project_id':t.project_id,'status':t.status,'current_step':t.current_step,'iteration':t.iteration,'error':t.error,'result':t.result}
@app.post('/v1/tasks/{task_id}/pause')
async def pause_task(task_id:str,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    t=(await db.execute(select(Task).where(Task.id==task_id,Task.user_id==user.id))).scalar_one_or_none();
    if not t: raise HTTPException(404,'TASK_NOT_FOUND')
    paused_tasks.add(t.id); t.status='paused'; await db.commit(); return {'status':'paused'}
@app.post('/v1/tasks/{task_id}/resume')
async def resume_task(task_id:str,background:BackgroundTasks,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    t=(await db.execute(select(Task).where(Task.id==task_id,Task.user_id==user.id))).scalar_one_or_none();
    if not t: raise HTTPException(404,'TASK_NOT_FOUND')
    if t.status not in ('paused','failed'): raise HTTPException(409,'TASK_NOT_RESUMABLE')
    request=str((t.result or {}).get('request','')); paused_tasks.discard(t.id); cancelled_tasks.discard(t.id); t.status='queued'; await db.commit(); background.add_task(run_agent_task,t.id,user.id,t.project_id,request); return {'status':'queued'}
@app.post('/v1/tasks/{task_id}/cancel')
async def cancel_task(task_id:str,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    t=(await db.execute(select(Task).where(Task.id==task_id,Task.user_id==user.id))).scalar_one_or_none();
    if not t: raise HTTPException(404,'TASK_NOT_FOUND')
    cancelled_tasks.add(t.id); t.status='cancelled'; t.current_step='cancelled'; await db.commit(); return {'status':'cancelled'}
@app.get('/v1/tasks/{task_id}/events')
async def task_events(task_id:str,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    t=(await db.execute(select(Task).where(Task.id==task_id,Task.user_id==user.id))).scalar_one_or_none();
    if not t: raise HTTPException(404,'TASK_NOT_FOUND')
    async def stream():
        yield 'data: '+json.dumps({'type':'task.state','status':t.status,'step':t.current_step})+'\n\n'
        historical=(await db.execute(select(TaskEventRecord).where(TaskEventRecord.task_id==task_id).order_by(TaskEventRecord.created_at))).scalars().all()
        for event in historical:
            yield 'data: '+json.dumps({'type':event.event_type,**(event.payload or {})})+'\n\n'
        if t.status in ('completed','failed','cancelled','budget_exceeded'): return
        async for event in event_bus.subscribe(task_id): yield 'data: '+json.dumps(event)+'\n\n'
    return StreamingResponse(stream(),media_type='text/event-stream',headers={'Cache-Control':'no-cache'})
@app.websocket('/v1/tasks/{task_id}/ws')
async def task_ws(ws:WebSocket,task_id:str):
    token=ws.cookies.get('shaurya_session')
    if not token:
        await ws.close(code=4401); return
    if db_session.SessionLocal is None: _ensure_engine()
    async with db_session.SessionLocal() as db:
        sess=(await db.execute(select(Session).where(Session.token_hash==hash_token(token),Session.expires_at>datetime.utcnow()))).scalar_one_or_none()
        if not sess:
            await ws.close(code=4401); return
        task=(await db.execute(select(Task).where(Task.id==task_id,Task.user_id==sess.user_id))).scalar_one_or_none()
        if not task:
            await ws.close(code=4404); return
    await ws.accept()
    try:
        async for event in event_bus.subscribe(task_id): await ws.send_json(event)
    except WebSocketDisconnect: pass

@app.post('/v1/projects/{project_id}/execute')
async def execute(project_id:str,body:dict,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id); command=str(body.get('command','')); task=Task(user_id=user.id,project_id=project_id,status='building',current_step='executing'); db.add(task); await db.flush()
    files=(await db.execute(select(ProjectFile).where(ProjectFile.project_id==project_id))).scalars().all(); tmp=Path(tempfile.mkdtemp(prefix='shaurya-'))
    for f in files:
        try: p=safe_project_path(tmp,f.path)
        except UnsafePath: await db.rollback(); shutil.rmtree(tmp,ignore_errors=True); raise HTTPException(400,'PATH_TRAVERSAL_BLOCKED')
        p.parent.mkdir(parents=True,exist_ok=True); p.write_text(f.content,encoding='utf-8')
    try:
        result=await sandbox.run(tmp,command); ex=Execution(user_id=user.id,project_id=project_id,command=command,status=result.status,exit_code=result.exit_code,stdout=result.stdout,stderr=result.stderr,duration_ms=result.duration_ms,image=result.image); db.add(ex); task.status='completed' if result.status=='passed' else 'failed'; task.current_step='verifying'; task.result={'execution_id':result.execution_id,'status':result.status}; await db.commit(); return {'execution_id':ex.id,'status':result.status,'exit_code':result.exit_code,'stdout':result.stdout,'stderr':result.stderr,'duration_ms':result.duration_ms,'image':result.image}
    except SandboxUnavailable: task.status='failed'; task.error='SANDBOX_RUNTIME_UNAVAILABLE'; await db.commit(); raise HTTPException(503,'SANDBOX_RUNTIME_UNAVAILABLE')
    finally: shutil.rmtree(tmp,ignore_errors=True)
@app.get('/v1/projects/{project_id}/executions')
async def executions(project_id:str,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id); xs=(await db.execute(select(Execution).where(Execution.project_id==project_id).order_by(Execution.created_at.desc()))).scalars().all(); return [{'id':x.id,'command':x.command,'status':x.status,'exit_code':x.exit_code,'stdout':x.stdout,'stderr':x.stderr,'duration_ms':x.duration_ms} for x in xs]

@app.get('/v1/projects/{project_id}/repository/index')
async def repository_index(project_id:str,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id); fs=(await db.execute(select(ProjectFile).where(ProjectFile.project_id==project_id))).scalars().all(); idx=RepositoryIndex(fs).build(); return {'files':[m.__dict__ for m in idx.metadata],'symbols':idx.symbols,'imports':idx.imports}
@app.post('/v1/projects/{project_id}/review')
async def review(project_id:str,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id); fs=(await db.execute(select(ProjectFile).where(ProjectFile.project_id==project_id))).scalars().all(); findings=CodeReview().review(fs); return {'findings':findings}
@app.post('/v1/projects/{project_id}/security-review')
async def security_review(project_id:str,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id); fs=(await db.execute(select(ProjectFile).where(ProjectFile.project_id==project_id))).scalars().all(); findings=SecurityReview().review(fs); return {'findings':findings}

@app.post('/v1/research/search')
async def research_search(body:dict,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    try: results=await research.search(str(body.get('query','')),int(body.get('limit',5)))
    except ResearchUnavailable as exc: raise HTTPException(503,str(exc))
    out=[]
    for item in research.dedupe(results):
        src=item if isinstance(item,ResearchSource) else ResearchSource.create(item['url'],item.get('title',''),item.get('content',''))
        existing=(await db.execute(select(ResearchSourceRecord).where(ResearchSourceRecord.user_id==user.id,ResearchSourceRecord.url==src.url))).scalar_one_or_none()
        if not existing: db.add(ResearchSourceRecord(user_id=user.id,url=src.url,title=src.title,domain=src.domain,content_hash=src.content_hash,content=src.content))
        out.append({'id':src.id,'url':src.url,'title':src.title,'domain':src.domain,'retrieved_at':src.retrieved_at,'content':src.content})
    await db.commit(); return {'results':out}
@app.get('/v1/research/sources')
async def sources(user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    rows=(await db.execute(select(ResearchSourceRecord).where(ResearchSourceRecord.user_id==user.id).order_by(ResearchSourceRecord.retrieved_at.desc()))).scalars().all(); return [{'id':r.id,'url':r.url,'title':r.title,'domain':r.domain,'retrieved_at':r.retrieved_at.isoformat(),'content_hash':r.content_hash} for r in rows]

@app.post('/v1/documents/extract')
async def document_extract(file:UploadFile=File(...),user=Depends(current_user)):
    data=await file.read()
    if len(data)>settings.max_document_bytes: raise HTTPException(413,'DOCUMENT_TOO_LARGE')
    name=file.filename or 'document'
    try: result=DocumentPipeline().extract(name,data)
    except UnsupportedDocument as exc: raise HTTPException(415,str(exc))
    except DocumentParserUnavailable as exc: raise HTTPException(503,str(exc))
    except DocumentParseError as exc: raise HTTPException(422,str(exc))
    except (ValueError,zipfile.BadZipFile) as exc: raise HTTPException(422,f'DOCUMENT_PARSE_ERROR:{type(exc).__name__}')
    return {'format':result.format,'metadata':{'filename':name,'bytes':len(data),**result.metadata},'pages':[{'page':p.page,'reference':p.reference,'text':p.text} for p in result.pages],'tables':result.tables}
@app.post('/v1/multimodal/image')
async def image_upload(file:UploadFile=File(...),user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    name=file.filename or 'image'
    data=await file.read()
    if len(data)>settings.max_image_bytes: raise HTTPException(413,'IMAGE_TOO_LARGE')
    try: image_meta=validate_image_bytes(name,data)
    except ValueError as exc: raise HTTPException(415,str(exc))
    return {'filename':name,'content_type':file.content_type,'bytes':len(data),'image':image_meta,'vision_capability':'available' if vision_provider.configured else 'VISION_CAPABILITY_UNAVAILABLE'}

@app.post('/v1/memory')
async def add_memory(body:dict,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    scope=str(body.get('scope','user')); project_id=body.get('project_id'); content=str(body.get('content','')).strip(); source=str(body.get('source','user-approved'))
    if project_id: await require_project(db,user.id,project_id)
    if not content: raise HTTPException(400,'MEMORY_CONTENT_REQUIRED')
    m=MemoryItemRecord(user_id=user.id,project_id=project_id,scope=scope,content=content,source=source); db.add(m); await db.commit(); return {'id':m.id,'scope':m.scope,'project_id':m.project_id,'content':m.content,'source':m.source}
@app.get('/v1/memory')
async def list_memory(project_id:str|None=None,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    if project_id: await require_project(db,user.id,project_id)
    q=select(MemoryItemRecord).where(MemoryItemRecord.user_id==user.id); q=q.where(MemoryItemRecord.project_id==project_id) if project_id else q
    rows=(await db.execute(q.order_by(MemoryItemRecord.updated_at.desc()))).scalars().all(); return [{'id':m.id,'scope':m.scope,'project_id':m.project_id,'content':m.content,'source':m.source} for m in rows]

@app.post('/v1/github/authorize')
async def github_authorize(user=Depends(current_user)): return {'status':'authorization_required','provider':'github','message':'Use a server-side OAuth flow; never submit a GitHub password to SHAURYA.'}
@app.get('/v1/github/repositories')
async def github_repositories(user=Depends(current_user)): raise HTTPException(503,'GITHUB_PROVIDER_NOT_CONFIGURED')
@app.post('/v1/github/pull-request')
async def github_pr(body:dict,user=Depends(current_user)): raise HTTPException(409,'EXPLICIT_CONFIRMATION_REQUIRED')
@app.post('/v1/deployments')
async def deployment(body:dict,user=Depends(current_user)): raise HTTPException(503,'DEPLOYMENT_PROVIDER_UNAVAILABLE')

# ---------------- Phase 7: research/document/multimodal knowledge APIs ----------------
@app.post('/v1/research/open')
async def research_open(body:dict,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    try: src=await research.open(str(body.get('url','')))
    except ResearchUnavailable as exc: raise HTTPException(503,str(exc))
    row=ResearchSourceRecord(user_id=user.id,url=src.url,title=src.title,domain=src.domain,content_hash=src.content_hash,content=src.content)
    existing=(await db.execute(select(ResearchSourceRecord).where(ResearchSourceRecord.user_id==user.id,ResearchSourceRecord.url==src.url))).scalar_one_or_none()
    if not existing: db.add(row); await db.commit(); source_id=row.id
    else: source_id=existing.id
    return {'id':source_id,'url':src.url,'title':src.title,'domain':src.domain,'retrieved_at':src.retrieved_at,'content_hash':src.content_hash,'content':src.content}

@app.post('/v1/research/citations')
async def create_citation(body:dict,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    project_id=body.get('project_id')
    if project_id: await require_project(db,user.id,project_id)
    source_id=str(body.get('source_id','')); claim=str(body.get('claim','')).strip(); reference=str(body.get('reference',''))
    source=(await db.execute(select(ResearchSourceRecord).where(ResearchSourceRecord.id==source_id,ResearchSourceRecord.user_id==user.id))).scalar_one_or_none()
    if not source: raise HTTPException(404,'SOURCE_NOT_FOUND')
    c=CitationRecord(user_id=user.id,project_id=project_id,source_type='web',source_id=source.id,claim=claim,reference=reference); db.add(c); await db.commit()
    return {'id':c.id,'source_id':c.source_id,'claim':c.claim,'reference':c.reference,'url':source.url,'title':source.title}

@app.get('/v1/research/citations')
async def list_citations(project_id:str|None=None,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    if project_id: await require_project(db,user.id,project_id)
    q=select(CitationRecord).where(CitationRecord.user_id==user.id)
    if project_id: q=q.where(CitationRecord.project_id==project_id)
    rows=(await db.execute(q.order_by(CitationRecord.created_at.desc()))).scalars().all()
    return [{'id':c.id,'source_id':c.source_id,'source_type':c.source_type,'claim':c.claim,'reference':c.reference} for c in rows]

@app.post('/v1/projects/{project_id}/knowledge/documents')
async def knowledge_upload(project_id:str,file:UploadFile=File(...),user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id); data=await file.read()
    if len(data)>settings.max_document_bytes: raise HTTPException(413,'DOCUMENT_TOO_LARGE')
    name=file.filename or 'document'; pipeline=DocumentPipeline()
    try: result=pipeline.extract(name,data)
    except UnsupportedDocument as exc: raise HTTPException(415,str(exc))
    except DocumentParserUnavailable as exc: raise HTTPException(503,str(exc))
    except DocumentParseError as exc: raise HTTPException(422,str(exc))
    except (ValueError,zipfile.BadZipFile) as exc: raise HTTPException(422,f'DOCUMENT_PARSE_ERROR:{type(exc).__name__}')
    chunks=chunk_document(result.pages); doc=KnowledgeDocument(user_id=user.id,project_id=project_id,filename=name,format=result.format,mime_type=file.content_type,size_bytes=len(data),metadata_json=result.metadata,extracted_text='\n\n'.join(p.text for p in result.pages),status='parsed')
    db.add(doc); await db.flush()
    for i,ch in enumerate(chunks): db.add(DocumentChunk(document_id=doc.id,project_id=project_id,chunk_index=i,text=ch.text,reference=ch.reference,metadata_json=ch.metadata))
    doc.status='indexed'; await db.commit()
    return {'id':doc.id,'filename':doc.filename,'format':doc.format,'chunks':len(chunks),'status':doc.status}

@app.get('/v1/projects/{project_id}/knowledge/documents')
async def knowledge_list(project_id:str,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id); rows=(await db.execute(select(KnowledgeDocument).where(KnowledgeDocument.project_id==project_id,KnowledgeDocument.user_id==user.id).order_by(KnowledgeDocument.created_at.desc()))).scalars().all()
    return [{'id':d.id,'filename':d.filename,'format':d.format,'size_bytes':d.size_bytes,'status':d.status,'metadata':d.metadata_json} for d in rows]

@app.delete('/v1/projects/{project_id}/knowledge/documents/{document_id}')
async def knowledge_delete(project_id:str,document_id:str,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id); d=(await db.execute(select(KnowledgeDocument).where(KnowledgeDocument.id==document_id,KnowledgeDocument.project_id==project_id,KnowledgeDocument.user_id==user.id))).scalar_one_or_none()
    if not d: raise HTTPException(404,'DOCUMENT_NOT_FOUND')
    await db.delete(d); await db.commit(); return {'status':'deleted'}

@app.get('/v1/projects/{project_id}/knowledge/search')
async def knowledge_search(project_id:str,q:str,top_k:int=5,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id)
    words=[w.lower() for w in q.split() if w.strip()]
    chunks=(await db.execute(select(DocumentChunk).where(DocumentChunk.project_id==project_id))).scalars().all()
    scored=[]
    for c in chunks:
        low=c.text.lower(); score=sum(low.count(w) for w in words)
        if score: scored.append((score,c))
    scored.sort(key=lambda x:x[0],reverse=True)
    return {'results':[{'chunk_id':c.id,'document_id':c.document_id,'reference':c.reference,'text':c.text,'score':score} for score,c in scored[:max(1,min(top_k,20))]],'retrieval':'lexical'}

@app.post('/v1/projects/{project_id}/knowledge/{document_id}/embed')
async def knowledge_embed(project_id:str,document_id:str,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id)
    doc=(await db.execute(select(KnowledgeDocument).where(KnowledgeDocument.id==document_id,KnowledgeDocument.project_id==project_id,KnowledgeDocument.user_id==user.id))).scalar_one_or_none()
    if not doc: raise HTTPException(404,'DOCUMENT_NOT_FOUND')
    chunks=(await db.execute(select(DocumentChunk).where(DocumentChunk.document_id==doc.id).order_by(DocumentChunk.chunk_index))).scalars().all()
    if not chunks: return {'embedded':0}
    try: vectors=await embedding_provider.embed([c.text for c in chunks])
    except EmbeddingUnavailable as exc: raise HTTPException(503,str(exc))
    for c,v in zip(chunks,vectors):
        if v.dimension<=0: raise HTTPException(502,'EMBEDDING_DIMENSION_INVALID')
        db.add(EmbeddingRecord(chunk_id=c.id,project_id=project_id,model=v.model,dimension=v.dimension,vector=v.vector))
        vector_store.add(VectorItem(c.id,project_id,doc.id,v.vector,{'reference':c.reference}))
    await db.commit(); return {'embedded':len(vectors),'model':vectors[0].model,'dimension':vectors[0].dimension}

@app.post('/v1/projects/{project_id}/knowledge/vector-search')
async def knowledge_vector_search(project_id:str,body:dict,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id)
    query=str(body.get('query',''))
    try: vec=(await embedding_provider.embed([query]))[0]
    except EmbeddingUnavailable as exc: raise HTTPException(503,str(exc))
    hits=vector_store.search(vec.vector,int(body.get('top_k',5)),project_id=project_id,threshold=float(body.get('threshold',0)))
    return {'results':[{'chunk_id':x.id,'document_id':x.document_id,'score':score,'metadata':x.metadata} for score,x in hits]}

@app.post('/v1/multimodal/messages/serialize')
async def serialize_multimodal(body:dict,user=Depends(current_user)):
    blocks=body.get('blocks') or []
    allowed={'text','image','document','code','tool_result'}
    normalized=[]
    for b in blocks:
        if b.get('type') not in allowed: raise HTTPException(400,'INVALID_CONTENT_BLOCK')
        if b.get('type')=='image' and not b.get('mime_type','').startswith('image/'): raise HTTPException(415,'INVALID_IMAGE_MIME')
        normalized.append({k:v for k,v in b.items() if k in {'type','text','mime_type','uri','metadata'}})
    return {'blocks':normalized}

@app.post('/v1/multimodal/image/analyze')
async def analyze_image(task:str='describe',file:UploadFile=File(...),user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    data=await file.read()
    if len(data)>settings.max_image_bytes: raise HTTPException(413,'IMAGE_TOO_LARGE')
    try: image_meta=validate_image_bytes(file.filename or 'image',data)
    except ValueError as exc: raise HTTPException(415,str(exc))
    import mimetypes
    mime=file.content_type or mimetypes.guess_type(file.filename or '')[0] or 'application/octet-stream'
    block={'type':'image','mime_type':mime,'data':base64.b64encode(data).decode('ascii'),'metadata':{'filename':file.filename}}
    try: result=await vision_provider.analyze([block],task)
    except VisionUnavailable as exc: raise HTTPException(503,str(exc))
    row=VisionAnalysis(user_id=user.id,task=task,provider='configured',model=vision_provider.model,status='completed',response=result); db.add(row); await db.commit()
    return {'id':row.id,'status':'completed','image':image_meta,'response':result}

# ---------------- Phase 8: Git / CI / deployment workflows ----------------
from .git_service import LocalGitService, GitError
from .github.service import GitHubService, GitHubError
from .approvals import ApprovalState, SENSITIVE_ACTIONS
from .ci import CIProvider, CIState, HttpCIProvider
from .deployment.providers import HttpDeploymentProvider, DeploymentState as ProviderDeploymentState
from .db.models import GitRepositoryRecord, ApprovalRecord, CIRecord, ProjectEnvironment

github_service = GitHubService(settings.github_api_url, settings.github_token)
ci_provider = HttpCIProvider(settings.ci_provider_url, settings.ci_api_key, settings.ci_provider or 'http')
deployment_provider = HttpDeploymentProvider(settings.deployment_base_url, settings.deployment_api_key, settings.deployment_provider or 'http')
WORKSPACE_ROOT = Path('/workspaces')
if not WORKSPACE_ROOT.exists(): WORKSPACE_ROOT=Path(tempfile.gettempdir())/'shaurya-workspaces'
WORKSPACE_ROOT.mkdir(parents=True,exist_ok=True)

def _workspace(project_id):
    p=(WORKSPACE_ROOT/project_id).resolve()
    if WORKSPACE_ROOT.resolve() not in p.parents and p != WORKSPACE_ROOT.resolve(): raise HTTPException(500,'WORKSPACE_PATH_ERROR')
    p.mkdir(parents=True,exist_ok=True); return p

async def _materialize_project(db, project_id):
    root=_workspace(project_id)
    files=(await db.execute(select(ProjectFile).where(ProjectFile.project_id==project_id))).scalars().all()
    for f in files:
        try: p=safe_project_path(root,f.path)
        except UnsafePath: raise HTTPException(400,'PATH_TRAVERSAL_BLOCKED')
        p.parent.mkdir(parents=True,exist_ok=True); p.write_text(f.content,encoding='utf-8')
    return root

@app.get('/v1/projects/{project_id}/git/status')
async def git_status(project_id:str,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id); root=await _materialize_project(db,project_id); git=LocalGitService(root)
    if not (root/'.git').exists(): git.init()
    r=git.status(); return {'ok':r.ok,'stdout':r.stdout,'stderr':r.stderr,'returncode':r.returncode}

@app.get('/v1/projects/{project_id}/git/branches')
async def git_branches(project_id:str,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id); root=await _materialize_project(db,project_id); git=LocalGitService(root)
    if not (root/'.git').exists(): git.init()
    b=git.branches(); c=git.current_branch(); return {'ok':b.ok,'branches':b.stdout.splitlines(),'current':c.stdout.strip()}

@app.post('/v1/projects/{project_id}/git/branch')
async def git_branch(project_id:str,body:dict,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id); root=await _materialize_project(db,project_id); git=LocalGitService(root)
    if not (root/'.git').exists(): git.init()
    action=body.get('action','create'); name=str(body.get('name',''))
    try: r=git.create_branch(name) if action=='create' else git.switch_branch(name)
    except GitError as e: raise HTTPException(400,str(e))
    return {'ok':r.ok,'stdout':r.stdout,'stderr':r.stderr,'returncode':r.returncode}

@app.get('/v1/projects/{project_id}/git/diff')
async def git_diff(project_id:str,staged:bool=False,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id); root=await _materialize_project(db,project_id); git=LocalGitService(root)
    if not (root/'.git').exists(): git.init()
    r=git.diff(staged); return {'ok':r.ok,'diff':r.stdout,'stderr':r.stderr}

@app.get('/v1/projects/{project_id}/git/history')
async def git_history(project_id:str,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id); root=await _materialize_project(db,project_id); git=LocalGitService(root)
    if not (root/'.git').exists(): git.init()
    r=git.history(); return {'ok':r.ok,'history':r.stdout,'stderr':r.stderr}

@app.post('/v1/projects/{project_id}/git/commit')
async def git_commit(project_id:str,body:dict,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id); root=await _materialize_project(db,project_id); git=LocalGitService(root)
    if not (root/'.git').exists(): git.init()
    r=git.stage(body.get('paths')); 
    if not r.ok: return {'ok':False,'stage_error':r.stderr}
    c=git.commit(str(body.get('message','')))
    db.add(AuditLog(user_id=user.id,action='git.commit',target=project_id,details={'message':body.get('message',''),'status':c.ok})); await db.commit()
    return {'ok':c.ok,'stdout':c.stdout,'stderr':c.stderr,'returncode':c.returncode}

@app.post('/v1/projects/{project_id}/git/approval')
async def git_approval(project_id:str,body:dict,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id); action=str(body.get('action',''))
    if action not in SENSITIVE_ACTIONS: raise HTTPException(400,'APPROVAL_NOT_REQUIRED')
    row=ApprovalRecord(user_id=user.id,project_id=project_id,task_id=body.get('task_id'),action=action,state=ApprovalState.PENDING.value,payload=body.get('payload') or {}); db.add(row); await db.commit()
    return {'id':row.id,'action':row.action,'state':row.state}

@app.post('/v1/approvals/{approval_id}/decision')
async def approval_decision(approval_id:str,body:dict,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    row=(await db.execute(select(ApprovalRecord).where(ApprovalRecord.id==approval_id,ApprovalRecord.user_id==user.id))).scalar_one_or_none()
    if not row: raise HTTPException(404,'APPROVAL_NOT_FOUND')
    decision=str(body.get('decision','')).lower()
    if decision not in ('approved','rejected'): raise HTTPException(400,'INVALID_APPROVAL_DECISION')
    row.state=decision; row.updated_at=datetime.utcnow(); await db.commit(); return {'id':row.id,'state':row.state}

@app.get('/v1/approvals')
async def approvals(project_id:str|None=None,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    q=select(ApprovalRecord).where(ApprovalRecord.user_id==user.id)
    if project_id: await require_project(db,user.id,project_id); q=q.where(ApprovalRecord.project_id==project_id)
    rows=(await db.execute(q.order_by(ApprovalRecord.created_at.desc()))).scalars().all(); return [{'id':x.id,'project_id':x.project_id,'action':x.action,'state':x.state,'payload':x.payload,'result':x.result} for x in rows]

@app.get('/v1/projects/{project_id}/github/repositories')
async def github_repo_list(project_id:str,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id)
    if not github_service.configured: raise HTTPException(503,'GITHUB_PROVIDER_UNAVAILABLE')
    try: return await github_service.repositories()
    except GitHubError as e: raise HTTPException(502,str(e))

@app.get('/v1/projects/{project_id}/github/repository/{owner}/{repo}')
async def github_repo(project_id:str,owner:str,repo:str,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id)
    if not github_service.configured: raise HTTPException(503,'GITHUB_PROVIDER_UNAVAILABLE')
    try: return await github_service.repository(owner,repo)
    except GitHubError as e: raise HTTPException(502,str(e))

@app.post('/v1/projects/{project_id}/github/pull-request')
async def github_pull_request(project_id:str,body:dict,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id)
    approval_id=str(body.get('approval_id','')); a=(await db.execute(select(ApprovalRecord).where(ApprovalRecord.id==approval_id,ApprovalRecord.user_id==user.id,ApprovalRecord.project_id==project_id,ApprovalRecord.action=='github_pull_request'))).scalar_one_or_none()
    if not a or a.state!='approved': raise HTTPException(409,'EXPLICIT_CONFIRMATION_REQUIRED')
    if not github_service.configured: raise HTTPException(503,'GITHUB_PROVIDER_UNAVAILABLE')
    p=body.get('payload') or a.payload
    try: result=await github_service.pull_request(p['owner'],p['repo'],p['title'],p['head'],p['base'],p.get('body',''))
    except (KeyError,GitHubError) as e: raise HTTPException(400,str(e))
    a.state=ApprovalState.EXECUTED.value; a.result={'status':'created','number':result.get('number'),'url':result.get('html_url')}; await db.commit(); return result

@app.post('/v1/projects/{project_id}/git/push')
async def git_push(project_id:str,body:dict,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id)
    approval_id=str(body.get('approval_id','')); a=(await db.execute(select(ApprovalRecord).where(ApprovalRecord.id==approval_id,ApprovalRecord.user_id==user.id,ApprovalRecord.project_id==project_id,ApprovalRecord.action=='git_push'))).scalar_one_or_none()
    if not a or a.state!='approved': raise HTTPException(409,'EXPLICIT_CONFIRMATION_REQUIRED')
    root=await _materialize_project(db,project_id); git=LocalGitService(root)
    if not (root/'.git').exists(): git.init()
    r=git.push(str(body.get('remote','origin')),body.get('branch'))
    a.state=ApprovalState.EXECUTED.value if r.ok else ApprovalState.FAILED.value; a.result={'returncode':r.returncode,'stderr':r.stderr[:1000]}; await db.commit()
    return {'ok':r.ok,'stdout':r.stdout,'stderr':r.stderr,'returncode':r.returncode}

@app.post('/v1/projects/{project_id}/github/repository')
async def github_create_repository(project_id:str,body:dict,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id)
    if not github_service.configured: raise HTTPException(503,'GITHUB_PROVIDER_UNAVAILABLE')
    try: result=await github_service.create_repository(str(body['name']),bool(body.get('private',True)),str(body.get('description','')))
    except (KeyError,GitHubError) as e: raise HTTPException(400,str(e))
    row=(await db.execute(select(GitRepositoryRecord).where(GitRepositoryRecord.project_id==project_id))).scalar_one_or_none()
    if not row: row=GitRepositoryRecord(project_id=project_id,provider='github'); db.add(row)
    row.remote_url=result.get('clone_url'); row.default_branch=result.get('default_branch') or 'main'; row.external_repo_id=str(result.get('id','')); await db.commit()
    return result

@app.get('/v1/projects/{project_id}/github/branches/{owner}/{repo}')
async def github_branches(project_id:str,owner:str,repo:str,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id)
    if not github_service.configured: raise HTTPException(503,'GITHUB_PROVIDER_UNAVAILABLE')
    try:return await github_service.branches(owner,repo)
    except GitHubError as e:raise HTTPException(502,str(e))

@app.get('/v1/projects/{project_id}/github/commits/{owner}/{repo}')
async def github_commits(project_id:str,owner:str,repo:str,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id)
    if not github_service.configured: raise HTTPException(503,'GITHUB_PROVIDER_UNAVAILABLE')
    try:return await github_service.commits(owner,repo)
    except GitHubError as e:raise HTTPException(502,str(e))

@app.get('/v1/projects/{project_id}/github/clone-info/{owner}/{repo}')
async def github_clone_info(project_id:str,owner:str,repo:str,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id)
    if not github_service.configured: raise HTTPException(503,'GITHUB_PROVIDER_UNAVAILABLE')
    try:return await github_service.clone_url(owner,repo)
    except GitHubError as e:raise HTTPException(502,str(e))

@app.post('/v1/projects/{project_id}/ci/verify')
async def ci_verify(project_id:str,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id)
    result=await ci_provider.verify(project_id)
    row=CIRecord(user_id=user.id,project_id=project_id,provider=result.provider,status=result.state.value,external_run_id=result.run_id,url=result.url,details={'error':result.error}); db.add(row); await db.commit()
    return {'id':row.id,'status':row.status,'provider':row.provider,'error':result.error}

@app.get('/v1/projects/{project_id}/deployments')
async def deployment_history(project_id:str,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id); rows=(await db.execute(select(DeploymentRecord).where(DeploymentRecord.project_id==project_id,DeploymentRecord.user_id==user.id).order_by(DeploymentRecord.created_at.desc()))).scalars().all(); return [{'id':x.id,'provider':x.provider,'status':x.status,'url':x.url,'error':x.error} for x in rows]

@app.post('/v1/projects/{project_id}/deployments')
async def create_deployment(project_id:str,body:dict,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id)
    approval_id=str(body.get('approval_id','')); a=(await db.execute(select(ApprovalRecord).where(ApprovalRecord.id==approval_id,ApprovalRecord.user_id==user.id,ApprovalRecord.project_id==project_id,ApprovalRecord.action=='deploy'))).scalar_one_or_none()
    if not a or a.state!='approved': raise HTTPException(409,'EXPLICIT_CONFIRMATION_REQUIRED')
    row=DeploymentRecord(user_id=user.id,project_id=project_id,provider=deployment_provider.name,status='queued'); db.add(row); await db.flush()
    if not deployment_provider.configured:
        row.status='failed'; row.error='DEPLOYMENT_PROVIDER_UNAVAILABLE'; a.state=ApprovalState.FAILED.value; a.result={'error':row.error}; await db.commit(); raise HTTPException(503,row.error)
    payload=body.get('payload') or a.payload; result=await deployment_provider.deploy(payload); row.status=result.state.value; row.url=result.url; row.error=result.error; a.state=ApprovalState.EXECUTED.value if result.state.value=='live' else ApprovalState.FAILED.value; a.result={'deployment_id':result.deployment_id,'status':result.state.value}; await db.commit()
    if result.state.value!='live': raise HTTPException(502,result.error or 'DEPLOYMENT_FAILED')
    health=await deployment_provider.health_check(result); row.status=health.state.value; row.error=health.error; await db.commit()
    if health.state.value!='live': raise HTTPException(502,'DEPLOYMENT_HEALTHCHECK_FAILED')
    return {'id':row.id,'status':row.status,'url':row.url}

@app.post('/v1/projects/{project_id}/deployments/rollback')
async def rollback_deployment(project_id:str,body:dict,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id); approval_id=str(body.get('approval_id','')); a=(await db.execute(select(ApprovalRecord).where(ApprovalRecord.id==approval_id,ApprovalRecord.user_id==user.id,ApprovalRecord.project_id==project_id,ApprovalRecord.action=='deployment_rollback'))).scalar_one_or_none()
    if not a or a.state!='approved': raise HTTPException(409,'EXPLICIT_CONFIRMATION_REQUIRED')
    if not deployment_provider.configured: raise HTTPException(503,'DEPLOYMENT_PROVIDER_UNAVAILABLE')
    result=await deployment_provider.rollback(body.get('payload') or a.payload); a.state=ApprovalState.EXECUTED.value if result.state.value=='rolled_back' else ApprovalState.FAILED.value; a.result={'status':result.state.value,'error':result.error}; await db.commit()
    if result.state.value!='rolled_back': raise HTTPException(502,result.error or 'ROLLBACK_FAILED')
    return {'status':result.state.value,'deployment_id':result.deployment_id,'url':result.url}

@app.post('/v1/projects/{project_id}/environment')
async def environment_metadata(project_id:str,body:dict,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id); env=str(body.get('environment','development')); key=str(body.get('key','')).strip()
    if env not in ('development','staging','production') or not key or len(key)>200: raise HTTPException(400,'INVALID_ENVIRONMENT_METADATA')
    row=ProjectEnvironment(project_id=project_id,environment=env,key=key,value_ref=body.get('value_ref'),is_secret=bool(body.get('is_secret',False)),is_public=bool(body.get('is_public',False))); db.add(row); await db.commit()
    return {'id':row.id,'environment':row.environment,'key':row.key,'is_secret':row.is_secret,'is_public':row.is_public}

@app.get('/v1/projects/{project_id}/production-readiness')
async def production_readiness(project_id:str,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    await require_project(db,user.id,project_id)
    pg,rd=await asyncio.gather(postgres_health(),redis_health())
    checks={
      'DATABASE':'VERIFIED' if pg['status']=='PASS' else 'BLOCKED',
      'REDIS':'VERIFIED' if rd['status']=='PASS' else 'BLOCKED',
      'DOCKER':'VERIFIED' if sandbox.available() else 'BLOCKED',
      'MODEL':'IMPLEMENTED — NOT VERIFIED' if (primary.configured or fallback.configured) else 'NOT_CONFIGURED',
      'RESEARCH':'IMPLEMENTED — NOT VERIFIED' if research.search_provider else 'NOT_CONFIGURED',
      'VISION':'IMPLEMENTED — NOT VERIFIED' if vision_provider.configured else 'NOT_CONFIGURED',
      'EMBEDDINGS':'IMPLEMENTED — NOT VERIFIED' if embedding_provider.configured else 'NOT_CONFIGURED',
      'GIT':'VERIFIED',
      'GITHUB':'IMPLEMENTED — NOT VERIFIED' if github_service.configured else 'NOT_CONFIGURED',
      'CI':'IMPLEMENTED — NOT VERIFIED' if ci_provider.configured else 'NOT_CONFIGURED',
      'DEPLOYMENT':'IMPLEMENTED — NOT VERIFIED' if deployment_provider.configured else 'NOT_CONFIGURED',
      'FRONTEND':'BLOCKED'
    }
    return {'project_id':project_id,'status':checks}
