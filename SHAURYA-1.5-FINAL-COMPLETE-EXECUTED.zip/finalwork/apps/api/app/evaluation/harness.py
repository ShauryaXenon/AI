from dataclasses import dataclass,asdict
from datetime import datetime,timezone
@dataclass
class EvaluationCase:
    id:str; category:str; input:str; expected_properties:list[str]
@dataclass
class EvaluationResult:
    case_id:str; score:float; failure_reason:str|None; timestamp:str; model_version:str
class EvaluationHarness:
    def run(self,case,output,model_version):
        hits=sum(1 for p in case.expected_properties if p.lower() in output.lower()); score=hits/len(case.expected_properties) if case.expected_properties else 1.0
        return asdict(EvaluationResult(case.id,score,None if score==1 else 'EXPECTED_PROPERTY_MISSING',datetime.now(timezone.utc).isoformat(),model_version))
