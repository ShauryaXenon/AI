from __future__ import annotations
from pathlib import Path
from .filesafe.paths import UnsafePath

MAX_TEXT_BYTES=2_000_000
MAX_LIST_FILES=10_000

def hardened_project_path(root: Path, relative: str) -> Path:
    if not relative or '\x00' in relative: raise UnsafePath('INVALID_PATH')
    r=Path(root).resolve()
    p=(r/relative).resolve(strict=False)
    try: p.relative_to(r)
    except ValueError: raise UnsafePath('PATH_TRAVERSAL_BLOCKED')
    cur=r
    for part in Path(relative).parts:
        cur=cur/part
        if cur.is_symlink():
            target=cur.resolve()
            try: target.relative_to(r)
            except ValueError: raise UnsafePath('SYMLINK_ESCAPE_BLOCKED')
    return p

def bounded_text(data: str, limit=MAX_TEXT_BYTES):
    if len(data.encode('utf-8'))>limit: raise ValueError('FILE_SIZE_LIMIT')
    return data

def redact(value):
    if isinstance(value,dict):
        return {k: ('[REDACTED]' if any(x in k.lower() for x in ('token','secret','password','api_key','authorization')) else redact(v)) for k,v in value.items()}
    if isinstance(value,list): return [redact(v) for v in value]
    return value
