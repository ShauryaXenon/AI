import json
from collections.abc import AsyncIterator
import httpx
from .config import settings

SYSTEM_PROMPT = """You are SHAURYA 1.5, an AI workspace assistant. Be accurate and transparent. Do not claim a tool was used, a file was changed, code was executed, web research was performed, or deployment succeeded unless the platform actually performed that operation. If the configured model lacks a capability, say so. Prefer concise, useful answers and preserve user constraints."""

class ProviderError(RuntimeError):
    pass

class OpenAICompatibleProvider:
    def __init__(self, base_url: str, api_key: str, model: str, name: str):
        self.base_url, self.api_key, self.model, self.name = base_url.rstrip("/"), api_key, model, name

    @property
    def configured(self) -> bool:
        return bool(self.base_url and self.api_key and self.model)

    async def stream(self, user_message: str) -> AsyncIterator[str]:
        if not self.configured:
            raise ProviderError("No AI model provider is configured. Set AI_BASE_URL, AI_API_KEY and AI_MODEL in the API environment.")
        url = f"{self.base_url}/chat/completions"
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        payload = {"model": self.model, "messages": [{"role":"system","content":SYSTEM_PROMPT},{"role":"user","content":user_message}], "stream": True, "temperature": settings.model_temperature, "max_tokens": settings.model_max_output_tokens}
        timeout = httpx.Timeout(settings.request_timeout_seconds, connect=15.0)
        async with httpx.AsyncClient(timeout=timeout) as client:
            try:
                async with client.stream("POST", url, headers=headers, json=payload) as response:
                    if response.status_code >= 400:
                        body = (await response.aread()).decode("utf-8", errors="replace")[:500]
                        raise ProviderError(f"Provider returned HTTP {response.status_code}: {body}")
                    async for line in response.aiter_lines():
                        if not line.startswith("data:"):
                            continue
                        data = line[5:].strip()
                        if data == "[DONE]":
                            break
                        try:
                            obj = json.loads(data)
                            delta = obj.get("choices", [{}])[0].get("delta", {}).get("content")
                            if delta:
                                yield delta
                        except json.JSONDecodeError:
                            continue
            except httpx.HTTPError as exc:
                raise ProviderError(f"Provider connection failed: {exc}") from exc

primary = OpenAICompatibleProvider(settings.ai_base_url, settings.ai_api_key, settings.ai_model, "primary")
fallback = OpenAICompatibleProvider(settings.model_fallback_base_url, settings.model_fallback_api_key, settings.model_fallback_name, "fallback")

async def route_stream(message: str) -> AsyncIterator[tuple[str, str]]:
    providers = [primary]
    if settings.model_fallback_enabled:
        providers.append(fallback)
    errors: list[str] = []
    for provider in providers:
        if not provider.configured:
            continue
        try:
            yield ("status", f"Using {provider.name} model: {provider.model}")
            async for token in provider.stream(message):
                yield ("token", token)
            return
        except ProviderError as exc:
            errors.append(f"{provider.name}: {exc}")
            yield ("status", f"{provider.name.title()} model failed; trying the configured fallback.")
    detail = errors[0] if errors else "No provider is configured."
    raise ProviderError(detail)
