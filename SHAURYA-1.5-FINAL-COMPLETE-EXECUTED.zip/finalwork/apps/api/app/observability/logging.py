import json,logging,uuid,time
log=logging.getLogger('shaurya')
def request_id(): return str(uuid.uuid4())
def event(name,**fields):
    payload={'event':name,'ts':time.time(),**fields}; log.info(json.dumps(payload,separators=(',',':'))); return payload
