from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import hashlib, json

@dataclass(frozen=True)
class UnifiedEvent:
    event_id: str
    event_type: str
    timestamp: str
    subsystem: str
    status: str
    project_id: str|None=None
    task_id: str|None=None
    user_id: str|None=None
    duration_ms: int|None=None
    error_code: str|None=None
    payload: dict|None=None

def event_id(event_type, task_id, payload):
    raw=json.dumps([event_type,task_id,payload],sort_keys=True,default=str)
    return hashlib.sha256(raw.encode()).hexdigest()[:32]

def make_event(event_type, subsystem, status, **kwargs):
    payload=kwargs.pop('payload',{}) or {}
    tid=kwargs.get('task_id')
    return UnifiedEvent(event_id=event_id(event_type,tid,payload),event_type=event_type,timestamp=datetime.now(timezone.utc).isoformat(),subsystem=subsystem,status=status,payload=payload,**kwargs)
