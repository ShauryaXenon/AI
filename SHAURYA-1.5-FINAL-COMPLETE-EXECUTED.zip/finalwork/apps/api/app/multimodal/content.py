from dataclasses import dataclass,asdict
from pathlib import Path
import base64,re,io
IMAGE_TYPES={'.png','.jpg','.jpeg','.webp','.gif','.svg'}
@dataclass
class ContentBlock:
    type:str; text:str|None=None; mime_type:str|None=None; data:str|None=None; uri:str|None=None; metadata:dict|None=None
    def to_dict(self): return asdict(self)
def image_block(data:bytes,mime_type:str,filename:str): return ContentBlock('image',mime_type=mime_type,data=base64.b64encode(data).decode(),metadata={'filename':filename})
def validate_image(name):
    ext=Path(name).suffix.lower()
    if ext not in IMAGE_TYPES: raise ValueError('UNSUPPORTED_IMAGE_FORMAT')
    return ext

def validate_image_bytes(name,data,max_dimension=12000):
    ext=validate_image(name)
    if ext=='.svg':
        text=data[:2_000_000].decode('utf-8',errors='ignore').lower()
        if '<script' in text or 'javascript:' in text or 'onload=' in text or 'iframe' in text: raise ValueError('UNSAFE_SVG')
        return {'format':'svg','dimensions':None,'dimensions_verified':False}
    try:
        from PIL import Image
        with Image.open(io.BytesIO(data)) as im:
            if im.width>max_dimension or im.height>max_dimension: raise ValueError('IMAGE_DIMENSIONS_TOO_LARGE')
            im.verify()
            return {'format':im.format.lower() if im.format else ext[1:],'dimensions':[im.width,im.height],'dimensions_verified':True}
    except ImportError:
        return {'format':ext[1:],'dimensions':None,'dimensions_verified':False}
    except ValueError: raise
    except Exception as exc: raise ValueError(f'INVALID_IMAGE:{type(exc).__name__}') from exc

class VisionProvider:
    async def analyze(self,blocks,task='describe'):
        raise RuntimeError('VISION_PROVIDER_UNAVAILABLE')
