from dataclasses import dataclass
@dataclass
class LoopPolicy:
    max_iterations:int=4
    auto_apply_safe_edits:bool=True
    require_confirmation_for_destructive:bool=True
class Orchestrator:
    def __init__(self,policy=None): self.policy=policy or LoopPolicy()
    def should_continue(self,iteration,build_ok,test_ok):
        if build_ok and test_ok: return False,'verifying'
        if iteration>=self.policy.max_iterations: return False,'failed'
        return True,'debugging'
