from dataclasses import dataclass
from enum import Enum
class TaskStatus(str,Enum): queued='queued'; planning='planning'; reading='reading'; editing='editing'; building='building'; testing='testing'; debugging='debugging'; verifying='verifying'; completed='completed'; failed='failed'; cancelled='cancelled'
@dataclass
class AgentPolicy:
 max_iterations:int=4
 require_confirmation_for_destructive:bool=True
class CodingAgent:
    """Execution coordinator. Model/tool decisions remain explicit; this class never fabricates verification."""
    def __init__(self,policy=None): self.policy=policy or AgentPolicy()
    def next_state(self,status,passed):
        if status=='planning': return 'reading'
        if status=='reading': return 'editing'
        if status=='editing': return 'building'
        if status=='building': return 'testing' if passed else 'debugging'
        if status=='testing': return 'verifying' if passed else 'debugging'
        if status=='debugging': return 'building'
        if status=='verifying': return 'completed' if passed else 'failed'
        return status
