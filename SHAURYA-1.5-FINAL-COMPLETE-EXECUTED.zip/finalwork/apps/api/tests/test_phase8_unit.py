import subprocess
from pathlib import Path
import tempfile
import pytest
from app.git_service import LocalGitService, GitError
from app.approvals import SENSITIVE_ACTIONS, ApprovalState
from app.ci import CIProvider, CIState
from app.deployment.providers import DeploymentProvider, DeploymentState


def git_repo(tmp):
    g=LocalGitService(tmp); g.init()
    subprocess.run(['git','config','user.email','test@example.com'],cwd=tmp,check=True)
    subprocess.run(['git','config','user.name','SHAURYA Test'],cwd=tmp,check=True)
    Path(tmp,'README.md').write_text('one\n')
    g.stage(); assert g.commit('initial').ok
    return g

def test_git_status_branch_diff_commit_and_history():
    with tempfile.TemporaryDirectory() as d:
        g=git_repo(d)
        assert g.status().ok
        assert g.current_branch().ok
        assert g.create_branch('feature/test').ok
        Path(d,'README.md').write_text('two\n')
        assert 'README.md' in g.diff().stdout
        assert g.stage().ok
        assert g.commit('change').ok
        assert 'change' in g.history().stdout

def test_git_path_and_branch_protection():
    with tempfile.TemporaryDirectory() as d:
        g=LocalGitService(d)
        with pytest.raises(GitError): g.stage(['../secret'])
        with pytest.raises(GitError): g.create_branch('../bad')

def test_approval_boundary_actions_are_explicit():
    assert {'git_push','github_pull_request','deploy','deployment_rollback'} <= SENSITIVE_ACTIONS
    assert ApprovalState.PENDING.value == 'pending'

def test_ci_unavailable_is_explicit():
    import asyncio
    r=asyncio.run(CIProvider().verify('p'))
    assert r.state is CIState.UNAVAILABLE
    assert r.error == 'CI_PROVIDER_UNAVAILABLE'

def test_deployment_unavailable_is_explicit():
    import asyncio
    r=asyncio.run(DeploymentProvider().deploy({'project_id':'p'}))
    assert r.state is DeploymentState.FAILED
    assert r.error == 'DEPLOYMENT_PROVIDER_UNAVAILABLE'

def test_github_without_server_token_fails_closed():
    import asyncio
    from app.github.service import GitHubService, GitHubError
    async def run():
        try: await GitHubService(token='').repositories()
        except GitHubError as e: return str(e)
    assert asyncio.run(run()) == 'GITHUB_PROVIDER_UNAVAILABLE'

def test_deployment_health_requires_real_url():
    import asyncio
    from app.deployment.providers import HttpDeploymentProvider, DeploymentResult, DeploymentState
    r=asyncio.run(HttpDeploymentProvider().health_check(DeploymentResult(DeploymentState.LIVE,'http',deployment_id='x')))
    assert r.error == 'DEPLOYMENT_HEALTHCHECK_FAILED'
