from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    r = client.get('/health'); assert r.status_code == 200; assert r.json()['status'] == 'ok'

def test_project_and_file():
    p = client.post('/v1/projects', json={'name':'demo','description':'test'}); assert p.status_code == 200
    pid = p.json()['id']
    f = client.post(f'/v1/projects/{pid}/files', json={'path':'README.md','content':'hello'}); assert f.status_code == 200
    assert client.get(f'/v1/projects/{pid}/files').json()[0]['path'] == 'README.md'
