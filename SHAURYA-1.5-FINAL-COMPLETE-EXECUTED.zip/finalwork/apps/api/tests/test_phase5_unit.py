import asyncio, tempfile
from pathlib import Path
from app.agent.protocol import parse_tool_calls,tool_schemas
from app.agent.model_loop import ModelLoopError
from app.tools.agent_handlers import AgentToolHandlers
from app.tools.registry import TOOLS
from app.execution.sandbox import DockerSandbox
from app.filesafe.paths import safe_project_path,UnsafePath
from app.security_policy import Permission

def test_tool_schema_and_malformed_call():
    schemas=tool_schemas(TOOLS); names={x['function']['name'] for x in schemas}
    assert {'read_file','write_file','run_command','run_tests'}.issubset(names)
    calls=parse_tool_calls([].copy() if False else {'tool_calls':[{'id':'1','function':{'name':'read_file','arguments':'not-json'}}]})
    assert calls[0].arguments['_malformed'] is True

def test_agent_file_edit_is_project_bound():
    with tempfile.TemporaryDirectory() as d:
        root=Path(d); (root/'a.txt').write_text('hello')
        h=AgentToolHandlers(root,DockerSandbox(),[Permission.READ,Permission.WRITE,Permission.EXECUTE])
        result=asyncio.run(h.execute('edit_file',{'path':'a.txt','old':'hello','new':'hello world'}))
        assert result['ok'] and (root/'a.txt').read_text()=='hello world'
        result=asyncio.run(h.execute('read_file',{'path':'../escape'}))
        assert not result['ok'] and 'PATH_TRAVERSAL' in result['error']

def test_delete_requires_human_approval():
    with tempfile.TemporaryDirectory() as d:
        h=AgentToolHandlers(Path(d),DockerSandbox(),[Permission.READ,Permission.WRITE,Permission.EXECUTE])
        result=asyncio.run(h.execute('delete_file',{'path':'a.txt'}))
        assert result['error']=='HUMAN_APPROVAL_REQUIRED'

def test_sandbox_unavailable_is_explicit_when_docker_missing():
    import shutil
    if shutil.which('docker') is None:
        with tempfile.TemporaryDirectory() as d:
            async def run():
                try: await DockerSandbox().run(Path(d),'echo ok')
                except Exception as e: return str(e)
            assert asyncio.run(run())=='SANDBOX_RUNTIME_UNAVAILABLE'
