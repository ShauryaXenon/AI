from pathlib import Path
from app.execution.runtime import command_allowed,detect_runtime

def test_command_policy():
 assert command_allowed('pytest -q')
 assert not command_allowed('docker run alpine')
 assert not command_allowed('cat /proc/1/environ')

def test_runtime_detection(tmp_path):
 (tmp_path/'package.json').write_text('{}'); assert detect_runtime(tmp_path)=='node:22-alpine'
 (tmp_path/'package.json').unlink(); (tmp_path/'requirements.txt').write_text(''); assert detect_runtime(tmp_path)=='python:3.13-alpine'
