import asyncio, tempfile
from pathlib import Path
from app.agent.model_loop import run_tool_loop, ModelLoopError
from app.tools.agent_handlers import AgentToolHandlers
from app.execution.sandbox import DockerSandbox
from app.security_policy import Permission

def test_model_provider_unavailable_is_explicit():
    async def run():
        with tempfile.TemporaryDirectory() as d:
            h=AgentToolHandlers(Path(d),DockerSandbox(),[Permission.READ,Permission.WRITE,Permission.EXECUTE])
            try:
                await run_tool_loop([{'role':'user','content':'integration probe'}],h,max_turns=1)
            except ModelLoopError as exc:
                return str(exc)
    assert asyncio.run(run()) == 'MODEL_PROVIDER_UNAVAILABLE'

def test_sandbox_and_model_fail_closed_without_infrastructure():
    import shutil
    assert shutil.which('docker') is None
