import tempfile
from pathlib import Path
from app.filesafe.paths import safe_project_path,UnsafePath,safe_archive_member
from app.documents.pipeline import DocumentPipeline,UnsupportedDocument
from app.research.providers import ResearchSource,ResearchEngine
from app.repository.index import RepositoryIndex
from app.review.engine import SecurityReview
from app.agent.engine import AgentBudget,AgentState,AgentLimits
from app.models.routing import ModelRegistry,ModelSpec,ModelCapabilities
from app.memory.store import MemoryStore
from app.security_policy import require_permissions

def test_path_traversal_and_archive_blocked():
    with tempfile.TemporaryDirectory() as d:
        assert safe_project_path(d,'src/a.py').parent.name=='src'
        try: safe_project_path(d,'../escape')
        except UnsafePath: pass
        else: assert False
    try: safe_archive_member('../../x')
    except UnsafePath: pass
    else: assert False

def test_document_support_is_parser_explicit():
    p=DocumentPipeline(parsers={'txt':lambda b:{'ok':b}})
    assert p.detect('a.txt')=='txt'
    try: p.extract('a.pdf',b'x')
    except Exception as e: assert type(e).__name__ in {'DocumentParseError','DocumentParserUnavailable'}
    else: assert False

def test_research_source_hash_and_dedupe():
    a=ResearchSource.create('https://example.com/a','A','hello')
    b=ResearchSource.create('https://example.com/a','A','hello')
    assert a.content_hash==b.content_hash
    assert len(ResearchEngine().dedupe([a,b]))==1

def test_repository_index_and_security_review():
    class F:
        path='app.py'; content='API_KEY = "secret"\ndef hello():\n    return 1\n'
    idx=RepositoryIndex([F()]).build(); assert idx.metadata[0].language=='python'; assert any(x['name']=='hello' for x in idx.symbols)
    findings=SecurityReview().review([F()]); assert any(x['severity']=='HIGH' for x in findings)

def test_agent_budget_stops_repetition():
    b=AgentBudget(AgentLimits(max_iterations=2,max_tool_calls=1,max_file_changes=1,max_tokens=10,max_seconds=999))
    s=AgentState('x'); ok,_=b.next_iteration(s); assert ok
    b.next_iteration(s); ok,reason=b.allow(s); assert not ok and reason=='ITERATION_LIMIT'

def test_model_routing_by_capability():
    r=ModelRegistry(); r.register(ModelSpec('a','text',ModelCapabilities(text=True))); r.register(ModelSpec('b','vision',ModelCapabilities(vision=True,tool_calling=True)))
    assert r.select({'vision':True,'tool_calling':True}).model=='vision'

def test_memory_authorization():
    m=MemoryStore(); item=m.add('u1','project','secret','user-approved'); assert m.get('u1',item.id)['content']=='secret'
    try: m.get('u2',item.id)
    except PermissionError: pass
    else: assert False

def test_permission_boundary():
    assert require_permissions(['READ'],['READ'])
    try: require_permissions(['WRITE'],['READ'])
    except PermissionError: pass
    else: assert False
