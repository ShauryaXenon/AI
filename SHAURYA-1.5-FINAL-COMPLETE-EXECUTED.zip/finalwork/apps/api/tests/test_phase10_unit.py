import io, zipfile
import pytest
from app.documents.pipeline import inspect_archive
from app.documents.pipeline import DocumentPipeline, UnsupportedDocument, DocumentParserUnavailable
from app.production_config import validate_production_config
from app.config import Settings
from app.security_hardening import redact

def test_phase10_missing_providers_not_verified():
    r=validate_production_config(Settings(ai_base_url='',ai_api_key='',ai_model='',github_token='',ci_provider_url='',ci_api_key='',deployment_base_url='',deployment_api_key=''))
    s={x['key']:x['status'] for x in r['findings']}
    assert s['model_provider']=='NOT_CONFIGURED' and s['github']=='NOT_CONFIGURED' and s['ci']=='NOT_CONFIGURED' and s['deployment']=='NOT_CONFIGURED'

def test_phase10_archive_traversal_blocked():
    b=io.BytesIO()
    with zipfile.ZipFile(b,'w') as z:z.writestr('../escape.txt','bad')
    with pytest.raises(Exception,match='ARCHIVE_PATH_TRAVERSAL'):inspect_archive(b.getvalue())

def test_phase10_builtin_document_formats_real():
    p=DocumentPipeline()
    for n,d in [('x.txt',b'hello'),('x.md',b'# hi'),('x.json',b'{"a":1}'),('x.csv',b'a,b\n1,2')]: assert p.extract(n,d).pages

def test_phase10_unsupported_extension_explicit():
    with pytest.raises(UnsupportedDocument,match='UNSUPPORTED_DOCUMENT_FORMAT'):DocumentPipeline().extract('x.exe',b'bad')

def test_phase10_optional_pdf_never_faked():
    p=DocumentPipeline()
    if 'pdf' not in p.parsers:
        with pytest.raises(DocumentParserUnavailable,match='DOCUMENT_PARSER_UNAVAILABLE:pdf'):p.extract('x.pdf',b'bad')

def test_phase10_secret_redaction_recursive():
    o=redact({'authorization':'abc','nested':[{'token':'xyz','safe':'ok'}]})
    assert o['authorization']=='[REDACTED]' and o['nested'][0]['token']=='[REDACTED]' and o['nested'][0]['safe']=='ok'
