# SHAURYA 1.5

**Final frozen release-candidate repository — Phases 1–10**

## Status

**RELEASE CANDIDATE — EXTERNAL INTEGRATION INCOMPLETE**

SHAURYA 1.5 is an AI software-engineering workspace combining a web frontend, FastAPI backend, persistent project/task state, model and tool abstractions, repository intelligence, sandbox architecture, research, document/knowledge workflows, multimodal boundaries, Git/GitHub, CI, deployment, approvals, security controls, and observability.

This repository is frozen at Phase 10. No Phase 11 is defined. Remaining work is environment activation and genuine integration testing.

## Verified in the current audit environment

- Python compilation
- Focused Phase 8–10 tests: 25 passed
- Existing security boundary tests
- Local Git tests
- Alembic migration ordering/static validation
- Docker Compose YAML validation
- Repository structure and configuration inspection
- Secret-pattern scan

## Current environment limitations

- PostgreSQL / `asyncpg`: **BLOCKED**
- Redis: **BLOCKED**
- Docker / Compose runtime: **UNAVAILABLE**
- Frontend dependencies/build: **BLOCKED**
- AI provider: **NOT_CONFIGURED**
- GitHub: **NOT_CONFIGURED**
- CI: **NOT_CONFIGURED**
- Deployment: **NOT_CONFIGURED**
- Research: **NOT_CONFIGURED**
- Vision: **NOT_CONFIGURED**
- Embeddings: **NOT_CONFIGURED**

The existing PostgreSQL-backed test failure is retained and reported rather than hidden or replaced with a mock.

## Documentation

- `SHAURYA-1.5-CAPABILITY-MATRIX.md` — frozen capability/evidence matrix
- `SHAURYA-1.5-FINAL-ARCHITECTURE.md` — actual implemented architecture
- `SHAURYA-1.5-RELEASE-NOTES.md` — release-candidate notes and limitations
- `docs/AGENT.md` — agent runtime
- `docs/ARCHITECTURE.md` — architecture details
- `docs/SECURITY.md` — security boundaries
- `docs/DEPLOYMENT.md` — deployment requirements
- `docs/INTEGRATION.md` — integration instructions and limitations
- `docs/RELEASE.md` — release checklist

## Local checks

```bash
python -m compileall -q apps/api/app
PYTHONPATH=apps/api pytest -q apps/api/tests
alembic upgrade head --sql > /tmp/shaurya-upgrade.sql
```

With the required infrastructure and dependencies available, run the real database, Redis, Docker, frontend, and provider integration checks described in the documentation.

## Anti-fabrication boundary

Implemented does not mean verified. Configured does not mean working. Unavailable infrastructure is reported explicitly. No live AI response, GitHub mutation, CI result, deployment, customer/user, benchmark, or security certification is claimed without corresponding evidence.
