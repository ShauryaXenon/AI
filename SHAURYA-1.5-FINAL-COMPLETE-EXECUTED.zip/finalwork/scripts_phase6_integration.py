"""Phase 6 environment probe. Reports PASS/FAIL/BLOCKED; never simulates results."""
import os, shutil, socket, urllib.request

def tcp(host, port, timeout=1):
    try:
        with socket.create_connection((host,port),timeout=timeout): return True
    except OSError: return False

checks=[]
checks.append(('Docker sandbox','PASS' if shutil.which('docker') else 'BLOCKED','docker executable unavailable'))
checks.append(('PostgreSQL TCP','PASS' if tcp('127.0.0.1',5432) else 'BLOCKED','no local PostgreSQL listener'))
checks.append(('Redis TCP','PASS' if tcp('127.0.0.1',6379) else 'BLOCKED','no local Redis listener'))
checks.append(('Model provider','PASS' if os.getenv('AI_BASE_URL') and os.getenv('AI_API_KEY') and os.getenv('AI_MODEL') else 'BLOCKED','AI_BASE_URL/AI_API_KEY/AI_MODEL not configured'))
checks.append(('Node.js','PASS' if shutil.which('node') else 'BLOCKED',''))
checks.append(('npm','PASS' if shutil.which('npm') else 'BLOCKED',''))
for name,status,reason in checks: print(f'{name}\t{status}\t{reason}')
