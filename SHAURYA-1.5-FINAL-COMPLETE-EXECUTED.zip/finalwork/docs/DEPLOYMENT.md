# Deployment

Docker Compose defines PostgreSQL, Redis, API, sandbox-worker, and frontend services. Production deployment is provider-neutral through the Phase 8 HTTP deployment adapter and remains approval-gated.

Use disposable/staging environments for integration tests. A missing deployment provider is reported as `DEPLOYMENT_PROVIDER_UNAVAILABLE` / `NOT_CONFIGURED`; no deployment success is inferred.

## Release-candidate checklist

1. Configure a non-default signing secret and explicit HTTPS CORS origins.
2. Provision PostgreSQL and Redis and run the complete Alembic chain.
3. Provision the sandbox runtime without weakening resource/network restrictions.
4. Configure and verify a model provider before live agent testing.
5. Configure GitHub/CI/deployment providers only against dedicated test/staging resources.
6. Exercise approval-gated push, PR, deployment, and rollback flows before any production publish.
7. Build the frontend with installed dependencies and perform browser E2E separately.
