# SHAURYA 1.5 — Release Candidate

## What it is
SHAURYA 1.5 is an AI-assisted software-engineering workspace with authentication, project/file/version management, conversations, agent orchestration, controlled tools, sandbox architecture, repository intelligence, research/document/knowledge capabilities, local Git, GitHub/CI/deployment provider boundaries, approvals, rollback boundaries, and observability/security controls.

## Architecture
Browser (Next.js/React/TypeScript) → FastAPI → task/agent/tool/provider boundaries → persistence and isolated execution. External providers remain explicit boundaries and are never represented as live when unavailable.

## Setup
1. Copy `.env.example` to `.env` and configure required secrets.
2. Provision PostgreSQL and Redis, or use the supplied Docker Compose environment.
3. Run Alembic migrations.
4. Install API and frontend dependencies.
5. Start the API and frontend.
6. Run the Phase 10 audit before enabling external mutations.

## Provider configuration
- Model: `AI_BASE_URL`, `AI_API_KEY`, `AI_MODEL`; optional fallback settings are documented in `.env.example`.
- GitHub: `GITHUB_TOKEN` plus GitHub API/OAuth settings where applicable.
- CI: `CI_PROVIDER_URL`, `CI_API_KEY`, `CI_PROVIDER`.
- Deployment: `DEPLOYMENT_BASE_URL`, `DEPLOYMENT_API_KEY`, `DEPLOYMENT_PROVIDER`.
- Research: `RESEARCH_SEARCH_URL`, `RESEARCH_API_KEY`.
- Vision: `VISION_BASE_URL`, `VISION_API_KEY`, `VISION_MODEL`.
- Embeddings: `EMBEDDING_BASE_URL`, `EMBEDDING_API_KEY`, `EMBEDDING_MODEL`.

## Security and approvals
Repository/research content is untrusted data. Sensitive GitHub, deployment, publishing, and rollback operations remain approval-gated. Secrets are not included in readiness reports or audit output.

## Limitations
The Phase 10 audit environment used for this release candidate did not have Docker, PostgreSQL/`asyncpg`, Redis, provider credentials, or frontend `node_modules`. Therefore live AI repair, GitHub, CI, deployment, database, Redis, sandbox, and browser verification are not claimed.

## Production checklist
- [ ] Configure production database and Redis.
- [ ] Configure sandbox runtime.
- [ ] Configure and live-test model provider/fallback.
- [ ] Configure and test GitHub against a dedicated test repository.
- [ ] Configure CI and staging deployment.
- [ ] Install/build frontend and run browser E2E.
- [ ] Run full integration suite in the provisioned environment.
- [ ] Review `phase10-production-readiness.json` and resolve all BLOCKED/NOT_CONFIGURED items.
- [ ] Obtain explicit human approval for any production publish.
