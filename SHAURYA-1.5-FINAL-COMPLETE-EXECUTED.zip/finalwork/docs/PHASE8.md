# SHAURYA 1.5 — Phase 8

Phase 8 extends the Phase 7 intelligence platform with production software-engineering workflow boundaries.

## Git

`app/git_service.py` provides project-scoped local Git operations: initialization, status, branches, switching, diff, history, staging and commits. Workspace state is stored under `/workspaces` in Compose via a persistent volume.

External push is approval-gated. No GitHub token is passed to the browser.

## GitHub

`app/github/service.py` is a real GitHub REST adapter using a server-side bearer token. It supports repository listing/metadata, repository creation, branches, commits, pull requests, issues and clone metadata. Missing credentials return `GITHUB_PROVIDER_UNAVAILABLE`.

Remote changes such as push and PR creation require a persisted approval record.

## CI

`app/ci.py` defines provider-neutral CI states and an HTTP adapter. No CI success is asserted unless a configured provider returns a result.

## Deployment

`app/deployment/providers.py` defines deployment states and an HTTP provider adapter. Deployment and rollback require persisted approval records. Health checks are performed after a successful provider response; failed health checks are reported as `DEPLOYMENT_HEALTHCHECK_FAILED`.

## Environments

Development, staging and production metadata are stored separately. Only references/metadata are persisted; plaintext production secrets are not accepted as a frontend contract.

## Production readiness

`GET /v1/projects/{project_id}/production-readiness` reports each major subsystem as `VERIFIED`, `IMPLEMENTED`, `BLOCKED`, or `UNAVAILABLE`. Architecture alone is never marked verified.

## Local verification

This environment has Git, but does not provide Docker, PostgreSQL/asyncpg, Redis, configured model credentials, GitHub credentials, deployment credentials, or installed frontend dependencies. Those boundaries are therefore not reported as live successes.
