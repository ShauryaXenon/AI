# SHAURYA 1.5 — Phase 4

Phase 4 extends the Phase 3 engineering foundation with autonomous-task state, event streaming, repository indexing, multimodal/document abstractions, research source persistence, review/security analysis, permissions, memory, model capability routing, deployment/GitHub boundaries, evaluation utilities, and a responsive coding workspace.

## Truth boundary

- Docker execution remains real and is not replaced by a fake runner. If Docker is unavailable, the API returns `SANDBOX_RUNTIME_UNAVAILABLE`.
- Research returns `RESEARCH_PROVIDER_UNAVAILABLE` until a real provider is configured; no synthetic web sources are generated.
- Vision returns `VISION_PROVIDER_UNAVAILABLE` until a vision-capable provider is connected.
- PDF/DOC/DOCX/XLS/XLSX/PPT/PPTX extraction returns a parser-unavailable error unless an actual parser is installed and registered. Plain text, Markdown, JSON, XML, YAML and CSV are directly decoded.
- GitHub and deployment endpoints are explicit provider boundaries and never report successful external changes without a provider.
- Pricing is not invented. Usage records currently store token estimates/durations; estimated cost is nullable.

## Run

Use Docker Compose for PostgreSQL/Redis/API/web. Apply `database/004_phase4.sql` through the project's migration process in production. The API currently uses SQLAlchemy `create_all` for local bootstrap; Alembic migration wiring remains a production boundary.

## Phase 5 continuation
Phase 5 adds the model-driven tool protocol and autonomous execution runtime on top of the Phase 4 foundation. The agent uses OpenAI-compatible structured tool calls, validates arguments, routes every operation through project-scoped handlers and permission checks, materializes a temporary project workspace, syncs successful file changes back into versioned database records, records tool calls and task events, and runs build/test commands through the existing Docker sandbox. Docker absence remains an explicit `SANDBOX_RUNTIME_UNAVAILABLE` state.

## Phase 5 validation boundary
The model-driven loop uses an OpenAI-compatible `/chat/completions` endpoint with structured function tools. Tool arguments are JSON-validated before execution. Project files are materialized into a temporary workspace, edits are synchronized back into versioned `ProjectFile`/`FileVersion` records, tool calls and task events are persisted, and build/test commands use the Phase 3 Docker sandbox. Sensitive destructive deletion remains behind an explicit human-approval result. If no model provider is configured, the model layer returns `No provider is configured`; if Docker is absent, execution returns `SANDBOX_RUNTIME_UNAVAILABLE`.
