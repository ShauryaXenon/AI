# SHAURYA 1.5 architecture

Browser (Next.js/React/TypeScript)
→ FastAPI API
→ Orchestrator/provider boundary
→ configured model provider(s)
→ streaming SSE back to browser

Planned expansion:
API → auth/tenant middleware → task queue → orchestrator → planner/tool router → isolated tools/sandbox → verifier → memory → response.

Provider boundary is intentionally OpenAI-compatible today so a model provider can be swapped without rewriting the UI. A future native SHAURYA model can implement the same internal provider contract.

## Phase 9 Hardening

The agent pipeline now uses bounded context selection and explicit task transition validation. External content remains untrusted data, sensitive operations remain approval-gated, and production configuration is validated without exposing secrets.

## Phase 10 release-candidate audit

The release candidate keeps the provider-neutral boundaries from Phases 1–9 and adds a deterministic environment/release audit. Local verification is separated from live-provider verification. PostgreSQL, Redis, Docker, model, GitHub, CI, deployment, research, vision, embeddings, and browser E2E are never treated as verified merely because adapters exist.
