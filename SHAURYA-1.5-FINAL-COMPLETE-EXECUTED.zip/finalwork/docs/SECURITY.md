# Security Boundaries

Phase 9 hardens external-input boundaries with project-root enforcement, symlink escape checks, archive traversal checks, bounded text, secret redaction, and explicit approval records for sensitive GitHub/deployment actions.

Retrieved documents, research content, repository files, and model-generated tool arguments are **data**, not trusted instructions. They cannot grant permissions.

Sensitive values are never included in production-readiness output. Destructive/external actions remain approval-gated.

## Phase 10 final audit

The release audit checks secret-pattern leakage, archive traversal, project path handling, symlink boundaries, prompt-injection trust labeling, approval boundaries, and recursive log redaction through automated tests and static inspection. This is an application-level security audit, not a penetration test or certification. Unavailable infrastructure is recorded as blocked/unavailable rather than bypassed.
