# Agent Reliability

The coding agent uses bounded repository context, structured tool-call parsing, explicit budgets, persistent task/tool/model records, security review, and verification states.

Phase 9 adds deterministic transition validation and malformed-tool-call recovery. A live autonomous repair loop requires a configured model provider, database, and sandbox runtime and is not marked verified without execution.

## Phase 10 live verification boundary

A live autonomous repair claim requires an actually configured model, durable task state, executable sandbox, and a disposable repository containing a deterministic failure. The release candidate deliberately records this as not configured/not tested when those dependencies are absent. No simulated model response is accepted as evidence.
