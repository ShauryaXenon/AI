# SHAURYA 1.5 — Phase 3

Phase 3 adds a Docker-backed execution boundary, persistent execution/task records, runtime detection, command policy, build/test command detection, error normalization, coding-agent loop primitives, and a Monaco workspace.

## Execution

The API never executes project code through Python `exec`, shell subprocesses, or the FastAPI process. It stages an authorized project into a temporary workspace and invokes Docker with:

- `--network none`
- memory and CPU limits
- PID limit
- dropped Linux capabilities
- `no-new-privileges`
- a temporary mounted workspace only
- no host credentials

Docker is a runtime dependency. If it is unavailable the API returns `SANDBOX_RUNTIME_UNAVAILABLE`; it does not fabricate output.

## Verification

Execution status is separate from verification. A generated or edited project is not considered verified until real build/test results satisfy the verification criteria.

## Local requirements

- PostgreSQL
- Python 3.13+
- Node.js 22+
- Docker Engine for execution
- configured AI provider

The browser workspace uses Monaco and requires the web dependencies to be installed before `next build` can be performed.
