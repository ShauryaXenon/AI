# Integration and Verification

Phase 9 separates **implemented** behavior from **observed** runtime behavior. Configure dependencies before calling them live.

## Local checks
```bash
python -m compileall -q apps/api/app
PYTHONPATH=apps/api pytest -q apps/api/tests
alembic upgrade head
```

## External services
- Model: `AI_BASE_URL`, `AI_API_KEY`, `AI_MODEL`.
- GitHub: `GITHUB_TOKEN` and API configuration.
- CI: `CI_PROVIDER_URL`, `CI_API_KEY`, `CI_PROVIDER`.
- Deployment: `DEPLOYMENT_BASE_URL`, `DEPLOYMENT_API_KEY`, `DEPLOYMENT_PROVIDER`.
- PostgreSQL/Redis: use Docker Compose or equivalent reachable services.

Unavailable dependencies must remain explicitly unavailable; the application does not synthesize successful results.

## Phase 10 final audit

Run:
```bash
python scripts/phase10_audit.py
PYTHONPATH=apps/api pytest -q apps/api/tests
alembic upgrade head --sql > /tmp/shaurya-upgrade.sql
npm --prefix apps/web install
npm --prefix apps/web run build
```

The audit writes machine-readable readiness and integration matrices. `AVAILABLE` means configuration/tool availability only; it is not equivalent to a successful live integration. `NOT_TESTED` is never promoted to `VERIFIED`.

## Final freeze

The Phase 1–10 repository is frozen. The current status remains **RELEASE CANDIDATE — EXTERNAL INTEGRATION INCOMPLETE**. Configuration presence is not treated as runtime verification. Future work should activate the documented external dependencies and run genuine integration tests; no Phase 11 architecture is defined.
