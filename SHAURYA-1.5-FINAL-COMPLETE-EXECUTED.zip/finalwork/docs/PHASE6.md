# SHAURYA 1.5 — Phase 6 Integration & Verification

Phase 6 prioritizes integration and truthful verification over feature expansion.

## Runtime contract

`User task -> model -> structured tool call -> authorization -> repository tools -> versioned files -> sandbox -> build/test -> error -> model continuation -> security review -> verification`.

The model loop is provider-independent and uses the existing OpenAI-compatible abstraction. Tool calls are schema-validated, permission checked, executed inside a project workspace, and returned to the model as tool results. The loop has iteration, tool-call, token, file-change and time budgets.

## Persistence

PostgreSQL is the durable source of truth. Phase 6 adds an Alembic lifecycle. API startup validates database connectivity; schema creation is no longer performed with `Base.metadata.create_all()`.

Run locally after dependencies are installed:

```bash
cp .env.example .env
# set POSTGRES_PASSWORD and JWT_SECRET
alembic upgrade head
```

Compose runs `alembic upgrade head` before starting the API.

## Docker sandbox

The existing Docker sandbox remains fail-closed. If the Docker executable is unavailable, execution returns `SANDBOX_RUNTIME_UNAVAILABLE` and no success result is generated.

The current API container invokes the Docker CLI for the sandbox path. Production deployments should isolate that capability in a dedicated worker/runtime boundary rather than exposing an unrestricted host Docker socket to the API.

## Redis

Redis is configured as a service and has a health check. `/health/dependencies` probes PostgreSQL, Redis, the configured model provider, and Docker independently. PostgreSQL remains the durable store.

## Model provider

A model provider is considered available only when base URL, API key and model are configured. There is no local fake provider. If none is configured, the agent returns `MODEL_PROVIDER_UNAVAILABLE`.

## Frontend verification

The repository declares the required npm dependencies. A production build must be performed in an environment where those dependencies can be installed. The Phase 6 build environment has Node/npm but no cached npm packages and no network access, so the frontend build is not marked as verified.

## Integration matrix

| Component | Status in this environment | Reason |
|---|---|---|
| Python compile | PASS | `compileall` completed |
| Unit/security/tool tests | PASS | 17 tests passed in focused Phase 3–6 suite |
| Full API suite | FAIL | existing DB test blocked by missing `asyncpg` package in runner |
| Alembic offline migration generation | PASS | generated PostgreSQL migration SQL successfully |
| PostgreSQL connection | BLOCKED | no local PostgreSQL listener; `asyncpg` unavailable in runner |
| Redis connection | BLOCKED | no local Redis listener |
| Docker sandbox | BLOCKED | Docker executable unavailable |
| Model provider | BLOCKED | no AI provider credentials configured |
| Real model tool call | BLOCKED | model provider unavailable |
| Real build/test in sandbox | BLOCKED | Docker unavailable |
| Model repair/retest | BLOCKED | model provider and Docker unavailable |
| Security verification engine | PASS | deterministic defensive review unit path tested |
| Local Git status/diff/history | PASS | exercised in a temporary Git repository |
| GitHub external operations | BLOCKED | no OAuth/API authorization configured |
| Frontend production build | BLOCKED | npm packages could not be installed offline |

## Important distinction

A PASS in the unit suite does not mean the full distributed system has been verified. The unavailable infrastructure above is deliberately reported as BLOCKED rather than converted into successful integration results.
