# SHAURYA 1.5 — Phase 7 Intelligence Layer

Phase 7 extends the Phase 6 engineering runtime with provider-independent research, document extraction, multimodal content, vision, structured document chunking, embeddings, vector retrieval, and citation provenance.

## Provider boundaries

- `RESEARCH_SEARCH_URL` configures an HTTP search adapter. No endpoint means `RESEARCH_PROVIDER_UNAVAILABLE`.
- `EMBEDDING_BASE_URL`, `EMBEDDING_API_KEY`, and `EMBEDDING_MODEL` configure an OpenAI-compatible embedding endpoint. Missing configuration returns `EMBEDDING_PROVIDER_UNAVAILABLE`.
- `VISION_BASE_URL`, `VISION_API_KEY`, and `VISION_MODEL` configure an OpenAI-compatible vision endpoint. Missing configuration returns `VISION_CAPABILITY_UNAVAILABLE`.

External research is treated as **untrusted data**. Retrieved content is never treated as executable instructions by the platform.

## Documents

The pipeline performs extension/type validation, size checks, parser availability detection, extraction, structural page/sheet/slide references, and chunking. Optional parser dependencies are declared in `requirements.txt`; an unavailable parser returns `DOCUMENT_PARSER_UNAVAILABLE:<format>`.

PDF pages, DOCX paragraphs/tables, XLSX sheets/cells, and PPTX slides are represented with source references when the corresponding parser is installed.

## Knowledge base

Knowledge documents are project-scoped. Extracted chunks persist in PostgreSQL. Lexical retrieval works without embeddings. Embedding/vector retrieval is only used when a real embedding provider has produced vectors; the system never fabricates vectors.

## Multimodal

Conversation blocks support `text`, `image`, `document`, `code`, and `tool_result`. Binary image input is validated before reaching a vision provider.

## Security

Project isolation, path validation, upload limits, archive inspection, unsafe public-URL filtering, and explicit network permission boundaries remain enforced. External content is marked untrusted in agent tool results.

## Verification boundary

The Phase 7 unit suite can verify provider-unavailable and parser-independent behavior without pretending that external providers are live. Live research, vision, and embedding tests require real configured services.
