-- Phase 3 schema additions are represented by SQLAlchemy models.
-- Apply with Alembic in production; this file documents the execution records.
CREATE INDEX IF NOT EXISTS ix_executions_project_created ON executions(project_id, created_at DESC);
CREATE INDEX IF NOT EXISTS ix_tasks_project_updated ON tasks(project_id, updated_at DESC);
CREATE INDEX IF NOT EXISTS ix_tool_calls_task_created ON tool_calls(task_id, created_at DESC);
