-- Phase 5 durable agent-loop indexes. PostgreSQL-compatible; create_all remains the local bootstrap path.
CREATE INDEX IF NOT EXISTS ix_task_events_task_created ON task_events(task_id, created_at);
CREATE INDEX IF NOT EXISTS ix_tool_calls_task_created ON tool_calls(task_id, created_at);
CREATE INDEX IF NOT EXISTS ix_file_versions_file_version ON file_versions(file_id, version);
CREATE INDEX IF NOT EXISTS ix_model_requests_user_created ON model_requests(user_id, created_at);
CREATE INDEX IF NOT EXISTS ix_usage_user_created ON usage(user_id, created_at);
