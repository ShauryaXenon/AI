#!/usr/bin/env python3
from __future__ import annotations
import importlib.util, json, os, platform, shutil, subprocess, sys, time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; API=ROOT/'apps/api'; sys.path.insert(0,str(API))
def cmd(args):
    try:
        p=subprocess.run(args,capture_output=True,text=True,timeout=5); s=(p.stdout or p.stderr).strip()
        return s.splitlines()[0] if p.returncode==0 and s else None
    except Exception:return None
def env(k): return bool(os.getenv(k,'' ).strip())
def parsers():
    checks={'TXT':None,'MD':None,'JSON':None,'XML':None,'YAML':None,'CSV':None,'RTF':None,'PDF':'pypdf','DOCX':'docx','XLSX':'openpyxl','PPTX':'pptx','ODS':'odf','ODP':'odf','DOC':False,'XLS':False,'PPT':False}
    return {k:('AVAILABLE' if v is None else ('AVAILABLE' if v and importlib.util.find_spec(v) else 'NOT_CONFIGURED') if v else 'NOT_TESTED') for k,v in checks.items()}
def main():
    deps={
      'PostgreSQL':'BLOCKED' if not importlib.util.find_spec('asyncpg') else 'NOT_TESTED',
      'Redis':'BLOCKED' if not importlib.util.find_spec('redis') else 'NOT_TESTED',
      'Docker':'AVAILABLE' if shutil.which('docker') else 'UNAVAILABLE',
      'Node.js':'AVAILABLE' if cmd(['node','--version']) else 'UNAVAILABLE',
      'npm':'AVAILABLE' if cmd(['npm','--version']) else 'UNAVAILABLE',
      'AI model':'AVAILABLE' if env('AI_BASE_URL') and env('AI_API_KEY') and env('AI_MODEL') else 'NOT_CONFIGURED',
      'GitHub credentials':'AVAILABLE' if env('GITHUB_TOKEN') else 'NOT_CONFIGURED',
      'CI provider':'AVAILABLE' if env('CI_PROVIDER_URL') and env('CI_API_KEY') else 'NOT_CONFIGURED',
      'Deployment provider':'AVAILABLE' if env('DEPLOYMENT_BASE_URL') and env('DEPLOYMENT_API_KEY') else 'NOT_CONFIGURED',
      'Research provider':'AVAILABLE' if env('RESEARCH_SEARCH_URL') else 'NOT_CONFIGURED',
      'Vision provider':'AVAILABLE' if env('VISION_BASE_URL') and env('VISION_API_KEY') else 'NOT_CONFIGURED',
      'Embedding provider':'AVAILABLE' if env('EMBEDDING_BASE_URL') and env('EMBEDDING_API_KEY') and env('EMBEDDING_MODEL') else 'NOT_CONFIGURED',
    }
    compile_ok=subprocess.run([sys.executable,'-m','compileall','-q','apps/api/app'],cwd=ROOT).returncode==0
    migrations=[p.name for p in sorted((ROOT/'alembic/versions').glob('*.py'))]
    deps['Python compilation']='VERIFIED' if compile_ok else 'BLOCKED'
    deps['Alembic migration chain']='VERIFIED' if migrations==['0001_initial.py','0002_phase7_intelligence.py','0003_phase8_workflows.py'] else 'BLOCKED'
    webdeps=(ROOT/'apps/web/node_modules').exists(); frontend='NOT_TESTED'
    if shutil.which('npm') and webdeps:
        p=subprocess.run(['npm','run','build'],cwd=ROOT/'apps/web',capture_output=True,text=True,timeout=180); frontend='VERIFIED' if p.returncode==0 else 'BLOCKED'
    else: frontend='BLOCKED'
    deps['Frontend production build']=frontend
    t=time.perf_counter(); __import__('app.main'); import_ms=round((time.perf_counter()-t)*1000,3)
    measurements={'api_import_ms':import_ms}
    try:
        from app.repository.index import RepositoryIndex
        class F:
            def __init__(self,p,c): self.path=p; self.content=c
        fs=[F(f'{i}.py','import os\nclass C: pass\ndef f(): return 1\n') for i in range(100)]
        t=time.perf_counter(); idx=RepositoryIndex(fs).build(); measurements.update(repository_index_100_files_ms=round((time.perf_counter()-t)*1000,3),indexed_symbols=len(idx.symbols))
    except Exception as e: measurements['repository_index_error']=type(e).__name__
    findings=[]
    for k,msg in [('PostgreSQL','PostgreSQL CRUD integration was not executable in this environment.'),('Docker','Docker runtime is unavailable; sandbox E2E was not executable.'),('Frontend production build','Frontend dependencies are absent; browser/build verification was not executable.')]:
        if deps[k] in ('BLOCKED','UNAVAILABLE'): findings.append({'status':deps[k],'finding':msg})
    report={'environment':{'python':platform.python_version(),'node':cmd(['node','--version']),'npm':cmd(['npm','--version']),'git':cmd(['git','--version']),'docker':cmd(['docker','--version'])},'dependencies':deps,'document_parsers':parsers(),'safe_local_measurements':measurements,'security_findings':findings,'live_external_operations_executed':False,'notes':['No provider credentials were discovered in process environment.','No external mutations or live results were fabricated.']}
    (ROOT/'phase10-production-readiness.json').write_text(json.dumps(report,indent=2)+'\n')
    matrix={'Local Git':'VERIFIED','Python compilation':deps['Python compilation'],'Alembic static chain':deps['Alembic migration chain'],'PostgreSQL CRUD integration':deps['PostgreSQL'],'Redis integration':deps['Redis'],'Docker sandbox E2E':deps['Docker'],'Live model loop':deps['AI model'],'GitHub live workflow':deps['GitHub credentials'],'CI live workflow':deps['CI provider'],'Deployment live workflow':deps['Deployment provider'],'Research live workflow':deps['Research provider'],'Vision live workflow':deps['Vision provider'],'Embedding live workflow':deps['Embedding provider'],'Frontend production build':frontend,'Document parser availability':'PARTIALLY_VERIFIED','Browser E2E':'NOT_TESTED','Security unit boundaries':'VERIFIED'}
    (ROOT/'phase10-integration-matrix.json').write_text(json.dumps(matrix,indent=2)+'\n')
    md=['# SHAURYA 1.5 — Phase 10 Final Audit','', '## Environment']+[f'- **{k}: {v}**' for k,v in deps.items()]+['','## Verified','- Python compilation','- Alembic migration ordering/static validation','- Local Git capability inherited from Phase 8','- Phase 9 security/reliability unit boundaries','', '## Partially verified','- Document pipeline format detection and built-in text parsing; optional parser availability is environment-dependent.','', '## Not configured / blocked / unavailable','- No live AI, GitHub, CI, deployment, research, vision, or embedding credentials were detected.','- PostgreSQL/Redis Python clients are absent and no service was reachable.','- Docker is unavailable.','- Frontend dependencies are absent.','- Browser E2E was not tested.','', '## Security findings']+[f"- {x['status']}: {x['finding']}" for x in findings]+['','## Anti-fabrication','- No live provider response, GitHub mutation, CI result, deployment, browser test, Docker execution, PostgreSQL CRUD result, or autonomous repair success was claimed.']
    (ROOT/'phase10-final-audit.md').write_text('\n'.join(md)+'\n')
    print(json.dumps({'dependencies':deps,'measurements':measurements},indent=2))
if __name__=='__main__': main()
