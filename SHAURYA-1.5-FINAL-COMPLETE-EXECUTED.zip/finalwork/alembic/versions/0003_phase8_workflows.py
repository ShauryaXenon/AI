from alembic import op
import sqlalchemy as sa
revision='0003_phase8_workflows'; down_revision='0002_phase7_intelligence'; branch_labels=None; depends_on=None

def upgrade():
    op.create_table('git_repositories',
      sa.Column('id',sa.String(36),primary_key=True),sa.Column('project_id',sa.String(36),sa.ForeignKey('projects.id',ondelete='CASCADE'),nullable=False,unique=True),sa.Column('provider',sa.String(40),nullable=False),sa.Column('remote_url',sa.Text),sa.Column('remote_name',sa.String(80),nullable=False),sa.Column('default_branch',sa.String(255),nullable=False),sa.Column('external_repo_id',sa.String(255)),sa.Column('created_at',sa.DateTime,nullable=False),sa.Column('updated_at',sa.DateTime,nullable=False))
    op.create_index('ix_git_repositories_project_id','git_repositories',['project_id'],unique=True)
    op.create_table('approvals',
      sa.Column('id',sa.String(36),primary_key=True),sa.Column('user_id',sa.String(36),sa.ForeignKey('users.id',ondelete='CASCADE'),nullable=False),sa.Column('project_id',sa.String(36),sa.ForeignKey('projects.id',ondelete='CASCADE'),nullable=False),sa.Column('task_id',sa.String(36),sa.ForeignKey('tasks.id',ondelete='SET NULL')),sa.Column('action',sa.String(100),nullable=False),sa.Column('state',sa.String(30),nullable=False),sa.Column('payload',sa.JSON,nullable=False),sa.Column('result',sa.JSON),sa.Column('created_at',sa.DateTime,nullable=False),sa.Column('updated_at',sa.DateTime,nullable=False))
    for n,t in [('user_id','approvals'),('project_id','approvals'),('task_id','approvals')]: op.create_index(f'ix_approvals_{n}',t,[n])
    op.create_table('ci_runs',
      sa.Column('id',sa.String(36),primary_key=True),sa.Column('user_id',sa.String(36),sa.ForeignKey('users.id',ondelete='CASCADE'),nullable=False),sa.Column('project_id',sa.String(36),sa.ForeignKey('projects.id',ondelete='CASCADE'),nullable=False),sa.Column('provider',sa.String(80),nullable=False),sa.Column('status',sa.String(30),nullable=False),sa.Column('external_run_id',sa.String(255)),sa.Column('url',sa.Text),sa.Column('details',sa.JSON,nullable=False),sa.Column('created_at',sa.DateTime,nullable=False),sa.Column('updated_at',sa.DateTime,nullable=False))
    op.create_index('ix_ci_runs_user_id','ci_runs',['user_id']); op.create_index('ix_ci_runs_project_id','ci_runs',['project_id'])
    op.create_table('project_environments',
      sa.Column('id',sa.String(36),primary_key=True),sa.Column('project_id',sa.String(36),sa.ForeignKey('projects.id',ondelete='CASCADE'),nullable=False),sa.Column('environment',sa.String(30),nullable=False),sa.Column('key',sa.String(200),nullable=False),sa.Column('value_ref',sa.Text),sa.Column('is_secret',sa.Boolean,nullable=False),sa.Column('is_public',sa.Boolean,nullable=False),sa.Column('created_at',sa.DateTime,nullable=False))
    op.create_index('ix_project_env_key','project_environments',['project_id','environment','key'],unique=True)

def downgrade():
    op.drop_table('project_environments'); op.drop_table('ci_runs'); op.drop_table('approvals'); op.drop_table('git_repositories')
